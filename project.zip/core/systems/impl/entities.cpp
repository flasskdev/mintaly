#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <utilities/logging/logging.hpp>
#include <core/settings.hpp>

#include "../systems.hpp"

namespace systems {

	void entities::on_add_entity( std::uintptr_t entity, std::uint32_t handle )
	{
		if ( !entity )
		{
			return;
		}

		const auto index = static_cast< std::int16_t >( handle & 0x7fff );
		if ( index < 0 || index > 0x3fff )
		{
			return;
		}

		const auto schema_name = this->get_schema_name( entity );
		if ( !schema_name || !schema_name[ 0 ] )
		{
			return;
		}

		const auto hashed = fnv1a::runtime_hash( schema_name );
		const auto entity_type = this->classify_entity( hashed );

		if ( entity_type == type::unknown )
		{
			return;
		}

		cached entry{};
		entry.ptr = entity;
		entry.index = index;
		entry.schema_hash = hashed;
		entry.type = entity_type;

		std::unique_lock lock( this->m_cache_mtx );

		if ( !this->m_cached.insert( entry ) )
		{
			return;
		}

		if ( hashed == "C_SmokeGrenadeProjectile"_hash && settings::g_misc.m_smoke_and_fire_color.custom_smoke.value )
		{
			static auto smoke_col_offset = SCHEMA( "C_SmokeGrenadeProjectile", "m_vSmokeColor"_hash );
			if ( !smoke_col_offset )
			{
				smoke_col_offset = SCHEMA( "C_SmokeGrenadeProjectile", "m_vSmokeColor"_hash );
				if ( !smoke_col_offset )
				{
					const auto det_offset = SCHEMA( "C_SmokeGrenadeProjectile", "m_vSmokeDetonationPos"_hash );
					if ( det_offset >= 12 )
					{
						smoke_col_offset = det_offset - 12;
					}
				}
			}
			if ( smoke_col_offset )
			{
				const auto& col = settings::g_misc.m_smoke_and_fire_color.smoke_color.value;
				const math::vector3 smoke_col{
					static_cast<float>( col.r ) / 255.0f,
					static_cast<float>( col.g ) / 255.0f,
					static_cast<float>( col.b ) / 255.0f
				};
				memory::write<math::vector3>( entity + smoke_col_offset, smoke_col );
			}
		}
	}

	void entities::on_remove_entity( std::uintptr_t entity, std::uint32_t handle )
	{
		if ( !entity )
		{
			return;
		}

		const auto index = static_cast< std::int16_t >( handle & 0x7fff );
		if ( index < 0 || index > 0x3fff )
		{
			return;
		}

		std::unique_lock lock( this->m_cache_mtx );

		const auto entry = this->m_cached.find( static_cast<std::size_t>( index ) );
		// A delayed removal for a reused index must not erase its new occupant.
		if ( entry && entry->ptr == entity )
		{
			this->m_cached.erase( static_cast<std::size_t>( index ) );
		}
	}

	void entities::force_update( )
	{
		{
			std::unique_lock lock( this->m_cache_mtx );
			this->m_cached.clear( );
			this->m_cached.reserve( 128 );
		}

		for ( auto i = 0; i < 2048; ++i )
		{
			const auto entity = this->get_by_index( i );
			if ( !entity )
			{
				continue;
			}

			this->on_add_entity( entity, static_cast< std::uint32_t >( i ) );
		}
	}

	void entities::reset( )
	{
		std::unique_lock lock( this->m_cache_mtx );
		this->m_cached.clear( );
		this->m_cached_list_entries.fill( 0 );
		this->m_cached_entity_list = 0;
	}

	bool entities::exists( std::uintptr_t entity_ptr ) const
	{
		std::shared_lock lock( this->m_cache_mtx );

		for ( const auto& c : this->m_cached.entries( ) )
		{
			if ( c.ptr == entity_ptr )
			{
				return true;
			}
		}

		return false;
	}

	const char* entities::get_schema_name( std::uintptr_t entity ) const
	{
		if ( !entity || entity < 0x10000 )
		{
			return nullptr;
		}

		__try
		{
			const auto identity = *reinterpret_cast<const std::uintptr_t*>( entity + 0x10 );
			if ( !identity )
			{
				return nullptr;
			}

			const auto entity_class = *reinterpret_cast<const std::uintptr_t*>( identity + 0x8 );
			if ( !entity_class )
			{
				return nullptr;
			}

			// CEntityClass owns the current SchemaClassInfo pointer at 0x58.
			const auto class_info = *reinterpret_cast<const std::uintptr_t*>( entity_class + 0x58 );
			if ( !class_info )
			{
				return nullptr;
			}

			return *reinterpret_cast<const char* const*>( class_info + 0x8 );
		}
		__except ( EXCEPTION_EXECUTE_HANDLER )
		{
			return nullptr;
		}
	}

	std::uintptr_t entities::get_by_index( std::int32_t index )
	{
		if ( !addresses::globals::entity_list )
		{
			return 0;
		}

		const auto entity_list = memory::safe_read<std::uintptr_t>( addresses::globals::entity_list ).value_or( 0 );
		if ( !entity_list )
		{
			return 0;
		}

		if ( this->m_cached_entity_list != entity_list )
		{
			this->m_cached_entity_list = entity_list;
			this->m_cached_list_entries.fill( 0 );
		}

		const auto chunk_index = index >> 9;
		if ( chunk_index < 0 || chunk_index >= static_cast<int>( this->m_cached_list_entries.size( ) ) )
		{
			return 0;
		}

		if ( !this->m_cached_list_entries[ chunk_index ] )
		{
			this->m_cached_list_entries[ chunk_index ] = memory::safe_read<std::uintptr_t>( entity_list + ( static_cast< std::uintptr_t >( chunk_index ) * 8 ) + 0x10 ).value_or( 0 );
		}

		const auto list_entry = this->m_cached_list_entries[ chunk_index ];
		if ( !list_entry )
		{
			return 0;
		}

		return memory::safe_read<std::uintptr_t>( list_entry + ( static_cast< std::uintptr_t >( index & 0x1ff ) * 112 ) ).value_or( 0 );
	}

	std::uintptr_t entities::lookup( std::uint32_t handle ) const
	{
		if ( !handle || handle == 0xffffffff || !addresses::globals::entity_list )
		{
			return 0;
		}

		__try
		{
			const auto entity_list = *reinterpret_cast<const std::uintptr_t*>( addresses::globals::entity_list );
			if ( !entity_list )
			{
				return 0;
			}

			const auto list_entry = *reinterpret_cast<const std::uintptr_t*>( entity_list + ( static_cast< std::uintptr_t >( ( handle & 0x7fff ) >> 9 ) * 8 ) + 0x10 );
			if ( !list_entry || list_entry == 0xffffffffffffffff )
			{
				return 0;
			}

			const auto entity = *reinterpret_cast<const std::uintptr_t*>( list_entry + ( static_cast< std::uintptr_t >( handle & 0x1ff ) * 112 ) );
			if ( !entity || entity == 0xffffffffffffffff || entity < 0x10000 )
			{
				return 0;
			}

			return entity;
		}
		__except ( EXCEPTION_EXECUTE_HANDLER )
		{
			return 0;
		}
	}

	std::vector<entities::cached> entities::get_by_type( type type ) const
	{
		const auto type_index = static_cast<std::size_t>( type );
		{
			std::shared_lock lock( this->m_cache_mtx );
			if ( const auto ready = this->m_cached.snapshot_if_ready( type_index ) )
				return *ready;
		}
		// Recheck after acquiring the exclusive lock: another reader may have
		// rebuilt the snapshot, or an entity callback may have invalidated it.
		std::unique_lock lock( this->m_cache_mtx );
		return this->m_cached.snapshot( type_index );
	}

	bool entities::has_alive_enemies( std::uintptr_t local_controller, std::uintptr_t local_pawn, int local_team, bool is_team_mode ) const
	{
		if ( !local_controller || !local_pawn )
		{
			return false;
		}

		std::shared_lock lock( this->m_cache_mtx );
		const auto type_index = static_cast<std::size_t>( type::player );
		const auto ready = this->m_cached.snapshot_if_ready( type_index );
		if ( !ready )
		{
			return true;
		}

		for ( const auto& p : *ready )
		{
			if ( !p.ptr || p.ptr == local_controller )
			{
				continue;
			}

			if ( !memory::read<bool>( p.ptr + SCHEMA( "CCSPlayerController", "m_bPawnIsAlive"_hash ) ) )
			{
				continue;
			}

			const auto pawn_handle = memory::read<std::uint32_t>( p.ptr + SCHEMA( "CBasePlayerController", "m_hPawn"_hash ) );
			if ( !pawn_handle )
			{
				continue;
			}

			const auto pawn = this->lookup( pawn_handle );
			if ( !pawn || pawn == local_pawn )
			{
				continue;
			}

			const auto team = memory::read<int>( pawn + SCHEMA( "C_BaseEntity", "m_iTeamNum"_hash ) );
			if ( is_team_mode && team == local_team )
			{
				continue;
			}

			const auto health = memory::read<int>( pawn + SCHEMA( "C_BaseEntity", "m_iHealth"_hash ) );
			if ( health > 0 )
			{
				return true;
			}
		}

		return false;
	}

	bool entities::is_empty( ) const
	{
		std::shared_lock lock( this->m_cache_mtx );
		return this->m_cached.empty( );
	}

	entities::type entities::classify_entity( std::uint32_t schema_hash ) const
	{
		switch ( schema_hash )
		{
		case "CCSPlayerController"_hash:
			return type::player;

		case "C_AK47"_hash:
		case "C_WeaponM4A1"_hash:
		case "C_WeaponM4A1Silencer"_hash:
		case "C_WeaponAWP"_hash:
		case "C_WeaponAug"_hash:
		case "C_WeaponFamas"_hash:
		case "C_WeaponGalilAR"_hash:
		case "C_WeaponSG556"_hash:
		case "C_WeaponG3SG1"_hash:
		case "C_WeaponSCAR20"_hash:
		case "C_WeaponSSG08"_hash:
		case "C_WeaponMAC10"_hash:
		case "C_WeaponMP5SD"_hash:
		case "C_WeaponMP7"_hash:
		case "C_WeaponMP9"_hash:
		case "C_WeaponBizon"_hash:
		case "C_WeaponP90"_hash:
		case "C_WeaponUMP45"_hash:
		case "C_WeaponNOVA"_hash:
		case "C_WeaponSawedoff"_hash:
		case "C_WeaponXM1014"_hash:
		case "C_WeaponMag7"_hash:
		case "C_WeaponM249"_hash:
		case "C_WeaponNegev"_hash:
		case "C_DEagle"_hash:
		case "C_WeaponElite"_hash:
		case "C_WeaponFiveSeven"_hash:
		case "C_WeaponGlock"_hash:
		case "C_WeaponHKP2000"_hash:
		case "C_WeaponUSPSilencer"_hash:
		case "C_WeaponP250"_hash:
		case "C_WeaponCZ75a"_hash:
		case "C_WeaponTec9"_hash:
		case "C_WeaponRevolver"_hash:
		case "C_WeaponTaser"_hash:
		case "C_Knife"_hash:
		case "C_C4"_hash:
		case "C_Item_Healthshot"_hash:
		case "C_HEGrenade"_hash:
		case "C_Flashbang"_hash:
		case "C_SmokeGrenade"_hash:
		case "C_MolotovGrenade"_hash:
		case "C_IncendiaryGrenade"_hash:
		case "C_DecoyGrenade"_hash:
			return type::item;

		case "C_HEGrenadeProjectile"_hash:
		case "C_FlashbangProjectile"_hash:
		case "C_SmokeGrenadeProjectile"_hash:
		case "C_MolotovProjectile"_hash:
		case "C_Inferno"_hash:
		case "C_DecoyProjectile"_hash:
			return type::projectile;

		default:
			return type::unknown;
		}
	}

} // namespace systems
