#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <utilities/logging/logging.hpp>
#include <utilities/diag.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <protection/game_addresses.hpp>
#include <utilities/threadpool/threadpool.hpp>
#include <utilities/performance.hpp>

namespace features::combat {

    namespace perf = utilities::performance;

    namespace {
        void report_rage_timings()
        {
            static auto last = std::chrono::steady_clock::now();
            const auto now = std::chrono::steady_clock::now();
            if (now - last < std::chrono::seconds(5)) return;
            last = now;
            const auto samples = perf::take_samples();
            for (std::size_t i = 0; i < samples.size(); ++i)
            {
                const auto& value = samples[i];
                if (!value.calls) continue;
                char line[256]{};
                _snprintf_s(line, sizeof(line), _TRUNCATE,
                    "rage perf: %s calls=%llu avg_ms=%.3f max_ms=%.3f",
                    perf::names[i], static_cast<unsigned long long>(value.calls),
                    static_cast<double>(value.total_ns) / static_cast<double>(value.calls) / 1.0e6,
                    static_cast<double>(value.maximum_ns) / 1.0e6);
                diag::write(diag::level::debug, line);
            }
        }
    }

    // Helper for faster angle calculations
    namespace math_opt {
        [[nodiscard]] inline float deg_to_rad(float deg) { return deg * (std::numbers::pi_v<float> / 180.0f); }
        [[nodiscard]] inline float rad_to_deg(float rad) { return rad * (180.0f / std::numbers::pi_v<float>); }
    }

    void rage::on_create_move(systems::input::usercmd* cmd)
    {
        // Scan storage belongs to this command and is not re-entrant.
        static std::mutex command_mutex;
        std::lock_guard command_lock(command_mutex);
        report_rage_timings();
        perf::scope total_timer{perf::stage::rage_total};
        auto& ctx = g_shared.ctx();
        const auto local = systems::g_local.get();

        this->update_penetration_crosshair(local);
        this->m_should_stop = false;
        this->m_firing_this_tick = false;

        if (!ctx.valid)
        {
            this->m_revolver_cock_ticks = 0;
            return;
        }

        // Reset revolver logic if weapon changed
        if (ctx.item_def_idx != cstypes::item_definition_index::weapon_r8_revolver)
            this->m_revolver_cock_ticks = 0;

        // Duckpeek logic reset
        if (!settings::g_combat.m_duckpeek.enabled.value)
        {
            this->m_release_duck_for_shot = false;
            this->m_duckpeek_reduck = false;
            this->m_duckpeek_reduck_ticks = 0;
        }
        else if (this->m_duckpeek_reduck_ticks > 0)
        {
            --this->m_duckpeek_reduck_ticks;
        }

        if (!g_shared.has_alive_enemies())
        {
            this->m_revolver_cock_ticks = 0;
            return;
        }

        // Zeus handling
        if (this->m_zeus_fired)
        {
            this->m_zeus_fired = false;
            if (settings::g_combat.m_zeusbot.drop_after && !systems::g_local.is_in_deathmatch())
                memory::call<void>(PATTERN(patterns::engine_client_cmd), addresses::globals::source2engine_to_client, 0, "drop", 0x7ffef001);
            return;
        }

        const auto is_knife = ctx.weapon_type == cstypes::weapon_type::knife;
        const auto is_taser = ctx.weapon_type == cstypes::weapon_type::taser;

        // Filter invalid weapon types early
        if (!is_knife && !is_taser && (ctx.weapon_type < cstypes::weapon_type::pistol || ctx.weapon_type > cstypes::weapon_type::lmg))
            return;

        auto aim_ctx = this->build_context(cmd, local);

        if (is_knife)
        {
            if (!g_shared.can_shoot(cmd, local.controller))
                return;
            this->run_knife(cmd, aim_ctx, local);
        }
        else if (is_taser)
        {
            if (!g_shared.can_shoot(cmd, local.controller))
                return;
            this->run_taser(cmd, aim_ctx, local);
        }
        else if (ctx.item_def_idx == cstypes::item_definition_index::weapon_r8_revolver)
        {
            if (!settings::g_combat.m_ragebot.enabled)
            {
                this->m_revolver_cock_ticks = 0;
                return;
            }

            if (settings::g_combat.m_autos.revolver_quick.value)
            {
                this->m_revolver_cock_ticks = 0;
                // Quick shot: just fire attack2
                if (cmd->buttons.value & cstypes::command_buttons::in_attack)
                {
                    cmd->buttons.value &= ~cstypes::command_buttons::in_attack;
                    cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
                    cmd->buttons.value_scroll &= ~cstypes::command_buttons::in_attack;
                    cmd->csgo_user_cmd.set_attack1_start_history_index(-1);
                }
                if (!g_shared.can_shoot(cmd, local.controller))
                    return;
                this->run_gun(cmd, aim_ctx, local);
            }
            else
            {
                this->auto_revolver(cmd, aim_ctx, local);
            }
        }
        else
        {
            this->m_revolver_cock_ticks = 0;
            if (!settings::g_combat.m_ragebot.enabled)
                return;
            if (!g_shared.can_shoot(cmd, local.controller))
                return;
            this->run_gun(cmd, aim_ctx, local);
        }
    }

    void rage::on_render(xdraw::draw_list& draw_list)
    {
        this->draw_penetration_crosshair(draw_list);

        const auto& config = settings::g_combat.m_ragebot.get_group(g_shared.ctx().weapon_type, g_shared.ctx().item_def_idx);
        if (!config.debug_multipoints.value)
            return;

        std::lock_guard lock(m_debug_mtx);
        for (const auto& pt : m_debug_points)
        {
            const auto screen = systems::g_view.project(pt.position);
            if (!systems::g_view.projection_valid(screen))
                continue;

            xdraw::color col{};
            switch (pt.hitbox_index)
            {
            case 0: col = { 255, 80, 80 }; break; // Head
            case 2: case 3: col = { 220, 220, 60 }; break; // Stomach
            case 4: case 5: case 6: col = { 255, 160, 60 }; break; // Chest
            case 7: case 8: case 9: case 10: case 11: case 12: col = { 80, 160, 255 }; break; // Legs
            case 13: case 14: case 15: case 16: case 17: case 18: col = { 180, 80, 255 }; break; // Arms
            default: col = { 200, 200, 200 }; break;
            }

            const auto alpha = pt.is_center ? std::uint8_t{ 255 } : std::uint8_t{ 160 };
            const auto radius = pt.is_center ? 3.5f : 2.0f;
            draw_list.circle_filled(screen.x, screen.y, radius, col.alpha(alpha));
        }
    }

    rage::aim_context rage::build_context(systems::input::usercmd* cmd, const systems::local::snapshot& local) const
    {
        auto& ctx = g_shared.ctx();
        const auto& prestate = systems::g_prediction.pre();

        aim_context out{};
        out.velocity = prestate.velocity;
        out.spread = g_shared.get_spread();
        out.predicted_inaccuracy = g_shared.get_inaccuracy(true);
        auto recoil_index = ctx.recoil_index;

        // Keep spread, inaccuracy and recoil from the same simulated weapon state.
        systems::g_prediction.simulate(cmd, local, [&]
            {
                g_shared.sh().snapshot(local.pawn, ctx.weapon_services);
                out.velocity = memory::read<math::vector3>(local.pawn + SCHEMA("C_BaseEntity", "m_vecAbsVelocity"_hash));
                out.predicted_inaccuracy = g_shared.get_inaccuracy(true);
                out.spread = g_shared.get_spread();
                recoil_index = memory::read<float>(ctx.weapon + SCHEMA("C_CSWeaponBase", "m_flRecoilIndex"_hash));
            });

        ctx.spread = out.spread;
        ctx.inaccuracy = out.predicted_inaccuracy;
        ctx.recoil_index = recoil_index;
        out.view_angles = systems::g_input.get_view_angles();
        out.on_ground = (prestate.flags & cstypes::entity_flags::on_ground) != 0;
        out.is_scoped = ctx.is_scoped;
        out.weapon_max_speed = ctx.weapon_max_speed;
        out.accurate_threshold = ctx.weapon_max_speed * 0.34f;

        return out;
    }

    std::optional<rage::stop_prediction> rage::predict_stop(const aim_context& ctx, const math::vector3& current_eye, const systems::local::snapshot& local) const
    {
        const auto& shared_ctx = g_shared.ctx();
        const auto& prestate = systems::g_prediction.pre();
        const auto speed = prestate.networked_velocity.length_2d();

        // Check if we actually need to stop
        const auto will_stop = ctx.on_ground && (speed > ctx.accurate_threshold || (ctx.is_scoped && speed > 1.0f));
        if (!will_stop)
            return std::nullopt;

        auto sim_vel = prestate.networked_velocity;
        sim_vel.z = 0.0f;

        static const auto sv_friction_cv = CONVAR("sv_friction");
        static const auto sv_stopspeed_cv = CONVAR("sv_stopspeed");
        static const auto sv_accelerate_cv = CONVAR("sv_accelerate");
        const auto sv_friction = sv_friction_cv ? sv_friction_cv->get<float>() : 5.2f;
        const auto sv_stopspeed = sv_stopspeed_cv ? sv_stopspeed_cv->get<float>() : 100.0f;
        const auto sv_accelerate = sv_accelerate_cv ? sv_accelerate_cv->get<float>() : 5.5f;
        const auto surface_friction = prestate.surface_friction;
        const auto movement_services = memory::read<std::uintptr_t>(local.pawn + SCHEMA("C_BasePlayerPawn", "m_pMovementServices"_hash));
        const auto max_move_speed = movement_services ? memory::read<float>(movement_services + SCHEMA("CPlayer_MovementServices", "m_flMaxspeed"_hash)) : 250.0f;

        // Simulate friction decay
        for (auto i = 0; i < 15; ++i)
        {
            const auto sim_speed = sim_vel.length_2d();
            if (sim_speed < 1.0f)
                break;

            const auto control = std::fmaxf(sim_speed, sv_stopspeed);
            const auto drop = sv_friction * surface_friction * control * cstypes::tick_interval;
            auto new_speed = std::fmaxf(sim_speed - drop, 0.0f);

            auto accel = sv_accelerate;
            if (shared_ctx.is_scoped)
            {
                const auto weapon_ratio = std::fminf(1.0f, shared_ctx.weapon_max_speed / 250.0f);
                const auto scoped_max = std::fmaxf(250.0f, max_move_speed) * weapon_ratio * 0.52f;
                if (new_speed > scoped_max - 5.0f)
                {
                    const auto t = 1.0f - std::fmaxf(0.0f, new_speed - (scoped_max - 5.0f)) / std::fmaxf(0.01f, 5.0f);
                    accel *= std::clamp(t, 0.0f, 1.0f);
                }
            }

            const auto accel_speed = std::fminf(accel * shared_ctx.weapon_max_speed * surface_friction * cstypes::tick_interval, new_speed);
            new_speed = std::fmaxf(new_speed - accel_speed, 0.0f);

            if (new_speed > 0.0f)
                sim_vel *= (new_speed / sim_speed);
            else
            {
                sim_vel = {};
                break;
            }
        }

        const auto avg_vel = (prestate.networked_velocity + sim_vel) * 0.5f;
        const auto stop_ticks = g_shared.calculate_stop_ticks(prestate.networked_velocity, shared_ctx.weapon_max_speed, local.pawn);
        const auto stop_time = static_cast<float>(stop_ticks) * cstypes::tick_interval;

        return stop_prediction
        {
            .eye = { current_eye.x + avg_vel.x * stop_time, current_eye.y + avg_vel.y * stop_time, current_eye.z },
            .inaccuracy = g_shared.get_inaccuracy_at_velocity(local.pawn, sim_vel)
        };
    }

    namespace {
        std::vector<rage::candidate> s_candidates_buf{};
        std::vector<rage::scan_hit> s_eye_scan_buf{};
        std::vector<rage::scan_hit> s_hits_buf{};
    }

    std::vector<rage::candidate>& rage::gather_candidates(const systems::local::snapshot& local, float max_distance_sq)
    {
        perf::scope timer{perf::stage::gather};
        const auto& shared_ctx = g_shared.ctx();
        const auto players = systems::g_entities.get_by_type(systems::entities::type::player);

        s_candidates_buf.clear();
        s_candidates_buf.reserve(players.size());

        this->m_scan_records.clear();
        // Reserve before publishing pointers; at most two owned poses per player.
        this->m_scan_records.reserve(players.size() * k_max_scan_records);

        for (const auto& p : players)
        {
            if (!p.ptr || p.ptr == local.controller)
                continue;

            if (!memory::read<bool>(p.ptr + SCHEMA("CCSPlayerController", "m_bPawnIsAlive"_hash)))
                continue;

            const auto pawn_handle = memory::read<std::uint32_t>(p.ptr + SCHEMA("CBasePlayerController", "m_hPawn"_hash));
            const auto pawn = systems::g_entities.lookup(pawn_handle);
            if (!pawn || pawn == local.pawn)
                continue;

            const auto team = memory::read<int>(pawn + SCHEMA("C_BaseEntity", "m_iTeamNum"_hash));
            if (!local.is_this_other_team(team))
                continue;

            const auto health = memory::read<int>(pawn + SCHEMA("C_BaseEntity", "m_iHealth"_hash));
            if (health <= 0)
                continue;

            if (memory::read<bool>(pawn + SCHEMA("C_CSPlayerPawn", "m_bGunGameImmunity"_hash)))
                continue;

            auto snapshots = g_shared.lc().get_scan_records(pawn);
            if (snapshots.empty())
            {
                auto extrap = g_shared.lc().extrapolate(pawn);
                if (!extrap.has_value()) continue;
                snapshots.push_back(std::move(*extrap));
            }
            std::array<shared::lagcomp::record*, k_max_lagcomp_records> records_buf{};
            int records_count{};
            for (auto& snapshot : snapshots)
            {
                this->m_scan_records.push_back(std::move(snapshot));
                records_buf[records_count++] = &this->m_scan_records.back();
            }

            // Distance cull
            if (max_distance_sq > 0.0f)
            {
                const auto& origin = systems::g_prediction.pre().origin;
                const auto delta_front = records_buf[0]->origin - origin;
                auto closest_sq = delta_front.x * delta_front.x + delta_front.y * delta_front.y + delta_front.z * delta_front.z;

                if (records_count > 1)
                {
                    const auto delta_back = records_buf[records_count - 1]->origin - origin;
                    const auto back_sq = delta_back.x * delta_back.x + delta_back.y * delta_back.y + delta_back.z * delta_back.z;
                    closest_sq = std::min(closest_sq, back_sq);
                }

                if (closest_sq > max_distance_sq)
                    continue;
            }

            candidate c{};
            c.pawn = pawn;
            c.health = health;
            c.armor = memory::read<int>(pawn + SCHEMA("C_CSPlayerPawn", "m_ArmorValue"_hash));

            // Pick first and last record for scanning
            c.records[0] = records_buf[0];
            auto picked{ 1 };
            if (records_count > 1)
                c.records[picked++] = records_buf[records_count - 1];

            c.record_count = picked;

            if (shared_ctx.weapon_type >= cstypes::weapon_type::pistol && shared_ctx.weapon_type <= cstypes::weapon_type::lmg)
            {
                const auto& config = settings::g_combat.m_ragebot.get_group(shared_ctx.weapon_type, shared_ctx.item_def_idx);
                c.min_damage = this->get_min_damage(config, health, config.min_damage_override.value);
            }

            s_candidates_buf.push_back(c);
        }
        return s_candidates_buf;
    }

    bool rage::run_gun(systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local, bool allow_fire)
    {
        if (!settings::g_combat.m_ragebot.enabled)
            return false;

        diag::exception_scope rage_scope{ "rage: run_gun / configuration" };
        auto& shared_ctx = g_shared.ctx();
        const auto& config = settings::g_combat.m_ragebot.get_group(shared_ctx.weapon_type, shared_ctx.item_def_idx);
        const auto autostop_enabled = config.autostop.value;

        diag::set_exception_phase("rage: run_gun / gather_candidates");
        auto& candidates = this->gather_candidates(local);
        {
            std::lock_guard lock(m_debug_mtx);
            m_debug_points.clear();
        }

        if (candidates.empty())
            return false;

        diag::set_exception_phase("rage: run_gun / eye_candidates");
        auto eye_candidates = g_shared.sh().get_candidates();
        if (eye_candidates.count == 0)
        {
            eye_candidates.entries[0].position = g_shared.get_shoot_position();
            eye_candidates.entries[0].is_uninterpolated = true;
            eye_candidates.count = 1;
        }

        // Reusable static buffer for per-eye scan results; zero heap alloc per tick.
        s_eye_scan_buf.clear();
        s_eye_scan_buf.reserve(64);
        auto& eye_scan_buf = s_eye_scan_buf;

        const auto scan_from_eye_candidates = [&](const math::vector3& eye_offset, float inaccuracy, std::vector<scan_hit>& hits_out)
            {
                hits_out.clear();
                for (auto i = 0; i < eye_candidates.count; ++i)
                {
                    const auto eye = eye_candidates.entries[i].position + eye_offset;
                    eye_scan_buf.clear();
                    this->scan_players(eye, inaccuracy, ctx, candidates, local, eye_scan_buf);

                    auto found_direct{ false };
                    auto source_eye = eye_candidates.entries[i];
                    source_eye.position = eye;
                    for (auto& hit : eye_scan_buf)
                    {
                        hit.source_eye = source_eye;
                        found_direct = found_direct || !hit.penetrated;
                        hits_out.push_back(std::move(hit));
                    }
                    if (found_direct)
                        break;
                }
            };

        diag::set_exception_phase("rage: run_gun / movement_and_selection");
        const auto& prestate = systems::g_prediction.pre();
        const auto duckpeek_active = settings::g_combat.m_duckpeek.enabled.value && ctx.on_ground;
        const auto movement_services = memory::read<std::uintptr_t>(local.pawn + SCHEMA("C_BasePlayerPawn", "m_pMovementServices"_hash));
        const auto duck_amount = movement_services ? memory::read<float>(movement_services + SCHEMA("CCSPlayer_MovementServices", "m_flDuckAmount"_hash)) : 0.0f;
        const auto is_ducking = (duck_amount > 0.05f) || ((prestate.flags & cstypes::entity_flags::ducking) != 0) || ((cmd->buttons.value & cstypes::command_buttons::in_duck) != 0);
        const auto effective_stand_z = is_ducking ? std::clamp(duck_amount * 18.0f, 0.0f, 18.0f) : 0.0f;

        if (duckpeek_active && this->m_duckpeek_reduck)
        {
            if ((this->m_duckpeek_reduck_ticks <= 0 && duck_amount >= 0.60f) || this->m_duckpeek_reduck_ticks <= -10)
                this->m_duckpeek_reduck = false;
        }

        // Reusable static hits buffer for all scan_from_eye_candidates calls below.
        s_hits_buf.clear();
        s_hits_buf.reserve(64);
        auto& hits_buf = s_hits_buf;

        // No-spread uses the same predicted state as scanning. fire_gun validates
        // the compensated trajectory instead of assuming compensation always hits.
        if (config.no_spread.value)
        {
            scan_from_eye_candidates({}, shared_ctx.inaccuracy, hits_buf);
            const auto best = hits_buf.empty() ? target{} : this->select_best(ctx, hits_buf, shared_ctx.inaccuracy);

            if (best.valid && allow_fire)
            {
                this->fire_gun(cmd, best, false, best.hit.source_eye.position, local);
                if (duckpeek_active && this->m_firing_this_tick)
                {
                    this->m_duckpeek_reduck = true;
                    this->m_duckpeek_reduck_ticks = 10;
                    this->m_release_duck_for_shot = false;
                }
                return best.valid;
            }

            // Duckpeek standing scan
            if (duckpeek_active && is_ducking && !this->m_duckpeek_reduck)
            {
                const auto stand_offset = math::vector3{ 0.0f, 0.0f, effective_stand_z };
                scan_from_eye_candidates(stand_offset, shared_ctx.inaccuracy, hits_buf);
                const auto standing_best = hits_buf.empty() ? target{} : this->select_best(ctx, hits_buf, shared_ctx.inaccuracy);

                if (standing_best.valid)
                {
                    this->m_release_duck_for_shot = true;
                    if (autostop_enabled && this->should_stop_movement(ctx))
                        this->m_should_stop = true;
                }
                else
                {
                    this->m_release_duck_for_shot = false;
                }
            }
            else if (!duckpeek_active)
            {
                this->m_release_duck_for_shot = false;
            }
            return best.valid;
        }

        // Standard hitchance-based logic
        const auto primary_eye = eye_candidates.entries[0].position;
        scan_from_eye_candidates({}, ctx.predicted_inaccuracy, hits_buf);
        const auto best = this->select_best(ctx, hits_buf, ctx.predicted_inaccuracy);

        // Auto-scope
        if (settings::g_combat.m_autos.scope.value && settings::g_combat.m_ragebot.enabled &&
            shared_ctx.weapon_type == cstypes::weapon_type::sniper && !shared_ctx.is_scoped &&
            best.valid && !(cmd->buttons.value & cstypes::command_buttons::in_second_attack))
        {
            cmd->buttons.value |= cstypes::command_buttons::in_second_attack;
            cmd->buttons.value_changed |= cstypes::command_buttons::in_second_attack;
            cmd->buttons.value_scroll |= cstypes::command_buttons::in_second_attack;
        }

        const auto needed_hc = config.hitchance_override.value ?
            static_cast<float>(config.hitchance_override_value) / 100.0f :
            static_cast<float>(config.hitchance) / 100.0f;

        const auto standing_inaccuracy = duckpeek_active ? this->get_standing_inaccuracy(local, ctx) : ctx.predicted_inaccuracy;
        const auto current_hc = best.valid ? best.hitchance : 0.0f;
        const auto accurate = best.valid && current_hc >= needed_hc;
        const auto max_acc = g_shared.is_max_accuracy(ctx.predicted_inaccuracy);
        const auto force = best.valid && (ctx.on_ground ? (config.force_shot.value && max_acc) : (config.force_shot_air.value && max_acc));
        const auto shot_viable = accurate || force;

        if (shot_viable && allow_fire)
        {
            this->fire_gun(cmd, best, !accurate && force, best.hit.source_eye.position, local);
            if (duckpeek_active && this->m_firing_this_tick)
            {
                this->m_duckpeek_reduck = true;
                this->m_duckpeek_reduck_ticks = 10;
                this->m_release_duck_for_shot = false;
            }
            return best.valid;
        }

        // Duckpeek logic: check if standing up reveals a better shot
        if (duckpeek_active && is_ducking && !this->m_duckpeek_reduck)
        {
            const auto stand_offset = math::vector3{ 0.0f, 0.0f, effective_stand_z };
            scan_from_eye_candidates(stand_offset, standing_inaccuracy, hits_buf);
            const auto standing_best = hits_buf.empty() ? target{} : this->select_best(ctx, hits_buf, standing_inaccuracy);

            if (standing_best.valid)
            {
                const auto pred_standing_hc = standing_best.hitchance;
                const auto pred_accurate = pred_standing_hc >= needed_hc;
                const auto pred_max_acc = g_shared.is_max_accuracy(standing_inaccuracy);
                const auto pred_force = config.force_shot.value && pred_max_acc;

                if (pred_accurate || pred_force)
                {
                    this->m_release_duck_for_shot = true;
                    if (autostop_enabled && this->should_stop_movement(ctx))
                        this->m_should_stop = true;

                    if (settings::g_combat.m_autos.scope.value && settings::g_combat.m_ragebot.enabled &&
                        shared_ctx.weapon_type == cstypes::weapon_type::sniper && !shared_ctx.is_scoped &&
                        !(cmd->buttons.value & cstypes::command_buttons::in_second_attack))
                    {
                        cmd->buttons.value |= cstypes::command_buttons::in_second_attack;
                        cmd->buttons.value_changed |= cstypes::command_buttons::in_second_attack;
                        cmd->buttons.value_scroll |= cstypes::command_buttons::in_second_attack;
                    }
                    return best.valid;
                }
            }
            this->m_release_duck_for_shot = false;
        }
        else if (!duckpeek_active)
        {
            this->m_release_duck_for_shot = false;
        }

        // Autostop planning
        if (autostop_enabled && !shot_viable && this->should_stop_movement(ctx))
        {
            const auto stop = this->predict_stop(ctx, primary_eye, local);
            if (stop)
            {
                const auto future_offset = stop->eye - primary_eye;
                scan_from_eye_candidates(future_offset, stop->inaccuracy, hits_buf);
                const auto planned = this->select_best(ctx, hits_buf, stop->inaccuracy);
                this->m_should_stop = planned.valid;
            }
            else
            {
                this->m_should_stop = best.valid;
            }
        }

        return best.valid;
    }

    void rage::run_taser(systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local)
    {
        if (!settings::g_combat.m_zeusbot.enabled)
            return;

        auto candidates = this->gather_candidates(local);
        if (candidates.empty())
            return;

        auto eye_candidates = g_shared.sh().get_candidates();
        if (eye_candidates.count == 0)
        {
            eye_candidates.entries[0].position = g_shared.get_shoot_position();
            eye_candidates.entries[0].is_uninterpolated = true;
            eye_candidates.count = 1;
        }

        std::vector<scan_hit> all_hits;
        for (auto i = 0; i < eye_candidates.count; ++i)
        {
            auto hits = this->scan_taser(eye_candidates.entries[i].position, ctx, candidates, local);
            for (auto& h : hits)
            {
                h.source_eye = eye_candidates.entries[i];
                all_hits.push_back(std::move(h));
            }
        }

        if (all_hits.empty())
            return;

        target best{};
        for (const auto& h : all_hits)
        {
            if (!best.valid || h.score > best.score)
            {
                best.hit = h;
                best.hitchance = 1.0f;
                best.score = h.score;
                best.valid = true;
            }
        }

        if (best.valid)
        {
            this->m_zeus_fired = true;
            this->fire_melee(cmd, best, local);
        }
    }

    void rage::run_knife(systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local)
    {
        if (!settings::g_combat.m_knifebot.enabled)
            return;

        const auto info = this->get_knife_info(local);
        if (!info.can_slash && !info.can_stab)
            return;

        constexpr auto max_knife_dist_sq = 150.0f * 150.0f;
        auto candidates = this->gather_candidates(local, max_knife_dist_sq);
        if (candidates.empty())
            return;

        auto eye_candidates = g_shared.sh().get_candidates();
        if (eye_candidates.count == 0)
        {
            eye_candidates.entries[0].position = g_shared.get_shoot_position();
            eye_candidates.entries[0].is_uninterpolated = true;
            eye_candidates.count = 1;
        }

        std::vector<scan_hit> all_hits;
        for (auto i = 0; i < eye_candidates.count; ++i)
        {
            auto hits = this->scan_knife(eye_candidates.entries[i].position, ctx, info, candidates, local);
            for (auto& h : hits)
            {
                h.source_eye = eye_candidates.entries[i];
                all_hits.push_back(std::move(h));
            }
        }

        if (all_hits.empty())
            return;

        target best{};
        target best_backstab{};

        for (const auto& h : all_hits)
        {
            auto& dest = h.is_backstab ? best_backstab : best;
            if (!dest.valid || h.score > dest.score)
            {
                dest.hit = h;
                dest.hitchance = 1.0f;
                dest.score = h.score;
                dest.valid = true;
            }
        }

        auto& chosen = best_backstab.valid ? best_backstab : best;
        if (!chosen.valid)
            return;

        this->m_knife_attack = static_cast<std::uint8_t>(chosen.hit.attack_type);
        this->fire_melee(cmd, chosen, local);
    }

    void rage::auto_revolver(systems::input::usercmd* cmd, const aim_context& ctx, const systems::local::snapshot& local)
    {
        if (!settings::g_combat.m_ragebot.enabled)
        {
            this->m_revolver_cock_ticks = 0;
            return;
        }

        if (!g_shared.can_shoot(cmd, local.controller))
        {
            this->m_revolver_cock_ticks = 0;
            return;
        }

        if (!settings::g_combat.m_autos.revolver.value)
        {
            this->m_revolver_cock_ticks = 0;
            return;
        }

        constexpr auto cock_ticks{ 13 };
        if (this->m_revolver_cock_ticks >= cock_ticks)
        {
            // Fire!
            cmd->buttons.value &= ~cstypes::command_buttons::in_attack;
            cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
            cmd->buttons.value_scroll &= ~cstypes::command_buttons::in_attack;
            cmd->csgo_user_cmd.set_attack1_start_history_index(-1);

            this->m_revolver_cock_ticks = 0;
            this->run_gun(cmd, ctx, local);
            return;
        }

        // Keep holding attack to cock the hammer
        this->run_gun(cmd, ctx, local, false);

        cmd->buttons.value |= cstypes::command_buttons::in_attack;
        cmd->buttons.value_changed |= cstypes::command_buttons::in_attack;
        cmd->buttons.value_scroll |= cstypes::command_buttons::in_attack;

        const auto history_index = cmd->csgo_user_cmd.input_history_size() - 1;
        if (history_index >= 0)
            cmd->csgo_user_cmd.set_attack1_start_history_index(history_index);

        ++this->m_revolver_cock_ticks;
    }

    void rage::scan_players(const math::vector3& eye, float inaccuracy, const aim_context& ctx, std::vector<candidate>& candidates, const systems::local::snapshot& local, std::vector<scan_hit>& out) const
    {
        diag::exception_scope scan_scope{ "rage: scan_players / batch" };
        if (candidates.empty()) return;
        const auto penetration = g_shared.pen(); // Immutable weapon-data snapshot.
        // Initialize TLS on the owner before any worker reads its slot index.
        if (!penetration.prepare_workers()) return;
        const auto max_fov = static_cast<float>(settings::g_combat.m_ragebot.get_group(
            g_shared.ctx().weapon_type, g_shared.ctx().item_def_idx).max_fov);
        const auto view_angles = ctx.view_angles;
        const auto local_pawn = local.pawn;
        const auto local_team = local.team;

        m_scan_work.resize(candidates.size());
        m_candidate_hits.resize(candidates.size());
        m_candidate_done.assign(candidates.size(), 0);
        for (auto& hits : m_candidate_hits) hits.clear();

        // One queue per record round, not two barriers per individual player.
        // Newest poses run first; retain the direct-hit early-out for older poses.
        for (int ri = 0; ri < k_max_scan_records; ++ri)
        {
            m_scan_tasks.clear();
            for (std::size_t ci = 0; ci < candidates.size(); ++ci)
            {
                auto& work = m_scan_work[ci];
                work.point_count = 0;
                const auto& cand = candidates[ci];
                if (m_candidate_done[ci] || ri >= cand.record_count) continue;
                this->prepare_scan(eye, inaccuracy, ctx, cand, cand.records[ri], work);
                std::array<bool, 19> queued{};
                for (int pi = 0; pi < work.point_count; ++pi)
                {
                    work.hits[pi].reset();
                    const auto& point = work.points[pi];
                    if (!point.is_center || point.hitbox_index < 0 || point.hitbox_index >= 19) continue;
                    if (queued[point.hitbox_index]) continue;
                    queued[point.hitbox_index] = true;
                    m_scan_tasks.push_back({ci, point.hitbox_index});
                }
            }
            if (m_scan_tasks.empty()) continue;

            {
                perf::scope timer{perf::stage::scan_batch};
                threadpool::parallel_for(0, static_cast<int>(m_scan_tasks.size()), [&](int begin, int end)
                {
                    for (int ti = begin; ti < end; ++ti)
                    {
                        const auto task = m_scan_tasks[ti];
                        auto& work = m_scan_work[task.candidate_index];
                        const auto& cand = candidates[task.candidate_index];
                        bool center_sufficient{};
                        // Each hitbox (its center and dependent multipoints) has
                        // one owner. No shared push_back, masks or worker-ID buffers.
                        for (int pi = 0; pi < work.point_count; ++pi)
                        {
                            const auto& point = work.points[pi];
                            if (point.hitbox_index != task.hitbox_index) continue;
                            if (!point.is_center && center_sufficient) continue;
                            const auto aim = math::helpers::calculate_angle(eye, point.position);
                            const auto fov = math::helpers::angle_distance(view_angles, aim);
                            if (fov > max_fov) continue;
                            shared::penetration::result pen{};
                            if (!penetration.run(eye, point.position, work.penetration, local_pawn, local_team, pen)) continue;
                            if (pen.damage < cand.min_damage) continue;
                            if (!point.is_center && point.hitbox_index == 0 &&
                                pen.hitgroup != systems::g_hitboxes.hitgroup_from_hitbox(0)) continue;
                            if (point.is_center && (!pen.penetrated || pen.damage >= static_cast<float>(cand.health)))
                                center_sufficient = true;

                            scan_hit hit{};
                            hit.position = point.position;
                            hit.aim_angle = aim;
                            hit.damage = pen.damage;
                            hit.fov = fov;
                            hit.hitbox_index = point.hitbox_index;
                            hit.hitgroup = pen.hitgroup;
                            hit.bone_index = point.bone_index;
                            hit.hitbox = point.hitbox;
                            hit.is_center = point.is_center;
                            hit.penetrated = pen.penetrated;
                            hit.pawn = cand.pawn;
                            hit.health = cand.health;
                            hit.record = work.penetration.record;
                            work.hits[pi] = hit;
                        }
                    }
                });
            }
            // Stable candidate/record/center/multipoint ordering is independent
            // of worker completion order, preserving selection tie-breaking.
            for (std::size_t ci = 0; ci < candidates.size(); ++ci)
            {
                const auto& work = m_scan_work[ci];
                for (bool centers : {true, false})
                {
                    for (int pi = 0; pi < work.point_count; ++pi)
                    {
                        const auto& hit = work.hits[pi];
                        if (!hit || hit->is_center != centers) continue;
                        m_candidate_hits[ci].push_back(*hit);
                        if (!hit->penetrated) m_candidate_done[ci] = 1;
                    }
                }
            }
        }
        for (const auto& hits : m_candidate_hits)
            out.insert(out.end(), hits.begin(), hits.end());
    }

    void rage::prepare_scan(const math::vector3& eye, float inaccuracy, const aim_context& ctx, const candidate& cand, shared::lagcomp::record* record, scan_work& work) const
    {
        perf::scope timer{perf::stage::prepare_scan};
        work.point_count = 0;
        diag::exception_scope player_scope{ "rage: prepare_scan / validation" };
        if (!cand.pawn || cand.record_count <= 0 || cand.health <= 0 ||
            !record || !record->valid || record->bone_count <= 0)
            return;

        const auto& shared_ctx = g_shared.ctx();
        const auto& config = settings::g_combat.m_ragebot.get_group(shared_ctx.weapon_type, shared_ctx.item_def_idx);

        diag::set_exception_phase("rage: scan_player / hitboxes");
        const auto to_cand = math::helpers::calculate_angle(eye, record->origin);
        const auto base_fov = math::helpers::angle_distance(ctx.view_angles, to_cand);
        if (config.max_fov < 180.0f && base_fov > config.max_fov + 30.0f)
            return;

        diag::set_exception_phase("rage: scan_player / prepare_target");
        work.penetration = g_shared.pen().prepare_target(cand.pawn, record);
        const auto& pen_ctx = work.penetration;
        if (pen_ctx.geometry_count <= 0)
            return;

        const auto& hitbox_set = pen_ctx.hitboxes;
        diag::set_exception_phase("rage: scan_player / multipoints");

        const auto force_body = config.body_aim.value;
        std::array<int, 19> scan_order{};
        auto scan_count{ 0 };

        // Build scan order based on config
        if (!force_body && config.hitboxes.values[0])
            scan_order[scan_count++] = 0; // Head

        if (config.hitboxes.values[1])
        {
            scan_order[scan_count++] = 4; // Chest
            scan_order[scan_count++] = 5;
            scan_order[scan_count++] = 6;
        }

        if (config.hitboxes.values[2])
        {
            scan_order[scan_count++] = 3; // Stomach
            scan_order[scan_count++] = 2;
        }

        if (config.hitboxes.values[3])
        {
            for (auto idx : { 13, 14, 15, 16, 17, 18 }) // Arms
                scan_order[scan_count++] = idx;
        }

        if (config.hitboxes.values[4])
        {
            for (auto idx : { 7, 8, 9, 10 }) // Legs
                scan_order[scan_count++] = idx;
        }

        if (config.hitboxes.values[5])
        {
            for (auto idx : { 11, 12 }) // Feet
                scan_order[scan_count++] = idx;
        }

        // Fallback if nothing selected
        if (scan_count == 0)
        {
            if (!force_body)
                scan_order[scan_count++] = 0;
            for (auto idx : { 4, 5, 6, 3, 2 })
                scan_order[scan_count++] = idx;
        }

        // Build O(1) hitbox LUT indexed by hitbox index (max 19)
        std::array<const systems::hitboxes::entry*, 19> hitbox_lut{};
        for (const auto& entry : hitbox_set)
        {
            if (entry.index >= 0 && entry.index < 19)
                hitbox_lut[entry.index] = &entry;
        }

        // Reuse owner-allocated storage; workers never resize these buffers.
        auto& points = work.points;
        auto& point_count = work.point_count;

        // Batch debug points to avoid per-point mutex acquisition
        std::array<debug_point, 256> local_debug_points{};
        auto debug_count{ 0 };
        const auto collecting_debug = config.debug_multipoints.value;

        for (auto idx = 0; idx < scan_count; ++idx)
        {
            const auto hitbox_index = scan_order[idx];
            if (hitbox_index < 0 || hitbox_index >= 19)
                continue;

            const auto* hb = hitbox_lut[hitbox_index];
            if (!hb || hb->bone < 0 || hb->bone >= record->bone_count)
                continue;

            const auto& bone = record->bones[hb->bone];
            if (bone.position.length_sqr() < 1.0f)
                continue;

            const auto hitbox_center = (hb->mins + hb->maxs) * 0.5f;
            const auto center = bone.rotation.rotate_vector(hitbox_center) + bone.position;

            if (point_count < static_cast<int>(points.size()))
            {
                auto& cp = points[point_count++];
                cp.position = center;
                cp.hitbox_index = hitbox_index;
                cp.bone_index = hb->bone;
                cp.hitbox = *hb;
                cp.is_center = true;
            }

            if (collecting_debug && debug_count < static_cast<int>(local_debug_points.size()))
                local_debug_points[debug_count++] = { center, hitbox_index, true };

            // Generate multipoints
            if (config.pointscale > 0.0f)
            {
                const auto mps = this->generate_multipoints(*hb, center, bone.rotation, config.pointscale, eye, inaccuracy);
                // Duplicate check scoped to current hitbox's points only
                const auto hitbox_start = point_count - 1; // center point we just added
                for (auto mi = 0; mi < mps.count; ++mi)
                {
                    const auto& mp = mps.points[mi];

                    // Only check points belonging to the same hitbox for duplicates
                    auto duplicate{ false };
                    for (auto pi = hitbox_start; pi < point_count; ++pi)
                    {
                        if (points[pi].hitbox_index == hitbox_index && (points[pi].position - mp).length_sqr() < 0.01f)
                        {
                            duplicate = true;
                            break;
                        }
                    }

                    if (duplicate)
                        continue;

                    if (point_count < static_cast<int>(points.size()))
                    {
                        auto& tp = points[point_count++];
                        tp.position = mp;
                        tp.hitbox_index = hitbox_index;
                        tp.bone_index = hb->bone;
                        tp.hitbox = *hb;
                        tp.is_center = false;
                    }

                    if (collecting_debug && debug_count < static_cast<int>(local_debug_points.size()))
                        local_debug_points[debug_count++] = { mp, hitbox_index, false };
                }
            }
        }

        // Batch-write debug points under a single lock
        if (collecting_debug && debug_count > 0)
        {
            std::lock_guard lock(m_debug_mtx);
            for (auto i = 0; i < debug_count; ++i)
                m_debug_points.push_back(local_debug_points[i]);
        }

        // Dispatch is owned by scan_players after all target inputs are ready.
    }

    rage::target rage::select_best(const aim_context& aim_ctx, const std::vector<scan_hit>& hits, float eval_inaccuracy) const
    {
        perf::scope selection_timer{perf::stage::selection};
        auto hitgroup_priority = [](int hitbox_index) -> int
            {
                if (hitbox_index == 0) return 4; // Head
                if (hitbox_index >= 1 && hitbox_index <= 6) return 3; // Torso
                if (hitbox_index >= 13 && hitbox_index <= 18) return 2; // Arms
                if (hitbox_index >= 7 && hitbox_index <= 12) return 1; // Legs
                return 0;
            };

        struct record_group
        {
            shared::lagcomp::record* record{};
            std::array<int, 32> hit_indices{};
            int index_count{};
        };

        // Stack-local groups: max candidates × max_scan_records is small (typically 2-8)
        std::array<record_group, 16> groups{};
        auto group_count{ 0 };

        for (auto i = 0; i < static_cast<int>(hits.size()); ++i)
        {
            auto rec = hits[i].record;
            auto found{ false };
            for (auto gi = 0; gi < group_count; ++gi)
            {
                if (groups[gi].record == rec)
                {
                    if (groups[gi].index_count < static_cast<int>(groups[gi].hit_indices.size()))
                        groups[gi].hit_indices[groups[gi].index_count++] = i;
                    found = true;
                    break;
                }
            }
            if (!found && group_count < static_cast<int>(groups.size()))
            {
                auto& g = groups[group_count++];
                g.record = rec;
                g.hit_indices[0] = i;
                g.index_count = 1;
            }
        }

        constexpr auto top_k_per_record{ 8 };
        auto cheap_score = [&](const scan_hit& h) -> float
            {
                const auto lethal_bonus = h.damage >= static_cast<float>(h.health) ? 100000.0f : 0.0f;
                const auto direct_bonus = h.penetrated ? 0.0f : 5000.0f;
                const auto center_bonus = h.is_center ? 2000.0f : 0.0f;
                return lethal_bonus + direct_bonus + center_bonus + h.damage * 20.0f +
                    static_cast<float>(hitgroup_priority(h.hitbox_index)) * 10.0f - h.fov;
            };

        for (auto gi = 0; gi < group_count; ++gi)
        {
            auto& group = groups[gi];
            if (group.index_count <= top_k_per_record)
                continue;

            std::partial_sort
            (
                group.hit_indices.begin(),
                group.hit_indices.begin() + top_k_per_record,
                group.hit_indices.begin() + group.index_count,
                [&](int a, int b) { return cheap_score(hits[a]) > cheap_score(hits[b]); }
            );
            group.index_count = top_k_per_record;
        }

        // Collect all candidate indices from groups into a flat array
        std::array<int, 128> candidate_indices{};
        auto cand_count{ 0 };
        for (auto gi = 0; gi < group_count; ++gi)
        {
            const auto& group = groups[gi];
            if (!group.record || !group.record->valid)
                continue;
            for (auto ii = 0; ii < group.index_count; ++ii)
            {
                if (cand_count < static_cast<int>(candidate_indices.size()))
                    candidate_indices[cand_count++] = group.hit_indices[ii];
            }
        }

        // Sort candidate hits globally by cheap_score so most promising hits are tested first
        std::sort(candidate_indices.begin(), candidate_indices.begin() + cand_count,
            [&](int a, int b) { return cheap_score(hits[a]) > cheap_score(hits[b]); });

        const auto& config = settings::g_combat.m_ragebot.get_group(g_shared.ctx().weapon_type, g_shared.ctx().item_def_idx);
        const auto needed_hc = config.hitchance_override.value ?
            static_cast<float>(config.hitchance_override_value) / 100.0f :
            static_cast<float>(config.hitchance) / 100.0f;

        // Build the spread cache once for the entire evaluation loop.
        const auto hc_cache = config.no_spread.value
            ? shared::spread_cache{}
            : g_shared.build_spread_cache( eval_inaccuracy, aim_ctx.spread );
        const auto weapon_range = g_shared.ctx().range;
        const auto no_spread = config.no_spread.value;
        const auto batch_width = no_spread ? 1 : std::max(threadpool::get_thread_count(), 1);
        std::array<float, 128> hitchances{};
        hitchances.fill(-1.0f);

        target best{};

        for (auto ci = 0; ci < cand_count; ++ci)
        {
            const auto idx = candidate_indices[ci];
            const auto& h = hits[idx];
            if (!h.record || !h.record->valid || h.bone_index < 0 || h.bone_index >= 28)
                continue;

            const auto hp = static_cast<float>(h.health);
            const auto can_kill = h.damage >= hp;

            // Theoretical upper bound score if this hit had 100% hitchance
            const auto max_possible_score = 1000000.0f +
                (can_kill ? (100000.0f + 10000.0f) : (h.damage * 105.0f)) +
                (h.penetrated ? 0.0f : 250.0f) +
                (h.is_center ? 50.0f : 0.0f) +
                static_cast<float>(hitgroup_priority(h.hitbox_index)) * 2.0f -
                h.fov * 0.1f;

            // Branch-and-bound: if even 100% hitchance cannot beat our best found shot, skip hitchance testing!
            if (best.valid && best.score >= 1000000.0f && max_possible_score < best.score - 0.01f)
                continue;

            if (!no_spread && hitchances[ci] < 0.0f)
            {
                // Ordered waves retain branch-and-bound between batches instead
                // of evaluating every discarded candidate unconditionally.
                const auto wave_end = ci + std::min(batch_width, cand_count - ci);
                perf::scope timer{perf::stage::hitchance_batch};
                threadpool::parallel_for(ci, wave_end, [&](int begin, int end)
                {
                    for (int wi = begin; wi < end; ++wi)
                    {
                        const auto& hit = hits[candidate_indices[wi]];
                        auto hc_value = 0.0f;
                        if (hit.record && hit.record->valid && hit.bone_index >= 0 &&
                            hit.bone_index < 28 && hit.bone_index < hit.record->bone_count)
                        {
                            hc_value = g_shared.calculate_hitchance(hit.source_eye.position, hit.aim_angle,
                                hit.hitbox, hit.record->bones[hit.bone_index], hc_cache, weapon_range);
                        }
                        hitchances[wi] = hc_value;
                    }
                });
            }
            const auto hc = no_spread ? 1.0f : hitchances[ci];

            const auto passes_hitchance = config.no_spread.value || hc >= needed_hc;

            auto score = passes_hitchance ? 1000000.0f : 0.0f;
            if (can_kill)
                score += 100000.0f + hc * 10000.0f;
            else
                score += h.damage * hc * 100.0f + h.damage * 5.0f;

            score += h.penetrated ? 0.0f : 250.0f;
            score += h.is_center ? 50.0f : 0.0f;
            score += static_cast<float>(hitgroup_priority(h.hitbox_index)) * 2.0f;
            score -= h.fov * 0.1f;

            auto is_better = !best.valid || score > best.score;
            if (best.valid && std::fabsf(score - best.score) < 0.01f)
            {
                if (h.record->tick != best.hit.record->tick)
                    is_better = h.record->tick > best.hit.record->tick;
                else if (h.is_center != best.hit.is_center)
                    is_better = h.is_center;
                else
                    is_better = h.fov < best.hit.fov;
            }

            if (is_better)
            {
                best.hit = h;
                best.hitchance = hc;
                best.score = score;
                best.valid = true;
            }
        }

        return best;
    }

    float rage::evaluate_hitchance(const scan_hit& hit, const aim_context& ctx, float inaccuracy) const
    {
        if (!hit.record || !hit.record->valid || hit.bone_index < 0 || hit.bone_index >= 28)
            return 0.0f;

        return g_shared.calculate_hitchance(hit.source_eye.position, hit.aim_angle, hit.hitbox, hit.record->bones[hit.bone_index], inaccuracy, ctx.spread);
    }

    float rage::get_standing_inaccuracy(const systems::local::snapshot& local, const aim_context& ctx) const
    {
        const auto& prestate = systems::g_prediction.pre();
        auto velocity = prestate.networked_velocity;
        velocity.z = 0.0f;
        const auto speed = velocity.length_2d();

        if (speed > ctx.accurate_threshold)
            return g_shared.get_inaccuracy_at_velocity(local.pawn, velocity);

        const auto& shared_ctx = g_shared.ctx();
        if (!shared_ctx.weapon_vdata)
            return ctx.predicted_inaccuracy;

        const auto inaccuracy_stand = memory::read<float>(shared_ctx.weapon_vdata + SCHEMA("CCSWeaponBaseVData", "m_flInaccuracyStand"_hash));
        return std::max(inaccuracy_stand, g_shared.get_inaccuracy_at_velocity(local.pawn, velocity));
    }

    std::vector<rage::scan_hit> rage::scan_taser(const math::vector3& eye, const aim_context& ctx, std::vector<candidate>& candidates, const systems::local::snapshot& local) const
    {
        const auto& shared_ctx = g_shared.ctx();
        std::vector<scan_hit> results;

        for (auto& cand : candidates)
        {
            for (auto ri = 0; ri < cand.record_count; ++ri)
            {
                auto* record = cand.records[ri];
                if (!record || !record->valid)
                    continue;

                const auto game_scene_node = memory::read<std::uintptr_t>(cand.pawn + SCHEMA("C_BaseEntity", "m_pGameSceneNode"_hash));
                if (!game_scene_node)
                    continue;

                const auto hitbox_set = systems::g_hitboxes.query(game_scene_node);
                if (hitbox_set.count <= 0)
                    continue;

                record->apply();
                const auto skeleton = g_shared.lc().get_skeleton(*record);

                for (auto i = 0; i < hitbox_set.count; ++i)
                {
                    const auto& hb = hitbox_set.entries[i];
                    if (hb.bone < 0 ||
                        hb.bone >= static_cast<int>(skeleton.size()) ||
                        hb.bone >= record->bone_count)
                        continue;

                    const auto& bone = skeleton[hb.bone];
                    if (bone.position.length_sqr() < 1.0f)
                        continue;

                    const auto center = bone.rotation.rotate_vector((hb.mins + hb.maxs) * 0.5f) + bone.position;
                    const auto aim = math::helpers::calculate_angle(eye, center);
                    const auto fov = math::helpers::angle_distance(ctx.view_angles, aim);

                    if (fov > settings::g_combat.m_zeusbot.max_fov)
                        continue;

                    math::vector3 forward{};
                    math::helpers::angle_vectors_left(aim, &forward);
                    const auto trace = this->trace_taser_hit(eye, forward, shared_ctx.range * 0.85f, cand.pawn, local.pawn);

                    if (trace.hit_entity != cand.pawn)
                        continue;

                    const auto dist = (center - eye).length();
                    const auto range_fraction = dist / shared_ctx.range;

                    scan_hit h{};
                    h.position = center;
                    h.aim_angle = aim;
                    h.damage = 500.0f;
                    h.score = (10000.0f - dist) * (range_fraction > 0.92f ? 0.8f : 1.0f);
                    h.fov = fov;
                    h.hitbox_index = hb.index;
                    h.hitgroup = systems::g_hitboxes.hitgroup_from_hitbox(hb.index);
                    h.bone_index = hb.bone;
                    h.hitbox = hb;
                    h.is_center = true;
                    h.pawn = cand.pawn;
                    h.health = cand.health;
                    h.record = record;
                    results.push_back(h);
                }
                record->restore();
            }
        }
        return results;
    }

    rage::knife_info rage::get_knife_info(const systems::local::snapshot& local) const
    {
        const auto& shared_ctx = g_shared.ctx();
        const auto tick_base = memory::read<int>(local.controller + SCHEMA("CBasePlayerController", "m_nTickBase"_hash));
        const auto next_primary = memory::read<int>(shared_ctx.weapon + SCHEMA("C_BasePlayerWeapon", "m_nNextPrimaryAttackTick"_hash));
        const auto next_secondary = memory::read<int>(shared_ctx.weapon + SCHEMA("C_BasePlayerWeapon", "m_nNextSecondaryAttackTick"_hash));
        const auto last_shot_time = memory::read<float>(shared_ctx.weapon + SCHEMA("C_CSWeaponBase", "m_fLastShotTime"_hash));
        const auto cur_time = static_cast<float>(tick_base) * cstypes::tick_interval;

        return knife_info
        {
            .can_slash = tick_base >= next_primary,
            .can_stab = tick_base >= next_secondary,
            .charged = (cur_time - last_shot_time) > 0.4f,
            .armor_ratio = memory::read<float>(shared_ctx.weapon_vdata + SCHEMA("CCSWeaponBaseVData", "m_flArmorRatio"_hash))
        };
    }

    std::vector<rage::scan_hit> rage::scan_knife(const math::vector3& eye, const aim_context& ctx, const knife_info& info, std::vector<candidate>& candidates, const systems::local::snapshot& local) const
    {
        constexpr auto stab_range{ 50.0f };
        constexpr auto slash_range{ 66.0f };
        std::vector<scan_hit> results;

        for (auto& cand : candidates)
        {
            const auto eye_angles = memory::read<math::vector3>(cand.pawn + SCHEMA("C_CSPlayerPawn", "m_angEyeAngles"_hash));
            const auto hp = static_cast<float>(cand.health);
            const auto frontal_slash_dmg = this->get_knife_damage(info.charged ? 40.0f : 25.0f, cand.armor, info.armor_ratio);
            const auto frontal_stab_dmg = this->get_knife_damage(65.0f, cand.armor, info.armor_ratio);
            const auto frontal_can_kill = (info.can_slash && frontal_slash_dmg >= hp) || (info.can_stab && frontal_stab_dmg >= hp);

            for (auto ri = 0; ri < cand.record_count; ++ri)
            {
                auto* record = cand.records[ri];
                if (!record || !record->valid)
                    continue;

                const auto game_scene_node = memory::read<std::uintptr_t>(cand.pawn + SCHEMA("C_BaseEntity", "m_pGameSceneNode"_hash));
                if (!game_scene_node)
                    continue;

                const auto hitbox_set = systems::g_hitboxes.query(game_scene_node);
                if (hitbox_set.count <= 0)
                    continue;

                record->apply();
                const auto skeleton = g_shared.lc().get_skeleton(*record);

                auto backstab{ false };
                {
                    const auto delta = record->origin - systems::g_prediction.pre().origin;
                    const auto dist_2d = std::sqrtf(delta.x * delta.x + delta.y * delta.y);
                    if (dist_2d > 0.001f)
                    {
                        const auto dir_x = delta.x / dist_2d;
                        const auto dir_y = delta.y / dist_2d;
                        math::vector3 body_forward{};
                        math::helpers::angle_vectors_left(record->rotation, &body_forward);
                        math::vector3 eye_forward{};
                        math::helpers::angle_vectors_left(eye_angles, &eye_forward);

                        backstab = (dir_x * body_forward.x + dir_y * body_forward.y) > 0.475f ||
                            (dir_x * eye_forward.x + dir_y * eye_forward.y) > 0.475f;
                    }
                }

                const auto wait_for_backstab = backstab && !frontal_can_kill;

                for (auto i = 0; i < hitbox_set.count; ++i)
                {
                    const auto& hb = hitbox_set.entries[i];
                    if (hb.bone < 0 ||
                        hb.bone >= static_cast<int>(skeleton.size()) ||
                        hb.bone >= record->bone_count)
                        continue;

                    const auto& bone = skeleton[hb.bone];
                    if (bone.position.length_sqr() < 1.0f)
                        continue;

                    const auto center = bone.rotation.rotate_vector((hb.mins + hb.maxs) * 0.5f) + bone.position;
                    const auto dist = (center - eye).length();
                    const auto max_reach = info.can_slash ? slash_range : stab_range;

                    if (dist > max_reach)
                        continue;

                    const auto aim = math::helpers::calculate_angle(eye, center);
                    const auto fov = math::helpers::angle_distance(ctx.view_angles, aim);

                    if (fov > settings::g_combat.m_knifebot.max_fov)
                        continue;

                    math::vector3 forward{};
                    math::helpers::angle_vectors_left(aim, &forward);

                    for (const auto try_stab : { true, false })
                    {
                        if (try_stab && !info.can_stab)
                            continue;
                        if (!try_stab && !info.can_slash)
                            continue;

                        const auto reach = try_stab ? stab_range : slash_range;
                        if (dist > reach)
                            continue;

                        const auto raw_dmg = try_stab ? (backstab ? 180.0f : 65.0f) : (backstab ? 90.0f : (info.charged ? 40.0f : 25.0f));
                        const auto damage = this->get_knife_damage(raw_dmg, cand.armor, info.armor_ratio);
                        const auto can_kill = damage >= hp;

                        if (wait_for_backstab && !can_kill)
                            continue;

                        const auto trace = this->trace_knife_hit(eye, forward, reach, cand.pawn, local.pawn);
                        if (trace.hit_entity != cand.pawn)
                            continue;

                        const auto reach_margin = 1.0f - (dist / reach);
                        scan_hit h{};
                        h.position = center;
                        h.aim_angle = aim;
                        h.damage = damage;
                        h.score = can_kill ? (10000.0f + damage * reach_margin) : (damage * 100.0f * reach_margin);
                        h.fov = fov;
                        h.hitbox_index = hb.index;
                        h.hitgroup = systems::g_hitboxes.hitgroup_from_hitbox(hb.index);
                        h.bone_index = hb.bone;
                        h.hitbox = hb;
                        h.is_center = true;
                        h.is_backstab = backstab;
                        h.attack_type = try_stab ? 1 : 0;
                        h.pawn = cand.pawn;
                        h.health = cand.health;
                        h.record = record;
                        results.push_back(h);
                        break;
                    }
                }
                record->restore();
            }
        }
        return results;
    }

    void rage::fire_gun(systems::input::usercmd* cmd, const target& tgt, bool was_forced, const math::vector3& shoot_eye, const systems::local::snapshot& local)
    {
        this->m_firing_this_tick = false;
        if (!cmd || !tgt.hit.record || !tgt.hit.record->valid)
            return;

        const auto base = cmd->csgo_user_cmd.mutable_base();
        const auto history_size = cmd->csgo_user_cmd.input_history_size();
        if (!base || !base->mutable_viewangles() || history_size <= 0 ||
            !cmd->csgo_user_cmd.mutable_input_history(history_size - 1))
            return;

        const auto tick_base = memory::read<int>(local.controller + SCHEMA("CBasePlayerController", "m_nTickBase"_hash));
        const auto& shared_ctx = g_shared.ctx();
        const auto& config = settings::g_combat.m_ragebot.get_group(shared_ctx.weapon_type, shared_ctx.item_def_idx);
        const auto aim_punch = g_shared.get_aim_punch(local.pawn);

        auto aim_angle = config.no_spread.value ?
            math::helpers::calculate_angle(shoot_eye, tgt.hit.position) :
            tgt.hit.aim_angle;

        auto stamp_tick = tick_base;
        auto stamp_frac = 0.0f;

        if (!tgt.hit.source_eye.is_uninterpolated)
        {
            stamp_frac = tgt.hit.source_eye.player_frac + tgt.hit.source_eye.lerp_ticks_frac;
            const auto carry = static_cast<int>(std::floor(stamp_frac));
            stamp_frac -= static_cast<float>(carry);
            stamp_tick = tgt.hit.source_eye.player_tick + tgt.hit.source_eye.lerp_ticks_int + carry;
        }

        if (!std::isfinite(aim_angle.x) || !std::isfinite(aim_angle.y) ||
            !std::isfinite(aim_punch.x) || !std::isfinite(aim_punch.y))
            return;

        if (config.no_spread.value)
        {
            if (!std::isfinite(shared_ctx.inaccuracy) || shared_ctx.inaccuracy < 0.0f ||
                !std::isfinite(shared_ctx.spread) || shared_ctx.spread < 0.0f ||
                !std::isfinite(shared_ctx.recoil_index))
                return;

            // Zero angles can be a legitimate solution. Validate the resulting ray,
            // including the zero-vector fallback returned by the bounded solver.
            const auto corrected = shared_ctx.inaccuracy == 0.0f && shared_ctx.spread == 0.0f
                ? aim_angle : g_shared.find_spread_correction(aim_angle, stamp_tick);
            if (!std::isfinite(corrected.x) || !std::isfinite(corrected.y) || !std::isfinite(corrected.z))
                return;

            const auto seed = g_shared.get_spread_seed(corrected, stamp_tick);
            shared::spread_cache shot_cache{};
            shot_cache.count = 1;
            shot_cache.inaccuracy = shared_ctx.inaccuracy;
            shot_cache.spread = shared_ctx.spread;
            shot_cache.values[0] = g_shared.calculate_spread(seed, shared_ctx.inaccuracy,
                shared_ctx.spread, shared_ctx.recoil_index, shared_ctx.item_def_idx, shared_ctx.num_bullets);
            const auto sx = shot_cache.values[0].x;
            const auto sy = shot_cache.values[0].y;
            shot_cache.inv_len[0] = 1.0f / std::sqrt(1.0f + sx * sx + sy * sy);

            if (tgt.hit.bone_index < 0 || tgt.hit.bone_index >= tgt.hit.record->bone_count ||
                tgt.hit.bone_index >= 128 ||
                g_shared.calculate_hitchance(shoot_eye, corrected, tgt.hit.hitbox,
                    tgt.hit.record->bones[tgt.hit.bone_index], shot_cache) < 1.0f)
                return;

            math::vector3 forward{}, left{}, up{};
            math::helpers::angle_vectors_left(corrected, &forward, &left, &up);
            const auto& spread = shot_cache.values[0];
            const auto direction = (forward + left * spread.x + up * spread.y).normalized();
            const auto pen_ctx = g_shared.pen().prepare_target(tgt.hit.pawn, tgt.hit.record);
            shared::penetration::result pen{};
            if (!g_shared.pen().run(shoot_eye, shoot_eye + direction * shared_ctx.range,
                    pen_ctx, local.pawn, local.team, pen) ||
                pen.damage < this->get_min_damage(config, tgt.hit.health, config.min_damage_override.value) ||
                pen.hitgroup != tgt.hit.hitgroup)
                return;

            aim_angle = corrected;
        }

        this->m_firing_this_tick = true;
        g_shared.last_shoot_tick() = tick_base;

        if (settings::g_misc.m_impacts.console_log.value)
        {
            const auto hitgroup_name = systems::g_hitboxes.hitgroup_to_name(tgt.hit.hitgroup);
            const auto bt_delta = g_shared.ctx().current_tick - tgt.hit.record->tick;
            const auto is_extrap = tgt.hit.record && tgt.hit.record->extrapolated;
            logging::console::print(
                xs("[rage] shot target hp {} for {:.0f} in {} (hc {:.0f}%, bt {}t{}{})"),
                tgt.hit.health,
                tgt.hit.damage,
                hitgroup_name,
                tgt.hitchance * 100.0f,
                bt_delta,
                was_forced ? xs(", forced") : "",
                is_extrap ? xs(", extrap") : ""
            );
        }

        features::misc::g_impacts.on_boom(tgt.hit.pawn, tgt.hit.hitgroup, tgt.hit.damage, tgt.hitchance, shared_ctx.inaccuracy, shared_ctx.spread, aim_angle, shoot_eye, tgt.hit.record->tick, g_shared.lc().get_skeleton(*tgt.hit.record), was_forced);
        features::esp::player::g_chams.os().push(tgt.hit.pawn);

        const auto record_time = cstypes::tick_fraction::from_value(tgt.hit.record->simulation_time / cstypes::tick_interval);

        for (auto i = 0; i < history_size; ++i)
        {
            const auto entry = cmd->csgo_user_cmd.mutable_input_history(i);
            if (!entry)
                continue;

            if (const auto angles = entry->mutable_view_angles())
            {
                angles->set_x(aim_angle.x - aim_punch.x);
                angles->set_y(aim_angle.y - aim_punch.y);
                angles->set_z(config.no_spread.value ? aim_angle.z : 0.0f);
            }

            entry->set_render_tick_count(record_time.tick + 1);
            entry->set_render_tick_fraction(0.0f);

            if (config.no_spread.value || !tgt.hit.source_eye.is_uninterpolated)
            {
                entry->set_player_tick_count(stamp_tick);
                entry->set_player_tick_fraction(stamp_frac);
            }

            if (entry->has_sv_interp0())
            {
                const auto interp = entry->mutable_sv_interp0();
                interp->set_src_tick(-1);
                interp->set_dst_tick(-1);
                interp->set_frac(0.0f);
            }
            if (entry->has_sv_interp1())
            {
                const auto interp = entry->mutable_sv_interp1();
                interp->set_src_tick(-1);
                interp->set_dst_tick(-1);
                interp->set_frac(0.0f);
            }
            if (entry->has_cl_interp())
            {
                const auto interp = entry->mutable_cl_interp();
                interp->set_frac(0.0f);
            }
        }

        const auto quick_revolver = shared_ctx.item_def_idx == cstypes::item_definition_index::weapon_r8_revolver
            && settings::g_combat.m_autos.revolver_quick.value;
        const auto attack_button = quick_revolver ? cstypes::command_buttons::in_second_attack : cstypes::command_buttons::in_attack;

        cmd->buttons.value |= attack_button;
        cmd->buttons.value_changed |= attack_button;
        cmd->buttons.value_scroll |= attack_button;

        if (history_size > 0)
        {
            if (quick_revolver)
            {
                cmd->csgo_user_cmd.set_attack2_start_history_index(history_size - 1);
                cmd->csgo_user_cmd.set_attack1_start_history_index(-1);
            }
            else
            {
                cmd->csgo_user_cmd.set_attack1_start_history_index(history_size - 1);
            }
        }

        math::vector3 forward{};
        {
            if (const auto angles = base->viewangles())
                math::helpers::angle_vectors_left({ angles->x(), angles->y(), angles->z() }, &forward);
        }

        // The solver uses roll for every weapon, not only quick revolver shots.
        const auto carry_roll_in_command = config.no_spread.value;
        const auto punched_aim = math::vector3{
            aim_angle.x - aim_punch.x,
            aim_angle.y - aim_punch.y,
            carry_roll_in_command ? aim_angle.z : 0.0f
        };

        const auto facing_away = forward.dot((tgt.hit.record->origin - systems::g_prediction.pre().networked_origin).normalized()) < 0.707107f;
        auto command_aim = punched_aim;

        if (settings::g_combat.m_antiaim.enabled.value && facing_away && settings::g_combat.m_antiaim.hide_shots.value)
        {
            command_aim.x = 179.9f;
            command_aim.y = std::remainderf(punched_aim.y + 180.0f, 360.0f);
        }

        if (const auto angles = base->mutable_viewangles())
        {
            angles->set_x(command_aim.x);
            angles->set_y(command_aim.y);
            angles->set_z(command_aim.z);
        }

        if (!config.silent.value)
            systems::g_input.set_view_angles(punched_aim);
    }

    void rage::fire_melee(systems::input::usercmd* cmd, const target& tgt, const systems::local::snapshot& local)
    {
        if (!tgt.hit.record || !tgt.hit.record->valid)
            return;

        this->m_firing_this_tick = true;
        const auto base = cmd->csgo_user_cmd.mutable_base();
        const auto tick_base = memory::read<int>(local.controller + SCHEMA("CBasePlayerController", "m_nTickBase"_hash));
        g_shared.last_shoot_tick() = tick_base;

        const auto record_time = cstypes::tick_fraction::from_value(tgt.hit.record->simulation_time / cstypes::tick_interval);
        const auto history_index = cmd->csgo_user_cmd.input_history_size() - 1;
        const auto entry = history_index >= 0 ? cmd->csgo_user_cmd.mutable_input_history(history_index) : nullptr;

        if (entry)
        {
            if (const auto angles = entry->mutable_view_angles())
            {
                angles->set_x(tgt.hit.aim_angle.x);
                angles->set_y(tgt.hit.aim_angle.y);
            }
            entry->set_render_tick_count(record_time.tick + 1);
            entry->set_render_tick_fraction(0.0f);

            if (!tgt.hit.source_eye.is_uninterpolated)
            {
                auto tick_add = [](int t, float f, int tick_delta, float frac_delta)
                    {
                        f += frac_delta;
                        auto carry = static_cast<int>(std::floor(f));
                        f -= static_cast<float>(carry);
                        return std::pair{ t + tick_delta + carry, f };
                    };
                const auto [stamp_tick, stamp_frac] = tick_add(tgt.hit.source_eye.player_tick, tgt.hit.source_eye.player_frac, tgt.hit.source_eye.lerp_ticks_int, tgt.hit.source_eye.lerp_ticks_frac);
                entry->set_player_tick_count(stamp_tick);
                entry->set_player_tick_fraction(stamp_frac);
            }

            if (entry->has_sv_interp0())
            {
                const auto interp = entry->mutable_sv_interp0();
                interp->set_src_tick(-1);
                interp->set_dst_tick(-1);
                interp->set_frac(0.0f);
            }
            if (entry->has_sv_interp1())
            {
                const auto interp = entry->mutable_sv_interp1();
                interp->set_src_tick(-1);
                interp->set_dst_tick(-1);
                interp->set_frac(0.0f);
            }
            if (entry->has_cl_interp())
            {
                const auto interp = entry->mutable_cl_interp();
                interp->set_frac(0.0f);
            }
        }

        const auto is_secondary = tgt.hit.attack_type == 1;
        const auto attack_button = is_secondary ? cstypes::command_buttons::in_second_attack : cstypes::command_buttons::in_attack;

        cmd->buttons.value |= attack_button;
        cmd->buttons.value_changed |= attack_button;
        cmd->buttons.value_scroll |= attack_button;

        if (history_index >= 0)
        {
            if (is_secondary)
                cmd->csgo_user_cmd.set_attack2_start_history_index(history_index);
            else
                cmd->csgo_user_cmd.set_attack1_start_history_index(history_index);
        }

        if (const auto angles = base->mutable_viewangles())
        {
            angles->set_x(tgt.hit.aim_angle.x);
            angles->set_y(tgt.hit.aim_angle.y);
        }
    }

    rage::multipoint_result rage::generate_multipoints(const systems::hitboxes::entry& hitbox, const math::vector3& center, const math::quaternion& bone_rot, float pointscale, const math::vector3& shoot_pos, float inaccuracy) const
    {
        multipoint_result out{};
        auto scale = std::clamp(pointscale / 100.0f, 0.0f, 1.0f);
        if (scale <= 0.01f)
            return out;

        const auto hb_mid = (hitbox.mins + hitbox.maxs) * 0.5f;
        const auto capsule_a = center + bone_rot.rotate_vector(hitbox.mins - hb_mid);
        const auto capsule_b = center + bone_rot.rotate_vector(hitbox.maxs - hb_mid);

        // Dynamic pointscale based on spread cone
        const auto& config = settings::g_combat.m_ragebot.get_group(g_shared.ctx().weapon_type, g_shared.ctx().item_def_idx);
        if (config.dynamic_pointscale.value && hitbox.radius > 0.001f)
        {
            const auto cone = std::max(inaccuracy + g_shared.ctx().spread, 0.0f);
            const auto cone_radius = std::tanf(cone) * (center - shoot_pos).length();
            const auto automatic_scale = std::clamp(0.9f - cone_radius / hitbox.radius, 0.0f, 1.0f);
            scale = std::min(scale, automatic_scale);
            if (scale <= 0.01f)
                return out;
        }

        // Build view-relative frame
        const auto shoot_dir = (center - shoot_pos).normalized();
        const auto ang = math::helpers::vector_to_angle(shoot_dir);
        math::vector3 left{}, up{};
        math::helpers::angle_vectors_left(ang, nullptr, &left, &up);
        const auto right = math::vector3{ -left.x, -left.y, -left.z };

        // Trace from outside through center to find real capsule surface
        const auto surface_point = [&](const math::vector3& direction) -> math::vector3
            {
                const auto dir = direction.normalized();
                if (hitbox.radius > 0.001f)
                {
                    const auto reach = (capsule_b - capsule_a).length() + hitbox.radius * 2.0f + 1.0f;
                    const auto origin = center + dir * reach;
                    const auto delta = dir * (reach * -2.0f);
                    auto fraction{ 1.0f };
                    if (g_shared.ray_vs_capsule(origin, delta, capsule_a, capsule_b, hitbox.radius, fraction))
                        return origin + delta * fraction;
                }
                else
                {
                    // Box hitbox intersection
                    auto inverse = bone_rot;
                    inverse.x = -inverse.x;
                    inverse.y = -inverse.y;
                    inverse.z = -inverse.z;
                    const auto local_dir = inverse.rotate_vector(dir);
                    const auto extents = (hitbox.maxs - hitbox.mins) * 0.5f;
                    auto distance = 8192.0f;
                    if (std::fabs(local_dir.x) > 1.0e-6f) distance = std::min(distance, std::fabs(extents.x / local_dir.x));
                    if (std::fabs(local_dir.y) > 1.0e-6f) distance = std::min(distance, std::fabs(extents.y / local_dir.y));
                    if (std::fabs(local_dir.z) > 1.0e-6f) distance = std::min(distance, std::fabs(extents.z / local_dir.z));
                    if (distance < 8192.0f)
                        return center + dir * distance;
                }
                return center;
            };

        const auto scaled_surface = [&](const math::vector3& direction)
            {
                const auto surface = surface_point(direction);
                return center + (surface - center) * scale;
            };

        const auto add = [&](const math::vector3& pt)
            {
                if (out.count < k_max_multipoints)
                    out.points[out.count++] = pt;
            };

        switch (hitbox.index)
        {
        case 0: // Head
            add(scaled_surface(right));
            add(scaled_surface(-right));
            add(scaled_surface(up));
            add(scaled_surface(-up));
            break;
        case 2: case 3: // Stomach/Pelvis
            add(scaled_surface(right));
            add(scaled_surface(-right));
            break;
        case 4: case 5: case 6: // Chest
            add(scaled_surface(right));
            add(scaled_surface(-right));
            if (hitbox.index == 6)
                add(scaled_surface(up));
            break;
        case 7: case 8: case 9: case 10: case 11: case 12: // Legs/Feet
            add(capsule_a);
            add(capsule_b);
            break;
        case 13: case 14: case 15: case 16: case 17: case 18: // Arms
            add(capsule_b);
            break;
        default:
            add(scaled_surface(right));
            add(scaled_surface(-right));
            break;
        }
        return out;
    }

    bool rage::should_stop_movement(const aim_context& ctx) const
    {
        const auto& shared_ctx = g_shared.ctx();
        const auto& prestate = systems::g_prediction.pre();
        const auto velocity = prestate.networked_velocity;

        if (shared_ctx.weapon_type == cstypes::weapon_type::sniper && !ctx.is_scoped)
            return false;

        if (ctx.on_ground)
        {
            const auto speed_2d = velocity.length_2d();
            if (speed_2d <= 0.1f)
                return false;

            const auto inaccuracy_move = memory::read<float>(shared_ctx.weapon_vdata + SCHEMA("CCSWeaponBaseVData", "m_flInaccuracyMove"_hash));
            const auto inaccuracy_stand = memory::read<float>(shared_ctx.weapon_vdata + SCHEMA("CCSWeaponBaseVData", "m_flInaccuracyStand"_hash));
            return speed_2d * inaccuracy_move > inaccuracy_stand;
        }

        // Air stop logic for snipers
        if (shared_ctx.weapon_type != cstypes::weapon_type::sniper)
            return false;

        if (velocity.z > 140.0f)
            return false;

        const auto sv_gravity = CONVAR("sv_gravity")->get<float>();
        const auto sv_friction = CONVAR("sv_friction")->get<float>();
        const auto sv_stopspeed = CONVAR("sv_stopspeed")->get<float>();
        const auto inac_jump_initial = memory::read<float>(shared_ctx.weapon_vdata + SCHEMA("CCSWeaponBaseVData", "m_flInaccuracyJumpInitial"_hash));
        const auto inac_jump_apex = memory::read<float>(shared_ctx.weapon_vdata + SCHEMA("CCSWeaponBaseVData", "m_flInaccuracyJumpApex"_hash));

        const auto shootable_threshold = inac_jump_apex + 0.001f;
        const auto early_threshold = inac_jump_initial * 0.55f + inac_jump_apex * 0.45f;
        const auto air_inaccuracy = g_shared.get_air_inaccuracy(velocity.z, inac_jump_initial, inac_jump_apex);

        if (air_inaccuracy <= shootable_threshold || air_inaccuracy <= early_threshold)
            return true;

        auto sim_vz = velocity.z;
        auto ticks_to_shootable{ 0 };
        for (auto i = 1; i <= 32; ++i)
        {
            sim_vz -= sv_gravity * cstypes::tick_interval;
            if (g_shared.get_air_inaccuracy(sim_vz, inac_jump_initial, inac_jump_apex) <= shootable_threshold)
            {
                ticks_to_shootable = i;
                break;
            }
        }

        if (ticks_to_shootable == 0)
            return false;

        const auto speed_2d = velocity.length_2d();
        const auto max_speed = memory::read<float>(shared_ctx.weapon_vdata + SCHEMA("CCSWeaponBaseVData", "m_flMaxSpeed"_hash));
        const auto accurate_threshold = max_speed * 0.34f;

        if (speed_2d <= accurate_threshold)
            return true;

        auto sim_speed = speed_2d;
        auto ticks_to_stop{ 32 };
        for (auto i = 1; i <= 32; ++i)
        {
            const auto drop = std::fmaxf(sim_speed, sv_stopspeed) * sv_friction * cstypes::tick_interval;
            sim_speed -= drop;
            if (sim_speed <= accurate_threshold)
            {
                ticks_to_stop = i;
                break;
            }
        }

        return ticks_to_shootable <= ticks_to_stop + 2;
    }

    float rage::get_min_damage(const settings::combat::ragebot::weapon_group& config, int target_health, bool override_active) const
    {
        if (override_active)
            return static_cast<float>(config.min_damage_override_value);

        const auto base = static_cast<float>(config.min_damage);
        const auto hp = static_cast<float>(target_health);
        if (hp < base)
            return hp + 1.0f;
        return base;
    }

    float rage::get_knife_damage(float raw, int armor, float armor_ratio) const
    {
        if (armor <= 0)
            return raw;

        const auto ratio = armor_ratio * 0.5f;
        auto damage_to_health = raw * ratio;
        const auto damage_to_armor = (raw - damage_to_health) * 0.5f;

        if (damage_to_armor > static_cast<float>(armor))
            damage_to_health = raw - static_cast<float>(armor) * 2.0f;

        return std::max(0.0f, std::floorf(damage_to_health));
    }

    systems::tracing::result rage::trace_taser_hit(const math::vector3& origin, const math::vector3& forward, float range, std::uintptr_t target_pawn, std::uintptr_t local_pawn) const
    {
        const auto end = origin + forward * range;
        const int filter_extras[]{ 0, 15 };

        for (const auto extra : filter_extras)
        {
            const auto filter = extra == 0 ?
                systems::g_tracing.make_filter(local_pawn, 0x001c1003, 4) :
                systems::g_tracing.make_filter(local_pawn, 0x001c1003, 4, 15);

            auto result = systems::g_tracing.trace(origin, end, filter);
            if ((result.fraction < 1.0f || result.all_solid) && result.hit_entity == target_pawn)
                return result;

            for (auto radius = 2.0f; radius <= 4.0f; radius += 2.0f)
            {
                const auto sweep_end = end - forward * radius;
                result = systems::g_tracing.trace_sphere(origin, sweep_end, radius, filter);
                if ((result.fraction < 1.0f || result.all_solid) && result.hit_entity == target_pawn)
                    return result;
            }
        }

        systems::tracing::result miss{};
        miss.fraction = 1.0f;
        miss.hit_entity = 0;
        return miss;
    }

    systems::tracing::result rage::trace_knife_hit(const math::vector3& origin, const math::vector3& forward, float reach, std::uintptr_t target_pawn, std::uintptr_t local_pawn) const
    {
        const auto end = origin + forward * reach;
        const auto knife_filter = systems::g_tracing.make_filter(local_pawn, 0x0c3001, 4);

        auto result = systems::g_tracing.trace(origin, end, knife_filter);
        if ((result.fraction < 1.0f || result.all_solid) && result.hit_entity == target_pawn)
            return result;

        const auto weapon_filter = systems::g_tracing.make_filter(local_pawn, 0x0c3001, 4, 15);
        result = systems::g_tracing.trace(origin, end, weapon_filter);
        if ((result.fraction < 1.0f || result.all_solid) && result.hit_entity == target_pawn)
            return result;

        for (auto radius = 14.0f; radius > 0.0f; radius -= 3.0f)
        {
            const auto sweep_end = end - forward * radius;
            result = systems::g_tracing.trace_sphere(origin, sweep_end, radius, weapon_filter);
            if ((result.fraction < 1.0f || result.all_solid) && result.hit_entity == target_pawn)
                return result;
        }

        result.fraction = 1.0f;
        result.hit_entity = 0;
        return result;
    }

    void rage::update_penetration_crosshair(const systems::local::snapshot& local)
    {
        const auto& cfg = settings::g_combat.m_penetration_crosshair;
        const auto& ctx = g_shared.ctx();

        if (!cfg.enabled.value || !ctx.valid || !local.is_alive || local.team < 2
            || !local.pawn || !ctx.weapon
            || ctx.weapon_type < cstypes::weapon_type::pistol || ctx.weapon_type > cstypes::weapon_type::lmg)
        {
            this->m_penetration_crosshair_state.store(penetration_crosshair_state::unavailable, std::memory_order_relaxed);
            return;
        }

        const auto eye_pos = g_shared.get_eye_position(local.pawn);
        auto view_angles = systems::g_input.get_view_angles();
        const auto aim_punch = g_shared.get_aim_punch(local.pawn);
        view_angles.x += aim_punch.x;
        view_angles.y += aim_punch.y;

        static math::vector3 last_eye{};
        static math::vector3 last_angles{};
        if (eye_pos.distance_sqr(last_eye) < 0.25f &&
            std::fabsf(view_angles.x - last_angles.x) < 0.05f &&
            std::fabsf(view_angles.y - last_angles.y) < 0.05f)
        {
            return;
        }
        last_eye = eye_pos;
        last_angles = view_angles;

        math::vector3 forward{};
        math::helpers::angle_vectors_left(view_angles, &forward);

        auto pen_damage{ 0.0f };
        const auto can_pen = g_shared.pen().can(eye_pos, forward, pen_damage, local);

        this->m_penetration_crosshair_state.store(
            can_pen ? penetration_crosshair_state::penetrable : penetration_crosshair_state::blocked,
            std::memory_order_relaxed);
    }

    void rage::draw_penetration_crosshair(xdraw::draw_list& draw_list) const
    {
        const auto& cfg = settings::g_combat.m_penetration_crosshair;
        if (!cfg.enabled.value)
            return;

        const auto state = this->m_penetration_crosshair_state.load(std::memory_order_relaxed);
        const auto local = systems::g_local.get();

        if (state == penetration_crosshair_state::unavailable || !local.is_alive || systems::g_local.is_in_cinematic())
            return;

        const auto can_pen = state == penetration_crosshair_state::penetrable;
        const auto& fill = can_pen ? cfg.can_penetrate_fill : cfg.blocked_fill;
        const auto& outline = can_pen ? cfg.can_penetrate_outline : cfg.blocked_outline;

        const auto [screen_w, screen_h] = xdraw::viewport_size();
        const auto cx = std::floorf(static_cast<float>(screen_w) * 0.5f);
        const auto cy = std::floorf(static_cast<float>(screen_h) * 0.5f);

        constexpr auto half_size{ 3.0f };
        constexpr auto outline_size{ 1.0f };

        if (cfg.glow)
        {
            auto& glow = xdraw::get_glow();
            const auto glow_a = static_cast<std::uint8_t>(static_cast<float>(outline.value.a) * cfg.glow_strength);
            const auto glow_col = xdraw::color{ outline.value.r, outline.value.g, outline.value.b, glow_a };
            glow.rect_filled(cx - half_size - outline_size, cy - half_size - outline_size,
                (half_size + outline_size) * 2.0f, (half_size + outline_size) * 2.0f, glow_col);
        }

        draw_list.rect_filled(cx - half_size - outline_size, cy - half_size - outline_size,
            (half_size + outline_size) * 2.0f, (half_size + outline_size) * 2.0f, outline);
        draw_list.rect_filled(cx - half_size, cy - half_size, half_size * 2.0f, half_size * 2.0f, fill);
    }

} // namespace features::combat