#include <pch/pch.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <core/systems/systems.hpp>
#include <core/features/features.hpp>
#include <core/settings.hpp>
#include <utilities/steam/steam.hpp>
#include <protection/game_addresses.hpp>
#include <utilities/cosmetic_model.hpp>
namespace features::changer {

	namespace detail {

		inline static std::uint32_t murmurhash2_lower( const char* str, int len, std::uint32_t seed )
		{
			constexpr auto m{ 0x5bd1e995 };
			constexpr auto r{ 24 };

			auto h = seed ^ len;
			auto i{ 0 };

			while ( len >= 4 )
			{
				auto k =
					static_cast< std::uint32_t >( ( str[ i ] >= 'A' && str[ i ] <= 'Z' ) ? str[ i ] + 32 : str[ i ] ) |
					( static_cast< std::uint32_t >( ( str[ i + 1 ] >= 'A' && str[ i + 1 ] <= 'Z' ) ? str[ i + 1 ] + 32 : str[ i + 1 ] ) << 8 ) |
					( static_cast< std::uint32_t >( ( str[ i + 2 ] >= 'A' && str[ i + 2 ] <= 'Z' ) ? str[ i + 2 ] + 32 : str[ i + 2 ] ) << 16 ) |
					( static_cast< std::uint32_t >( ( str[ i + 3 ] >= 'A' && str[ i + 3 ] <= 'Z' ) ? str[ i + 3 ] + 32 : str[ i + 3 ] ) << 24 );

				k *= m;
				k ^= k >> r;
				k *= m;

				h *= m;
				h ^= k;

				i += 4;
				len -= 4;
			}

			switch ( len )
			{
			case 3: h ^= static_cast< std::uint32_t >( ( str[ i + 2 ] >= 'A' && str[ i + 2 ] <= 'Z' ) ? str[ i + 2 ] + 32 : str[ i + 2 ] ) << 16; [[fallthrough]];
			case 2: h ^= static_cast< std::uint32_t >( ( str[ i + 1 ] >= 'A' && str[ i + 1 ] <= 'Z' ) ? str[ i + 1 ] + 32 : str[ i + 1 ] ) << 8; [[fallthrough]];
			case 1: h ^= static_cast< std::uint32_t >( ( str[ i ] >= 'A' && str[ i ] <= 'Z' ) ? str[ i ] + 32 : str[ i ] ); h *= m;
			}

			h ^= h >> 13;
			h *= m;
			h ^= h >> 15;

			return h;
		}

		inline static std::uint32_t make_subclass_token( std::int16_t def_index )
		{
			const auto s = std::to_string( def_index );
			return murmurhash2_lower( s.c_str( ), static_cast< int >( s.length( ) ), 0x31415926 );
		}

	} // namespace detail

	void knives::on_frame_stage_notify( )
	{
		this->process_hud_clear( );

		const auto local = systems::g_local.get( );
		if ( !local.is_alive || systems::g_local.is_in_cinematic( ) || !local.pawn || !local.controller )
		{
			return;
		}

		const auto local_ctrl = local.controller;
		const auto local_pawn = local.pawn;
		const auto local_team = memory::read<int>( local_pawn + SCHEMA( "C_BaseEntity", "m_iTeamNum"_hash ) );

		if ( true )
		{
			const auto weapon_services = memory::read<std::uintptr_t>( local_pawn + SCHEMA( "C_BasePlayerPawn", "m_pWeaponServices"_hash ) );
			if ( weapon_services )
			{
				const settings::changer::applied_skin* selected_skin{ nullptr };
				const econ_item_system::item_def* selected_knife_def{ nullptr };

				for ( const auto& [def_idx, skin] : settings::g_changer.skins.for_team( local_team ) )
				{
					const auto def = g_econ_item_system.find_def( def_idx );
					if ( !def || def->category != econ_item_system::item_category::knife )
					{
						continue;
					}

					selected_skin = &skin;
					selected_knife_def = def;
					break;
				}

				const auto weapons_base = weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hMyWeapons"_hash );
				const auto weapons_size = memory::read<int>( weapons_base );
				const auto weapons_data = memory::read<std::uintptr_t>( weapons_base + 0x8 );

				if ( weapons_data && weapons_size > 0 )
				{
					const auto active_handle = memory::read<std::uint32_t>( weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hActiveWeapon"_hash ) );
					const auto active_weapon = systems::g_entities.lookup( active_handle );

					if ( this->m_tracked_pawn != local_pawn )
					{
						this->m_original = {};
						this->m_overridden = false;
						this->m_last_active_handle = 0;
						this->m_tracked_pawn = local_pawn;
					}

					for ( auto i = 0; i < weapons_size; ++i )
					{
						const auto handle = memory::read<std::uint32_t>( weapons_data + i * sizeof( std::uint32_t ) );
						const auto weapon = systems::g_entities.lookup( handle );

						if ( !weapon )
						{
							continue;
						}

						const auto iv = weapon + SCHEMA( "C_EconEntity", "m_AttributeManager"_hash ) + SCHEMA( "C_AttributeContainer", "m_Item"_hash );
						const auto current_def_index = memory::read<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ) );
						const auto current_def = g_econ_item_system.find_def( static_cast< std::int16_t >( current_def_index ) );

						if ( !current_def || current_def->category != econ_item_system::item_category::knife )
						{
							continue;
						}

						if ( !memory::read<std::uintptr_t>( weapon + SCHEMA( "C_BaseEntity", "m_nSubclassID"_hash ) + 0x8 ) )
						{
							continue;
						}

						if ( this->m_tracked_weapon_handle != handle )
						{
							this->m_original = {};
							this->m_overridden = false;
							this->m_tracked_weapon_handle = handle;
						}

						if ( !selected_knife_def )
						{
							this->restore( weapon, iv, active_weapon, local_pawn );
							break;
						}

						if ( !this->m_overridden )
						{
							this->capture_original( weapon, iv );
						}

						if (!this->m_original.captured) continue;
						const auto normalized_skin = cosmetic_attributes::normalize(*selected_skin);
						selected_skin = &normalized_skin;
						const auto target_token = detail::make_subclass_token( selected_knife_def->def_index );
						const auto current_subclass = memory::read<std::uint32_t>( weapon + SCHEMA( "C_BaseEntity", "m_nSubclassID"_hash ) );
						const auto current_pk = memory::read<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ) );

						if ( this->m_overridden && current_def_index == static_cast<std::uint16_t>( selected_knife_def->def_index )
							&& cosmetic_attributes::matches( iv, *selected_skin )
							&& current_subclass == target_token && current_pk == selected_skin->paint_kit_id
							&& memory::read<int>(weapon + SCHEMA("C_EconEntity", "m_nFallbackSeed"_hash)) == selected_skin->seed
							&& memory::read<float>(weapon + SCHEMA("C_EconEntity", "m_flFallbackWear"_hash)) == selected_skin->wear
							&& name_tag::matches(iv, selected_skin->name_tag)
							&& memory::read<int>(weapon + SCHEMA("C_EconEntity", "m_nFallbackStatTrak"_hash)) == (selected_skin->stattrak ? selected_skin->stattrak_count : -1) )
						{
							break;
						}

						auto steam_id = steam::user::get_steam_id( );
						if ( !steam_id && local_ctrl )
						{
							steam_id = memory::read<std::uint64_t>( local_ctrl + SCHEMA( "CBasePlayerController", "m_steamID"_hash ) );
						}
						const auto account_id = static_cast< std::uint32_t >( steam_id & 0xffffffff );

						this->apply( weapon, iv, selected_knife_def, selected_skin, account_id, active_weapon, local_pawn );
						break;
					}

					// A HUD weapon may be created AFTER the first apply without changing
					// m_hActiveWeapon. Reconcile it even when that handle is unchanged.
					{
						this->m_last_active_handle = active_handle;

						if ( this->m_overridden && active_weapon )
						{
							const auto iv = active_weapon + SCHEMA( "C_EconEntity", "m_AttributeManager"_hash ) + SCHEMA( "C_AttributeContainer", "m_Item"_hash );
							const auto def_index = memory::read<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ) );
							const auto def = g_econ_item_system.find_def( static_cast< std::int16_t >( def_index ) );

							if ( def && def->category == econ_item_system::item_category::knife )
							{
								const auto paint_kit_id = memory::read<int>( active_weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ) );
								const auto pk = g_econ_item_system.find_paint_kit( paint_kit_id );
								this->update_view_model( local_pawn, pk );
							}
						}
					}
				}
			}
		}

		// Apply synced knives for remote players
		const auto all_players = systems::g_entities.get_by_type( systems::entities::type::player );
		for ( const auto& p : all_players )
		{
			const auto ctrl = p.ptr;
			if ( !ctrl || ctrl == local_ctrl )
			{
				continue;
			}

			const auto sid = memory::safe_read<std::uint64_t>( ctrl + SCHEMA( "CBasePlayerController", "m_steamID"_hash ) ).value_or( 0 );
			constexpr std::uint64_t steam_id_base = 76561197960265728ull;
			if ( sid < steam_id_base && !g_skin_sync.m_bot_sync_test.load( ) )
			{
				continue;
			}

			const auto remote_skin_data = g_skin_sync.get_remote_skin( sid );
			if ( !remote_skin_data || remote_skin_data->skins.empty( ) )
			{
				continue;
			}

			settings::changer::applied_skin remote_knife_skin{};
			const econ_item_system::item_def* remote_knife_def{ nullptr };
			bool has_knife_skin{ false };
			for ( const auto& [def_idx, skin] : remote_skin_data->skins )
			{
				const auto def = g_econ_item_system.find_def( def_idx );
				if ( def && def->category == econ_item_system::item_category::knife )
				{
					remote_knife_skin = cosmetic_attributes::normalize( skin );
					remote_knife_def = def;
					has_knife_skin = true;
					break;
				}
			}

			if ( !remote_knife_def || !has_knife_skin )
			{
				continue;
			}

			const auto pawn_handle = memory::safe_read<std::uint32_t>( ctrl + SCHEMA( "CBasePlayerController", "m_hPawn"_hash ) ).value_or( 0 );
			if ( !pawn_handle )
			{
				continue;
			}

			const auto pawn = systems::g_entities.lookup( pawn_handle );
			if ( !pawn || pawn < 0x10000 )
			{
				continue;
			}

			const auto remote_weapon_services = memory::safe_read<std::uintptr_t>( pawn + SCHEMA( "C_BasePlayerPawn", "m_pWeaponServices"_hash ) ).value_or( 0 );
			if ( !remote_weapon_services )
			{
				continue;
			}

			const auto remote_weapons_base = remote_weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hMyWeapons"_hash );
			const auto remote_weapons_size = memory::safe_read<int>( remote_weapons_base ).value_or( 0 );
			const auto remote_weapons_data = memory::safe_read<std::uintptr_t>( remote_weapons_base + 0x8 ).value_or( 0 );
			if ( !remote_weapons_data || remote_weapons_size <= 0 )
			{
				continue;
			}

			const auto remote_active_handle = memory::safe_read<std::uint32_t>( remote_weapon_services + SCHEMA( "CPlayer_WeaponServices", "m_hActiveWeapon"_hash ) ).value_or( 0 );
			const auto remote_active_weapon = systems::g_entities.lookup( remote_active_handle );
			const auto remote_account_id = static_cast< std::uint32_t >( sid & 0xffffffff );

			for ( auto i = 0; i < remote_weapons_size; ++i )
			{
				const auto handle = memory::safe_read<std::uint32_t>( remote_weapons_data + i * sizeof( std::uint32_t ) ).value_or( 0 );
				if ( !handle )
				{
					continue;
				}

				const auto weapon = systems::g_entities.lookup( handle );
				if ( !weapon || weapon < 0x10000 )
				{
					continue;
				}

				const auto iv = weapon + SCHEMA( "C_EconEntity", "m_AttributeManager"_hash ) + SCHEMA( "C_AttributeContainer", "m_Item"_hash );
				const auto current_def_index = memory::read<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ) );
				const auto current_def = g_econ_item_system.find_def( static_cast< std::int16_t >( current_def_index ) );
				if ( !current_def || current_def->category != econ_item_system::item_category::knife )
				{
					continue;
				}

				const auto target_token = detail::make_subclass_token( remote_knife_def->def_index );
				const auto current_subclass = memory::safe_read<std::uint32_t>( weapon + SCHEMA( "C_BaseEntity", "m_nSubclassID"_hash ) ).value_or( 0 );
				const auto current_pk = memory::safe_read<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ) ).value_or( 0 );

				if ( current_def_index == static_cast<std::uint16_t>( remote_knife_def->def_index ) &&
					current_subclass == target_token && current_pk == remote_knife_skin.paint_kit_id &&
					cosmetic_attributes::matches( iv, remote_knife_skin ) && name_tag::matches( iv, remote_knife_skin.name_tag ) )
				{
					break;
				}

				this->apply( weapon, iv, remote_knife_def, &remote_knife_skin, remote_account_id, remote_active_weapon, pawn );
				break;
			}
		}
	}

	void knives::capture_original( std::uintptr_t weapon, std::uintptr_t iv )
	{
		if ( this->m_original.captured )
		{
			return;
		}

		if (!cosmetic_attributes::capture(iv, this->m_original.attributes)) return;
        this->m_original.custom_name = name_tag::capture(iv);
        this->m_original.item_id = memory::read<std::uint64_t>(iv + SCHEMA("C_EconItemView", "m_iItemID"_hash));
        this->m_original.quality = memory::read<int>(iv + SCHEMA("C_EconItemView", "m_iEntityQuality"_hash));
        this->m_original.disallow_soc = memory::read<bool>(iv + SCHEMA("C_EconItemView", "m_bDisallowSOC"_hash));
		this->m_original.def_index = memory::read<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ) );
		this->m_original.id_high = memory::read<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDHigh"_hash ) );
		this->m_original.id_low = memory::read<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDLow"_hash ) );
		this->m_original.account_id = memory::read<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iAccountID"_hash ) );
		this->m_original.initialized = memory::read<bool>( iv + SCHEMA( "C_EconItemView", "m_bInitialized"_hash ) );
		this->m_original.paint_kit = memory::read<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ) );
		this->m_original.seed = memory::read<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackSeed"_hash ) );
		this->m_original.wear = memory::read<float>( weapon + SCHEMA( "C_EconEntity", "m_flFallbackWear"_hash ) );
		this->m_original.stattrak = memory::read<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackStatTrak"_hash ) );
		this->m_original.captured = true;
	}

	void knives::apply( std::uintptr_t weapon, std::uintptr_t iv, const econ_item_system::item_def* def, const settings::changer::applied_skin* skin, std::uint32_t account_id, std::uintptr_t active_weapon, std::uintptr_t pawn )
	{
		this->m_pending_hud_iv = 0;
        if (!cosmetic_attributes::available()) return;
        if (!skin->name_tag.empty() && !name_tag::offsets()) return;
        const auto model_changed =
            memory::read<std::uint16_t>(iv + SCHEMA("C_EconItemView", "m_iItemDefinitionIndex"_hash)) != static_cast<std::uint16_t>(def->def_index)
            || memory::read<std::uint32_t>(weapon + SCHEMA("C_BaseEntity", "m_nSubclassID"_hash)) != detail::make_subclass_token(def->def_index);
        memory::write<std::uint64_t>(iv + SCHEMA("C_EconItemView", "m_iItemID"_hash), 0xf000000000000010ull);
        memory::write<bool>(iv + SCHEMA("C_EconItemView", "m_bDisallowSOC"_hash), true);
        memory::write<int>(iv + SCHEMA("C_EconItemView", "m_iEntityQuality"_hash), skin->stattrak ? 9 : 3);

		memory::write<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ), static_cast< std::uint16_t >( def->def_index ) );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDHigh"_hash ), 0xf0000000 );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDLow"_hash ), 0x10 );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iAccountID"_hash ), account_id );
		memory::write<bool>( iv + SCHEMA( "C_EconItemView", "m_bInitialized"_hash ), true );

		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ), skin->paint_kit_id );
		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackSeed"_hash ), skin->seed );
		memory::write<float>( weapon + SCHEMA( "C_EconEntity", "m_flFallbackWear"_hash ), skin->wear );
		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackStatTrak"_hash ), skin->stattrak ? skin->stattrak_count : -1 );

		const auto pk = g_econ_item_system.find_paint_kit( skin->paint_kit_id );

		if (model_changed)
            this->update_model( weapon, iv, static_cast< std::uint16_t >( def->def_index ) );
        if (!cosmetic_attributes::apply(iv, *skin)) return;
        // Subclass/model changes may rebuild the item view; set its name afterwards.
        if (!name_tag::apply(iv, skin->name_tag)) return;
		this->rebuild_paint( weapon, active_weapon, pawn, pk );
		this->schedule_hud_clear( iv );

		// A remote knife update must not mark the local original as overridden.
		if ( pawn == systems::g_local.get( ).pawn ) this->m_overridden = true;
	}

	void knives::restore( std::uintptr_t weapon, std::uintptr_t iv, std::uintptr_t active_weapon, std::uintptr_t pawn )
	{
		if ( !this->m_overridden || !this->m_original.captured )
		{
			return;
		}

		this->m_pending_hud_iv = 0;
        if (!cosmetic_attributes::restore(iv, this->m_original.attributes)) return;
        if (this->m_original.custom_name && !name_tag::restore(iv, *this->m_original.custom_name)) return;
        memory::write<std::uint64_t>(iv + SCHEMA("C_EconItemView", "m_iItemID"_hash), this->m_original.item_id);
        memory::write<bool>(iv + SCHEMA("C_EconItemView", "m_bDisallowSOC"_hash), this->m_original.disallow_soc);
        memory::write<int>(iv + SCHEMA("C_EconItemView", "m_iEntityQuality"_hash), this->m_original.quality);

		memory::write<std::uint16_t>( iv + SCHEMA( "C_EconItemView", "m_iItemDefinitionIndex"_hash ), this->m_original.def_index );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDHigh"_hash ), this->m_original.id_high );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iItemIDLow"_hash ), this->m_original.id_low );
		memory::write<std::uint32_t>( iv + SCHEMA( "C_EconItemView", "m_iAccountID"_hash ), this->m_original.account_id );
		memory::write<bool>( iv + SCHEMA( "C_EconItemView", "m_bInitialized"_hash ), this->m_original.initialized );

		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackPaintKit"_hash ), this->m_original.paint_kit );
		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackSeed"_hash ), this->m_original.seed );
		memory::write<float>( weapon + SCHEMA( "C_EconEntity", "m_flFallbackWear"_hash ), this->m_original.wear );
		memory::write<int>( weapon + SCHEMA( "C_EconEntity", "m_nFallbackStatTrak"_hash ), this->m_original.stattrak );

		const auto pk = g_econ_item_system.find_paint_kit( this->m_original.paint_kit );

		this->update_model( weapon, iv, this->m_original.def_index );
		this->rebuild_paint( weapon, active_weapon, pawn, pk );
		this->schedule_hud_clear( iv );

		this->m_overridden = false;
	}

	void knives::update_model( std::uintptr_t weapon, std::uintptr_t iv, std::uint16_t def_index )
	{
		const auto token = detail::make_subclass_token( static_cast< std::int16_t >( def_index ) );

		memory::write<std::uint32_t>( weapon + SCHEMA( "C_BaseEntity", "m_nSubclassID"_hash ), token );
		memory::call<void>( PATTERN (patterns::weapon_get_viewmodel), weapon );

		const char* target_model = memory::call<const char*>( PATTERN (patterns::weapon_get_model_path), iv );
		if ( !target_model || !*target_model )
		{
			const auto def = g_econ_item_system.find_def( static_cast< std::int16_t >( def_index ) );
			if ( def && !def->model_player.empty( ) )
			{
				target_model = def->model_player.c_str( );
			}
		}

		if ( target_model && *target_model )
		{
			memory::call<void>( PATTERN (patterns::set_player_model), weapon, target_model );
		}
	}

	void knives::rebuild_paint( std::uintptr_t weapon, std::uintptr_t active_weapon, std::uintptr_t pawn, const econ_item_system::paint_kit* pk )
	{
		const auto is_legacy = pk && pk->legacy_model;
		const auto mesh_group = is_legacy ? std::uint64_t{ 2 } : std::uint64_t{ 1 };

		if ( weapon == active_weapon )
		{
			this->update_view_model( pawn, pk );
		}

		const auto weapon_scene_node = memory::read<std::uintptr_t>( weapon + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( weapon_scene_node )
		{
			memory::call<void>( PATTERN( patterns::weapon_set_mesh_group_mask ), weapon_scene_node, mesh_group );
		}

		memory::call<void>( PATTERN( patterns::weapon_update_composite_material ), weapon + 0x608, true );
		memory::call_vfunc<void>( weapon, 10, 1 );
		memory::call<void>( PATTERN( patterns::weapon_update_skin ), weapon, true );
	}

	void knives::update_view_model( std::uintptr_t pawn, const econ_item_system::paint_kit* pk )
	{
		const auto view_model = this->find_hud_model_weapon( pawn );
		if ( !view_model )
		{
			return;
		}

		const auto view_model_scene_node = memory::read<std::uintptr_t>( view_model + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !view_model_scene_node )
		{
			return;
		}

		// Changing only the mesh-group mask leaves the old knife geometry visible.
		const auto services = memory::safe_read<std::uintptr_t>( pawn + SCHEMA( "C_BasePlayerPawn", "m_pWeaponServices"_hash ) ).value_or( 0 );
		const auto handle = services ? memory::safe_read<std::uint32_t>( services + SCHEMA( "CPlayer_WeaponServices", "m_hActiveWeapon"_hash ) ).value_or( 0 ) : 0;
		const auto weapon = handle ? systems::g_entities.lookup( handle ) : 0;
		const auto get_model = PATTERN( patterns::weapon_get_model_path );
		const auto set_model = PATTERN( patterns::set_player_model );
		if ( weapon && get_model && set_model )
		{
			const auto iv = weapon + SCHEMA( "C_EconEntity", "m_AttributeManager"_hash ) + SCHEMA( "C_AttributeContainer", "m_Item"_hash );
			const auto target = memory::call<const char*>( get_model, iv );
			const auto state = view_model_scene_node + SCHEMA( "CSkeletonInstance", "m_modelState"_hash );
			const auto current_name = memory::safe_read<std::uintptr_t>( state + SCHEMA( "CModelState", "m_ModelName"_hash ) ).value_or( 0 );
			if ( target && *target && ( !current_name || !cosmetic_model::matches( memory::read_string( current_name ), target ) ) )
				memory::call<void>( set_model, view_model, target );
		}
		const auto is_legacy = pk && pk->legacy_model;
		// Reacquire the node: SetModel may have replaced it.
		const auto refreshed_node = memory::safe_read<std::uintptr_t>( view_model + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) ).value_or( 0 );
		if ( refreshed_node )
			memory::call<void>( PATTERN( patterns::weapon_set_mesh_group_mask ), refreshed_node, is_legacy ? std::uint64_t{ 2 } : std::uint64_t{ 1 } );
	}

	std::uintptr_t knives::find_hud_model_weapon( std::uintptr_t pawn )
	{
		const auto arms_handle = memory::read<std::uint32_t>( pawn + SCHEMA( "C_CSPlayerPawn", "m_hHudModelArms"_hash ) );
		if ( !arms_handle )
		{
			return 0;
		}

		const auto arms = systems::g_entities.lookup( arms_handle );
		if ( !arms )
		{
			return 0;
		}

		const auto arms_scene_node = memory::read<std::uintptr_t>( arms + SCHEMA( "C_BaseEntity", "m_pGameSceneNode"_hash ) );
		if ( !arms_scene_node )
		{
			return 0;
		}

		auto child = memory::read<std::uintptr_t>( arms_scene_node + SCHEMA( "CGameSceneNode", "m_pChild"_hash ) );
		while ( child && child > 0x10000 )
		{
			const auto owner = memory::read<std::uintptr_t>( child + SCHEMA( "CGameSceneNode", "m_pOwner"_hash ) );
			if ( owner && owner > 0x10000 )
			{
				const auto name = systems::g_entities.get_schema_name( owner );
				if ( name && fnv1a::runtime_hash( name ) == "C_CS2HudModelWeapon"_hash )
				{
					return owner;
				}
			}

			child = memory::read<std::uintptr_t>( child + SCHEMA( "CGameSceneNode", "m_pNextSibling"_hash ) );
		}

		return 0;
	}

	void knives::clear_hud_icon( std::uintptr_t iv )
	{
		const auto invalidate = PATTERN( patterns::econ_item_view_invalidate_description );
		if ( iv && invalidate )
		{
			memory::call<void>( invalidate, iv );
		}
	}

	void knives::schedule_hud_clear( std::uintptr_t iv )
	{
		this->clear_hud_icon( iv );
		this->m_pending_hud_iv = 0;
	}

	void knives::process_hud_clear( )
	{
		this->m_pending_hud_iv = 0;
	}

	void knives::reset( )
	{
		this->m_original = {};
		this->m_overridden = false;
		this->m_tracked_pawn = 0;
		this->m_tracked_weapon_handle = 0;
		this->m_last_active_handle = 0;
		this->m_pending_hud_iv = 0;
		this->m_hud_clear_time = {};
	}

} // namespace features::changer
