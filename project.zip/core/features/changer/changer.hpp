#pragma once

#include <filesystem>
#include <queue>
#include <thread>
#include <condition_variable>
#include <unordered_set>
#include <utilities/cosmetic_identity.hpp>
#include <core/settings.hpp>
#include "cosmetic_attributes.hpp"
#include "name_tag.hpp"
#include "skin_sync.hpp"
#include "inspect_preview.hpp"
#include <core/systems/systems.hpp>

namespace features::changer {

	class econ_item_system
	{
	public:
		enum class item_category : std::uint8_t
		{
			gun,
			knife,
			glove,
			agent,
			other
		};

		struct paint_kit
		{
			int id{};
			std::string name{};
			std::string desc_token{};
			std::string name_token{};
			std::string localized_name{};
			float wear_min{};
			float wear_max{};
			bool legacy_model{};
			std::uint8_t rarity{};
		};

		struct music_kit
		{
			int id{};
			std::string name{};
			std::string loc_name{};
			std::string loc_desc{};
			std::string localized_name{};
			std::string localized_desc{};
			std::string image_inventory{};
			std::uint8_t rarity{ 3 };
		};

		struct item_def
		{
			std::int16_t def_index{};
			std::string item_class{};
			std::string name{};
			std::string localized_name{};
			std::string model_player{};
			std::string image_inventory{};
			int loadout_slot{};
			std::uint32_t used_by_classes{};
			item_category category{};
			std::uint8_t rarity{};

			[[nodiscard]] int team( ) const
			{
				if ( this->category == item_category::agent )
				{
					if ( this->model_player.find( "ctm_" ) != std::string::npos ||
						 this->item_class.find( "ctm_" ) != std::string::npos ||
						 this->name.find( "ctm_" ) != std::string::npos ||
						 this->image_inventory.find( "ctm_" ) != std::string::npos ||
						 this->item_class.find( "customplayer_ct" ) != std::string::npos ||
						 this->name.find( "customplayer_ct" ) != std::string::npos ||
						 this->image_inventory.find( "customplayer_ct" ) != std::string::npos )
					{
						return 3;
					}

					if ( this->model_player.find( "tm_" ) != std::string::npos ||
						 this->item_class.find( "tm_" ) != std::string::npos ||
						 this->name.find( "tm_" ) != std::string::npos ||
						 this->image_inventory.find( "tm_" ) != std::string::npos ||
						 this->item_class.find( "customplayer_t" ) != std::string::npos ||
						 this->name.find( "customplayer_t" ) != std::string::npos ||
						 this->image_inventory.find( "customplayer_tm" ) != std::string::npos )
					{
						return 2;
					}
				}

				if ( ( this->used_by_classes & 0xc ) == 0xc )
				{
					return 0;
				}

				if ( this->used_by_classes & 4 )
				{
					return 2;
				}

				if ( this->used_by_classes & 8 )
				{
					return 3;
				}

				return 0;
			}
		};

		struct skin_entry
		{
			std::int16_t def_index{};
			int paint_kit_id{};
		};

		struct skin_image
		{
			Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> srv{};
			int width{};
			int height{};
		};

		[[nodiscard]] bool initialize( );
		~econ_item_system( );
		void shutdown( );

		[[nodiscard]] const std::vector<paint_kit>& paint_kits( ) const { return this->m_paint_kits; }
		[[nodiscard]] const std::vector<item_def>& item_defs( ) const { return this->m_item_defs; }

		[[nodiscard]] const std::vector<const item_def*>& knives( ) const { return this->m_knives; }
		[[nodiscard]] const std::vector<const item_def*>& gloves( ) const { return this->m_gloves; }
		[[nodiscard]] const std::vector<const item_def*>& agents( ) const { return this->m_agents; }
		[[nodiscard]] const std::vector<const item_def*>& guns( ) const { return this->m_guns; }
		[[nodiscard]] const std::vector<skin_entry>& skins( ) const { return this->m_skins; }
		[[nodiscard]] const std::vector<music_kit>& music_kits( ) const { return this->m_music_kits; }

		[[nodiscard]] const item_def* find_def( std::int16_t def_index ) const;
		[[nodiscard]] const paint_kit* find_paint_kit( int id ) const;
		[[nodiscard]] const music_kit* find_music_kit( int id ) const;
		[[nodiscard]] const skin_image* get_skin_image( const std::string& image_inventory );
		[[nodiscard]] const skin_image* get_skin_image( std::int16_t def_index, int paint_kit_id );

		[[nodiscard]] int combined_rarity( std::int16_t def_index, int paint_kit_id ) const;

		bool poll_schema( );

		void flush_skin_images( );
		void begin_image_frame( ) { this->m_uploads_remaining = 2; }

	private:
		enum class image_state : std::uint8_t
		{
			idle,
			loading,
			decoded,
			ready,
			failed
		};

		struct image_entry
		{
			skin_image image{};
			std::atomic<image_state> state{ image_state::idle };
			std::vector<std::vector<std::uint8_t>> mip_buffers{};
			std::uint32_t width{};
			std::uint32_t height{};
			DXGI_FORMAT format{ DXGI_FORMAT_UNKNOWN };
		};

		bool parse_item_defs( std::uintptr_t schema );
		bool parse_paint_kits( std::uintptr_t schema );
		bool parse_music_kits( std::uintptr_t schema );
		void build_indices( );
		void resolve_localized_names( );
		bool build_vpk_index( );
		void build_skin_index( );

		void request_decode( const std::string& image_inventory );
		bool finalize_texture( image_entry& entry );

		[[nodiscard]] item_category classify( const char* item_class, int loadout_slot );
		[[nodiscard]] std::vector<std::byte> read_vpk( const std::string& path );
		[[nodiscard]] bool decode_vtex( std::span<const std::byte> data, image_entry& out );
		[[nodiscard]] std::string build_skin_image_path( const item_def* def, const paint_kit* pk ) const;

		std::vector<paint_kit> m_paint_kits{};
		std::vector<item_def> m_item_defs{};

		std::vector<const item_def*> m_knives{};
		std::vector<const item_def*> m_gloves{};
		std::vector<const item_def*> m_agents{};
		std::vector<const item_def*> m_guns{};
		std::vector<skin_entry> m_skins{};
		std::vector<music_kit> m_music_kits{};

		std::unordered_map<std::int16_t, std::size_t> m_def_index_map{};
		std::unordered_map<int, std::size_t> m_paint_kit_map{};
		std::unordered_map<int, std::size_t> m_music_kit_map{};

		struct vpk_file_entry
		{
			std::uint16_t archive_index{};
			std::uint32_t offset{};
			std::uint32_t length{};
			std::vector<std::byte> preload{};
		};

		std::uint64_t m_vpk_data_offset{};
		int m_uploads_remaining{ 2 };
		std::unordered_map<std::string, vpk_file_entry> m_vpk_index{};
		bool m_vpk_indexed{};
		std::filesystem::path m_vpk_directory{};

		std::unordered_map<std::string, std::shared_ptr<image_entry>> m_image_cache{};
		std::mutex m_image_mutex{};
		int m_item_schema_count{};
		std::uintptr_t m_item_schema_array{};
		std::chrono::steady_clock::time_point m_last_schema_poll{};

		std::unordered_map<std::uint16_t, std::ifstream> m_archive_handles{};
		std::mutex m_vpk_mutex{};

		void worker_routine( );
		void start_worker( );
		void stop_worker( );

		std::thread m_worker_thread{};
		std::queue<std::string> m_work_queue{};
		std::unordered_set<std::string> m_queued_keys{};
		std::mutex m_work_mutex{};
		std::condition_variable m_work_cv{};
		std::atomic<bool> m_worker_stop{ false };
	};

	class agents
	{
	public:
		void on_frame_stage_notify( );
		void reset( );

	private:
		void cycle_weapon_owners( std::uintptr_t pawn );

		std::string m_original_model{};
		std::string m_applied_model{};
		std::uintptr_t m_tracked_pawn{};
		std::uintptr_t m_applied_handle{};
		std::int16_t m_applied_def{};
		bool m_overridden{};
		int m_tracked_team{};
	};

	class gloves
	{
	public:
		void on_frame_stage_notify( );
		void reset( );

	private:
		struct original_state
		{
			std::uint16_t def_index{};
			std::uint64_t item_id{};
			std::uint32_t id_high{};
			std::uint32_t id_low{};
			std::uint32_t account_id{};
			bool restore_custom_material{};
			bool initialized{};
			bool disallow_soc{};
			bool captured{};
		};

		struct attribute_state
		{
			float value{};
			bool present{};
		};

		[[nodiscard]] bool capture_original( std::uintptr_t item_view );
		[[nodiscard]] bool read_paint_attributes( std::uintptr_t item_view, std::array<attribute_state, 3>& attributes ) const;
		[[nodiscard]] bool restore_paint_attributes( std::uintptr_t item_view ) const;
		[[nodiscard]] bool paint_attributes_match( std::uintptr_t item_view, const settings::changer::applied_skin& skin ) const;
		void apply( std::uintptr_t pawn, std::uintptr_t item_view, int team, const econ_item_system::item_def& def, const settings::changer::applied_skin& skin, std::uint32_t account_id );
		void restore( std::uintptr_t pawn, std::uintptr_t item_view, int team );
		void refresh( std::uintptr_t pawn, std::uintptr_t item_view, int team ) const;

		original_state m_original{};
		std::array<attribute_state, 3> m_original_attributes{};
		std::uintptr_t m_tracked_pawn{};
		bool m_overridden{};
	};

	class guns
	{
	public:
		void on_frame_stage_notify( );
		void reset( ); // Level teardown, on the game thread.
		void invalidate( ) { m_invalidate_pending.store( true ); }

	private:
		struct original_weapon {
			std::uintptr_t weapon{};
			std::uint16_t def_index{};
			std::uint64_t item_id{};
			std::uint32_t id_high{}, id_low{}, account_id{};
			int quality{}, paint_kit{}, seed{}, stattrak{};
			float wear{};
			bool initialized{}, disallow_soc{};
			cosmetic_attributes::snapshot attributes{};
			std::optional<name_tag::snapshot> custom_name{};
		};
		bool capture_original( std::uintptr_t weapon, std::uintptr_t iv, std::uint32_t handle );
		bool restore( std::uintptr_t weapon, std::uintptr_t iv, std::uint32_t handle, std::uint32_t active_handle, std::uintptr_t pawn );
		std::unordered_map<std::uint32_t, original_weapon> m_original_weapons{};
		std::atomic<bool> m_invalidate_pending{ false };
		bool apply( std::uintptr_t weapon, std::uintptr_t iv, std::uint32_t handle, std::uint32_t active_handle, std::uintptr_t pawn, const settings::changer::applied_skin* skin, std::uint32_t account_id );
		void rebuild_paint( std::uintptr_t weapon, std::uint32_t handle, std::uint32_t active_handle, std::uintptr_t pawn, const econ_item_system::paint_kit* pk );
		void update_view_model( std::uintptr_t pawn, const econ_item_system::paint_kit* pk );
		[[nodiscard]] std::uintptr_t find_hud_model_weapon( std::uintptr_t pawn );
		void clear_hud_icon( std::uintptr_t iv );
		void schedule_hud_clear( std::uintptr_t iv );
		void process_hud_clear( );

		std::uint32_t m_last_active_handle{};
		std::uintptr_t m_tracked_pawn{};
		std::uintptr_t m_last_hud_model{};
		float m_last_round_start_time{};
		struct applied_weapon {
            cosmetic_cache::identity visual{};
            settings::changer::applied_skin skin{};
        };
        std::unordered_map<std::uint32_t, applied_weapon> m_applied_weapons{};
		std::uintptr_t m_pending_hud_iv{};
		std::chrono::steady_clock::time_point m_hud_clear_time{};
	};

	class knives
	{
	public:
		void on_frame_stage_notify( );
		void reset( );

	private:
		struct original_state
		{
			std::uint16_t def_index{};
			std::uint32_t id_high{};
			std::uint32_t id_low{};
			std::uint32_t account_id{};
			bool initialized{};
			int paint_kit{};
			int seed{};
			float wear{};
			int stattrak{};
            std::uint64_t item_id{};
            int quality{};
            bool disallow_soc{};
            cosmetic_attributes::snapshot attributes{};
            std::optional<name_tag::snapshot> custom_name{};
			bool captured{};
		};

		void capture_original( std::uintptr_t weapon, std::uintptr_t iv );
		void apply( std::uintptr_t weapon, std::uintptr_t iv, const econ_item_system::item_def* def, const settings::changer::applied_skin* skin, std::uint32_t account_id, std::uintptr_t active_weapon, std::uintptr_t pawn );
		void restore( std::uintptr_t weapon, std::uintptr_t iv, std::uintptr_t active_weapon, std::uintptr_t pawn );
		void update_model( std::uintptr_t weapon, std::uintptr_t iv, std::uint16_t def_index );
		void update_view_model( std::uintptr_t pawn, const econ_item_system::paint_kit* pk );
		[[nodiscard]] std::uintptr_t find_hud_model_weapon( std::uintptr_t pawn );
		void rebuild_paint( std::uintptr_t weapon, std::uintptr_t active_weapon, std::uintptr_t pawn, const econ_item_system::paint_kit* pk );
		void clear_hud_icon( std::uintptr_t iv );
		void schedule_hud_clear( std::uintptr_t iv );
		void process_hud_clear( );

		original_state m_original{};
		std::uint32_t m_tracked_weapon_handle{};
		std::uint32_t m_last_active_handle{};
		std::uintptr_t m_tracked_pawn{};
		bool m_overridden{};
		std::uintptr_t m_pending_hud_iv{};
		std::chrono::steady_clock::time_point m_hud_clear_time{};
	};

	class music
	{
	public:
		void on_frame_stage_notify( );
		void reset( );
		void on_round_mvp( void* event );
		void clear_mvp( );
		// Returns false when deferring on this thread is unsafe; caller plays normally.
		bool queue_mvp_music( void* context, int track, std::uint16_t kit, float volume,
			void (*play)( void*, int, std::uint16_t, float ) );
		[[nodiscard]] bool is_local_mvp( ) const;

	private:
		std::uint16_t m_original_music{};
		std::int32_t m_original_music_kit_id{};
		bool m_original_mvp_no_music{};
		std::int32_t m_original_music_kit_mvps{};
		bool m_captured{};
		std::uintptr_t m_last_controller{};
		std::atomic_bool m_local_won_last_mvp{ false };
		std::chrono::steady_clock::time_point m_last_mvp_time{};
	};

	[[nodiscard]] int get_current_mvp_kit_id( );

} // namespace features::changer
