#include <pch/pch.hpp>
#include <utilities/math/math.hpp>
#include <utilities/memory/memory.hpp>
#include <utilities/addresses/addresses.hpp>
#include <core/systems/systems.hpp>
#include <core/settings.hpp>
#include <core/features/features.hpp>

#include "../rendering.hpp"
#include "../theme.hpp"
#include "menu/menu.weapons.hpp"
#include <utilities/security/security.hpp>
#include <utilities/steam/steam.hpp>
#include <protection/game_addresses.hpp>
#include <chrono>

namespace rendering {

	void widgets::draw( )
	{
		const auto [screen_w, screen_h] = xdraw::viewport_size( );
		if ( screen_w <= 0 || screen_h <= 0 )
			return;

		// HUD widgets must not inherit a menu/popup clip rectangle.
		auto& dl = xdraw::get( xdraw::layer::top );
		dl.push_clip_absolute( 0.0f, 0.0f, static_cast<float>( screen_w ), static_cast<float>( screen_h ) );
		xdraw::push_font( g_fonts.inter_medium[fonts::size::petite] );

		if ( settings::g_misc.m_watermark.enabled.value )
		{
			this->watermark( dl );
		}

		if ( settings::g_misc.m_widgets.keybinds_list.value )
		{
			this->keybinds( dl );
		}
		else
		{
			this->m_keybinds_hovered = false;
			this->m_keybinds_dragging = false;
		}

		if ( settings::g_misc.m_widgets.spectator_list.value )
		{
			this->spectators( dl );
		}
		else
		{
			this->m_spectators_hovered = false;
			this->m_spectators_dragging = false;
		}

		this->teammate_damage( dl );

		xdraw::pop_font( );
		dl.pop_clip( );
	}

	void widgets::watermark( xdraw::draw_list& draw_list )
	{
		const auto [screen_w, screen_h] = xdraw::viewport_size( );
		const auto& wm = settings::g_misc.m_watermark;
		const auto framerate = xdraw::framerate( );
		const auto local = systems::g_local.get( );


		// ── time ────────────────────────────────────────────────────────────
		SYSTEMTIME st{};
		GetLocalTime( &st );
		char time_buf[ 8 ]{};
		std::snprintf( time_buf, sizeof( time_buf ), "%02d:%02d", st.wHour, st.wMinute );

		// ── fps ─────────────────────────────────────────────────────────────
		static auto smoothed_fps{ 0.0f };
		if ( smoothed_fps == 0.0f ) smoothed_fps = framerate;
		smoothed_fps += ( framerate - smoothed_fps ) * std::min( 2.0f * xdraw::delta_time( ), 1.0f );
		char fps_val[ 8 ]{};
		std::snprintf( fps_val, sizeof( fps_val ), "%.0f", smoothed_fps );

		// ── ping (game scoreboard ping: CCSPlayerController::m_iPing) ───────
		auto ping{ 0 };
		if ( local.controller && systems::g_entities.exists( local.controller ) )
		{
			const auto ping_offset = SCHEMA( "CCSPlayerController", "m_iPing"_hash );
			if ( ping_offset > 0 )
			{
				const auto raw_ping = memory::read<std::uint32_t>( local.controller + ping_offset );
				if ( raw_ping < 1000 )
					ping = static_cast<int>( raw_ping );
			}
		}

		char ping_val[ 8 ]{};
		std::snprintf( ping_val, sizeof( ping_val ), "%d", ping );

		// ── packet loss (measured from network client misdelivery rate) ──────
		auto loss_pct{ 0 };
		if ( local.controller && systems::g_entities.exists( local.controller ) )
		{
			const auto net_client = addresses::globals::network_client_service;
			const auto tick_state = net_client ? memory::call_vfunc<std::uintptr_t>( net_client, 23 ) : 0;
			if ( tick_state )
			{
				const auto loss_in  = memory::call_vfunc<float>( tick_state, 68 );
				const auto loss_out = memory::call_vfunc<float>( tick_state, 69 );
				const auto max_loss = std::max( loss_in, loss_out );
				if ( max_loss >= 0.0f && max_loss <= 1.0f )
					loss_pct = static_cast<int>( std::round( max_loss * 100.0f ) );
			}
		}

		char loss_val[ 8 ]{};
		std::snprintf( loss_val, sizeof( loss_val ), "%d%%", loss_pct );

		// ── map name (stored reliably from level_initialization hook) ────────
		const bool has_map = wm.show_map.value && !s_map_name.empty( );

		// ── tick rate (measured from server_tick delta over ~2 s of real time) ─
		static auto last_server_tick{ 0 };
		static auto last_curtime{ 0.0f };
		static auto measured_tickrate{ 0 };

		if ( local.controller && systems::g_entities.exists( local.controller ) && addresses::globals::global_vars )
		{
			const auto net_for_tick = addresses::globals::network_client_service;
			const auto tick_state   = net_for_tick ? memory::call_vfunc<std::uintptr_t>( net_for_tick, 23 ) : 0;
			const auto server_tick  = tick_state   ? memory::read<int>( tick_state + 892 ) : 0;
			const auto gv           = memory::read<std::uintptr_t>( addresses::globals::global_vars );
			const auto curtime      = gv ? memory::read<float>( gv + 0x30 ) : 0.0f;

			if ( server_tick > 0 && last_server_tick > 0 && curtime - last_curtime >= 2.0f )
			{
				const auto tick_delta = server_tick - last_server_tick;
				const auto time_delta = curtime - last_curtime;
				if ( tick_delta > 0 && time_delta > 0.5f )
				{
					const auto rate = static_cast<int>( std::round( tick_delta / time_delta ) );
					if ( rate >= 16 && rate <= 256 ) measured_tickrate = rate;
				}
				last_server_tick = server_tick;
				last_curtime     = curtime;
			}
			else if ( last_server_tick == 0 && server_tick > 0 )
			{
				last_server_tick = server_tick;
				last_curtime     = curtime;
			}
		}
		else
		{
			last_server_tick = 0;
			last_curtime     = 0.0f;
			measured_tickrate = 0;
		}

		const bool has_tick = wm.show_tick.value && local.controller && measured_tickrate > 0;
		char tick_val[ 8 ]{};
		if ( has_tick ) std::snprintf( tick_val, sizeof( tick_val ), "%d", measured_tickrate );

		// ── velocity ──────────────────────────────────────────────────────
		const bool has_velocity = wm.show_velocity.value && local.is_alive && local.pawn && systems::g_entities.exists( local.pawn );
		static auto smoothed_velocity{ 0.0f };
		char vel_val[ 8 ]{};
		if ( has_velocity )
		{
			const auto vel_offset = SCHEMA( "C_BaseEntity", "m_vecAbsVelocity"_hash );
			const auto velocity = vel_offset ? memory::read<math::vector3>( local.pawn + vel_offset ) : math::vector3{};
			const auto speed = velocity.length_2d( );
			smoothed_velocity += ( speed - smoothed_velocity ) * std::min( 8.0f * xdraw::delta_time( ), 1.0f );
			std::snprintf( vel_val, sizeof( vel_val ), "%.0f", smoothed_velocity );
		}
		else
		{
			smoothed_velocity = 0.0f;
		}


        xdraw::push_font(g_fonts.inter_medium[fonts::size::petite]);
        enum class wm_icon_type : int {
            user = 0,
            map,
            ping,
            loss,
            velocity,
            fps,
            tick,
            time,
            count
        };
        struct segment {
            wm_icon_type icon;
            std::string value, unit;
            float full_width;
            float anim_w;
            float alpha_factor;
        };

        static float s_anim_factors[static_cast<int>(wm_icon_type::count)]{
            1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f, 1.0f
        };
        static bool s_anim_inited = false;

        const bool is_user_active     = wm.show_user.value;
        const bool is_map_active      = has_map;
        const bool is_ping_active     = wm.show_ping.value;
        const bool is_loss_active     = wm.show_loss.value;
        const bool is_velocity_active = has_velocity;
        const bool is_fps_active      = wm.show_fps.value;
        const bool is_tick_active     = has_tick;
        const bool is_time_active     = wm.show_time.value;

        if (!s_anim_inited)
        {
            s_anim_factors[static_cast<int>(wm_icon_type::user)]     = is_user_active ? 1.0f : 0.0f;
            s_anim_factors[static_cast<int>(wm_icon_type::map)]      = is_map_active ? 1.0f : 0.0f;
            s_anim_factors[static_cast<int>(wm_icon_type::ping)]     = is_ping_active ? 1.0f : 0.0f;
            s_anim_factors[static_cast<int>(wm_icon_type::loss)]     = is_loss_active ? 1.0f : 0.0f;
            s_anim_factors[static_cast<int>(wm_icon_type::velocity)] = is_velocity_active ? 1.0f : 0.0f;
            s_anim_factors[static_cast<int>(wm_icon_type::fps)]      = is_fps_active ? 1.0f : 0.0f;
            s_anim_factors[static_cast<int>(wm_icon_type::tick)]     = is_tick_active ? 1.0f : 0.0f;
            s_anim_factors[static_cast<int>(wm_icon_type::time)]     = is_time_active ? 1.0f : 0.0f;
            s_anim_inited = true;
        }

        const float dt = xdraw::delta_time();
        const auto update_anim = [&](wm_icon_type type, bool active) -> float {
            const int idx = static_cast<int>(type);
            const float target = active ? 1.0f : 0.0f;
            s_anim_factors[idx] += (target - s_anim_factors[idx]) * std::min(13.0f * dt, 1.0f);
            if (std::abs(s_anim_factors[idx] - target) < 0.001f)
                s_anim_factors[idx] = target;
            return s_anim_factors[idx];
        };

        std::vector<segment> segments;
        const auto add = [&](wm_icon_type icon, bool active, std::string value, std::string unit = {}) {
            const float factor = update_anim(icon, active);
            if (factor <= 0.001f)
                return;

            constexpr float icon_area_w = 14.0f + 6.0f;
            const auto full_w = icon_area_w + xdraw::measure_text(value).first + xdraw::measure_text(unit).first + 18.0f;
            const float eased = 1.0f - std::pow(1.0f - factor, 2.0f);
            const float anim_w = full_w * eased;

            segments.push_back({icon, std::move(value), std::move(unit), full_w, anim_w, factor});
        };

        const auto available = std::max(100.0f, static_cast<float>(screen_w) - 24.0f);
        add(wm_icon_type::user,     is_user_active,     theme::fit_text(g_menu.user_name(), std::min(140.0f, available * 0.25f)));
        add(wm_icon_type::map,      is_map_active,      theme::fit_text(s_map_name, 130.0f));
        add(wm_icon_type::ping,     is_ping_active,     ping_val, " ms");
        add(wm_icon_type::loss,     is_loss_active,     loss_val, " loss");
        add(wm_icon_type::velocity, is_velocity_active, vel_val, " u/s");
        add(wm_icon_type::fps,      is_fps_active,      fps_val, " fps");
        add(wm_icon_type::tick,     is_tick_active,     tick_val, " tick");
        add(wm_icon_type::time,     is_time_active,     time_buf);

        constexpr float height = 34.0f, pad = 7.0f, gap = 5.0f;
        const auto brand_width = 29.0f + xdraw::measure_text("mintaly").first + 14.0f;
        // Wrap on narrow viewports rather than drawing off-screen.
        std::vector<std::vector<segment>> rows(1);
        std::vector<float> widths{brand_width + pad * 2.0f};
        for (auto& item : segments)
        {
            const float item_span = gap * item.alpha_factor + item.anim_w;
            if (widths.back() + item_span > available)
            {
                rows.emplace_back();
                widths.push_back(pad * 2.0f);
            }
            widths.back() += item_span;
            rows.back().push_back(std::move(item));
        }
        const auto master_opacity = std::clamp( wm.opacity.value, 0.0f, 100.0f ) / 100.0f;
        const auto tint = [master_opacity]( xdraw::color c ) -> xdraw::color {
            return c.alpha( static_cast<std::uint8_t>( c.a * master_opacity ) );
        };

        // Position enum: 0=top-left, 1=top-center, 2=top-right, 3=bottom-left, 4=bottom-center, 5=bottom-right
        const auto pos = std::clamp( wm.position.value, 0, 5 );
        const bool is_bottom = pos >= 3;
        const bool is_left   = pos == 0 || pos == 3;
        const bool is_center = pos == 1 || pos == 4;

        auto draw_wm_icon = [&]( wm_icon_type type, float ix, float iy, xdraw::color col ) {
            switch ( type )
            {
            case wm_icon_type::user:
            {
                draw_list.circle( ix, iy - 2.8f, 2.5f, col, 1.3f );
                std::vector<float> p{
                    ix - 4.5f, iy + 4.2f,
                    ix - 3.2f, iy + 1.8f,
                    ix,        iy + 1.0f,
                    ix + 3.2f, iy + 1.8f,
                    ix + 4.5f, iy + 4.2f
                };
                draw_list.polyline( p, col, false, 1.3f );
                break;
            }
            case wm_icon_type::map:
            {
                draw_list.circle( ix, iy - 1.8f, 3.2f, col, 1.3f );
                draw_list.circle_filled( ix, iy - 1.8f, 1.2f, col );
                draw_list.line( ix - 2.4f, iy + 0.2f, ix, iy + 4.4f, col, 1.3f );
                draw_list.line( ix + 2.4f, iy + 0.2f, ix, iy + 4.4f, col, 1.3f );
                break;
            }
            case wm_icon_type::ping:
            {
                draw_list.line( ix - 3.5f, iy + 3.8f, ix - 3.5f, iy + 1.2f, col, 1.5f );
                draw_list.line( ix,        iy + 3.8f, ix,        iy - 1.2f, col, 1.5f );
                draw_list.line( ix + 3.5f, iy + 3.8f, ix + 3.5f, iy - 3.8f, col, 1.5f );
                break;
            }
            case wm_icon_type::loss:
            {
                // Bad connection / packet loss icon:
                // Wi-Fi signal broadcast arcs with a diagonal disconnect / loss slash
                std::vector<float> arc_outer{
                    ix - 4.5f, iy - 1.5f,
                    ix - 2.5f, iy - 3.8f,
                    ix,        iy - 4.5f,
                    ix + 2.5f, iy - 3.8f,
                    ix + 4.5f, iy - 1.5f
                };
                draw_list.polyline( arc_outer, col, false, 1.3f );

                std::vector<float> arc_inner{
                    ix - 2.8f, iy + 0.8f,
                    ix - 1.4f, iy - 0.8f,
                    ix,        iy - 1.4f,
                    ix + 1.4f, iy - 0.8f,
                    ix + 2.8f, iy + 0.8f
                };
                draw_list.polyline( arc_inner, col, false, 1.3f );

                draw_list.circle_filled( ix, iy + 3.8f, 1.2f, col );

                // Diagonal disconnect slash cutting across
                draw_list.line( ix - 4.8f, iy + 4.2f, ix + 4.8f, iy - 4.2f, col, 1.4f );
                break;
            }
            case wm_icon_type::velocity:
            {
                draw_list.line( ix - 4.5f, iy - 2.6f, ix + 2.2f, iy - 2.6f, col, 1.4f );
                draw_list.line( ix - 2.5f, iy,        ix + 4.5f, iy,        col, 1.4f );
                draw_list.line( ix - 4.5f, iy + 2.6f, ix + 1.2f, iy + 2.6f, col, 1.4f );
                break;
            }
            case wm_icon_type::fps:
            {
                std::vector<float> p{
                    ix + 0.6f, iy - 4.8f,
                    ix - 2.8f, iy + 0.2f,
                    ix - 0.2f, iy + 0.2f,
                    ix - 1.4f, iy + 4.8f,
                    ix + 3.2f, iy - 0.8f,
                    ix + 0.8f, iy - 0.8f,
                    ix + 1.8f, iy - 4.8f
                };
                draw_list.polyline( p, col, false, 1.4f );
                break;
            }
            case wm_icon_type::tick:
            {
                std::vector<float> p{
                    ix - 4.8f, iy + 0.8f,
                    ix - 2.2f, iy + 0.8f,
                    ix - 0.8f, iy - 3.8f,
                    ix + 0.8f, iy + 3.8f,
                    ix + 2.2f, iy + 0.8f,
                    ix + 4.8f, iy + 0.8f
                };
                draw_list.polyline( p, col, false, 1.4f );
                break;
            }
            case wm_icon_type::time:
            {
                draw_list.circle( ix, iy, 4.4f, col, 1.3f );
                draw_list.line( ix, iy, ix,        iy - 2.5f, col, 1.3f );
                draw_list.line( ix, iy, ix + 2.2f, iy + 0.6f, col, 1.3f );
                draw_list.circle_filled( ix, iy, 1.0f, col );
                break;
            }
            default:
                break;
            }
        };

        static float s_smoothed_widths[8]{ 0.0f };
        static bool s_widths_inited = false;

        for (std::size_t row = 0; row < rows.size(); ++row)
        {
            const auto target_w = widths[row];
            if (!s_widths_inited || s_smoothed_widths[row] <= 0.0f)
                s_smoothed_widths[row] = target_w;
            else
                s_smoothed_widths[row] += (target_w - s_smoothed_widths[row]) * std::min(15.0f * dt, 1.0f);

            const auto w = s_smoothed_widths[row];

            // X anchor
            float x;
            if (is_left)
                x = 12.0f;
            else if (is_center)
                x = (static_cast<float>(screen_w) - w) * 0.5f;
            else // right
                x = std::max(4.0f, static_cast<float>(screen_w) - w - 12.0f);

            // Y anchor
            float y;
            if (is_bottom)
                y = static_cast<float>(screen_h) - 12.0f - static_cast<float>(rows.size() - row) * (height + 5.0f) + 5.0f;
            else
                y = 12.0f + row * (height + 5.0f);

            // Ambient soft shadow expanding all around the background card
            draw_list.rect_filled( x - 6.0f, y - 5.0f, w + 12.0f, height + 11.0f,
                tint({ 0, 0, 0, 15 }), xdraw::corner_radius{ 12.0f } );
            draw_list.rect_filled( x - 4.0f, y - 3.5f, w + 8.0f, height + 8.0f,
                tint({ 0, 0, 0, 30 }), xdraw::corner_radius{ 10.0f } );
            draw_list.rect_filled( x - 2.5f, y - 2.0f, w + 5.0f, height + 5.0f,
                tint({ 0, 0, 0, 50 }), xdraw::corner_radius{ 8.5f } );
            draw_list.rect_filled( x - 1.0f, y - 0.5f, w + 2.0f, height + 3.0f,
                tint({ 0, 0, 0, 75 }), xdraw::corner_radius{ 7.5f } );

            // Card background and border
            draw_list.rect_filled(x, y, w, height, tint(tokens::col_card), xdraw::corner_radius{7.0f});
            draw_list.rect(x, y, w, height, tint(tokens::col_border), xdraw::corner_radius{7.0f});
            const auto accent_x = x + 10.0f;
            const auto accent_w = std::max(0.0f, w - 20.0f);
            const auto half_w = accent_w * 0.5f;
            const auto edge = tint(tokens::col_accent.alpha(0));
            const auto center = tint(tokens::col_accent.alpha(180));
            draw_list.rect_filled_gradient(accent_x, y, half_w, 1.5f,
                edge, center, center, edge);
            draw_list.rect_filled_gradient(accent_x + half_w, y, half_w, 1.5f,
                center, edge, edge, center);
            auto cx = x + pad;
            if (row == 0)
            {
                draw_list.rect_filled(cx, y + 6.0f, 22.0f, 22.0f, tint(tokens::col_elevated), xdraw::corner_radius{5.0f});
                draw_list.rect(cx, y + 6.0f, 22.0f, 22.0f, tint(tokens::col_accent.alpha(110)), xdraw::corner_radius{5.0f});
                xdraw::push_font(g_fonts.inter_bold[fonts::size::petite]);
                const auto [mw, mh] = xdraw::measure_text("M");
                draw_list.text(cx + (22.0f - mw) * 0.5f, y + (height - mh) * 0.5f, "M", tint(tokens::col_accent));
                xdraw::pop_font();
                const auto th = xdraw::measure_text("mintaly").second;
                draw_list.text(cx + 29.0f, y + (height - th) * 0.5f, "mintaly", tint(tokens::col_text));
                cx += brand_width;
            }
            for (const auto& item : rows[row])
            {
                cx += gap * item.alpha_factor;
                if (item.anim_w <= 0.5f)
                    continue;

                const bool needs_clip = (item.alpha_factor < 0.999f);
                if (needs_clip)
                    draw_list.push_clip( cx, y - 2.0f, item.anim_w, height + 4.0f );

                const auto item_cy = y + height * 0.5f;
                const auto icon_x = cx + 8.0f;

                const auto item_col_accent = tint(tokens::col_accent).alpha(static_cast<std::uint8_t>(tokens::col_accent.a * master_opacity * item.alpha_factor));
                const auto item_col_text   = tint(tokens::col_text).alpha(static_cast<std::uint8_t>(tokens::col_text.a * master_opacity * item.alpha_factor));
                const auto item_col_dim    = tint(tokens::col_text_dim).alpha(static_cast<std::uint8_t>(tokens::col_text_dim.a * master_opacity * item.alpha_factor));

                draw_wm_icon( item.icon, icon_x, item_cy, item_col_accent );

                const auto text_x = icon_x + 11.0f;
                const auto [vw, vh] = xdraw::measure_text(item.value);
                const auto uh = xdraw::measure_text(item.unit).second;
                draw_list.text(text_x, y + (height - vh) * 0.5f, item.value, item_col_text);
                if (!item.unit.empty())
                    draw_list.text(text_x + vw, y + (height - uh) * 0.5f, item.unit, item_col_dim);

                if (needs_clip)
                    draw_list.pop_clip();

                cx += item.anim_w;
            }
        }
        for (std::size_t r = rows.size(); r < 8; ++r)
            s_smoothed_widths[r] = 0.0f;
        s_widths_inited = true;
        xdraw::pop_font();
    }

	void widgets::keybinds( xdraw::draw_list& draw_list )
	{
		struct row_anim_t
		{
			animation::fade alpha;
			animation::spring offset_y;
			bool active_this_frame{ false };
			float last_w{ 0.0f };
		};

		static std::map<std::string, row_anim_t> row_states;
		static animation::fade container_alpha;
		static animation::spring smoothed_base_y;

		const auto [screen_w, screen_h] = xdraw::viewport_size( );
		const auto& s = xui::ctx( ).style;

		constexpr auto margin{ 10.0f };

		constexpr std::size_t k_max_entries = 64;
		struct bind_entry
		{
			char name[ 64 ]{};
			char value[ 32 ]{};
			char key[ 16 ]{};
			float nw{ 0.0f }, nh{ 0.0f };
			float vw{ 0.0f }, vh{ 0.0f };
			bool has_value_pill{ false };
			xui::bind_mode mode{ xui::bind_mode::toggle };
		};

		const auto format_key_name = []( int vk, char* out, std::size_t out_sz ) {
			if ( !out || out_sz == 0 )
				return;
			out[ 0 ] = '\0';
			if ( vk == 0 )
				return;
			const auto raw = xui::vk_name( vk );
			if ( !raw || raw[ 0 ] == '\0' || std::strcmp( raw, "none" ) == 0 )
				return;
			std::size_t i = 0;
			for ( ; raw[ i ] != '\0' && i + 1 < out_sz; ++i )
			{
				out[ i ] = static_cast< char >( std::toupper( static_cast< unsigned char >( raw[ i ] ) ) );
			}
			out[ i ] = '\0';
		};

		bind_entry entries[ k_max_entries ]{};
		auto count{ 0 };

		static bind_entry s_cached_entries[ k_max_entries ]{};
		static int s_cached_count = 0;
		static float s_cached_max_w = 195.0f;
		static auto s_last_binds_gather = std::chrono::steady_clock::time_point{};

		const auto now = std::chrono::steady_clock::now( );
		if ( std::chrono::duration<float>( now - s_last_binds_gather ).count( ) >= 0.04f )
		{
			s_last_binds_gather = now;

		const auto& ctx = features::combat::g_shared.ctx( );
		const auto has_weapon = ctx.valid && ctx.weapon_type >= cstypes::weapon_type::pistol && ctx.weapon_type <= cstypes::weapon_type::lmg;

		static const settings::combat::ragebot::weapon_group* s_last_rage_group = &settings::g_combat.m_ragebot.groups[ 2 ];
		static const settings::combat::legitbot::weapon_group* s_last_legit_group = &settings::g_combat.m_legitbot.groups[ 2 ];

		if ( has_weapon )
		{
			s_last_rage_group = &settings::g_combat.m_ragebot.get_group( ctx.weapon_type, ctx.item_def_idx );
			s_last_legit_group = &settings::g_combat.m_legitbot.get_group( ctx.weapon_type, ctx.item_def_idx );
		}
		else if ( g_menu.is_open( ) )
		{
			const auto is_custom_rage = ( menu_weapons::weapon_sel_rage.weapon_flat_idx >= 0 &&
				menu_weapons::weapon_sel_rage.weapon_flat_idx < static_cast< int >( cstypes::weapons::k_total_weapons ) );
			if ( is_custom_rage && settings::g_combat.m_ragebot.weapons[ menu_weapons::weapon_sel_rage.weapon_flat_idx ].override_group.value )
				s_last_rage_group = &settings::g_combat.m_ragebot.weapons[ menu_weapons::weapon_sel_rage.weapon_flat_idx ].cfg;
			else
				s_last_rage_group = &settings::g_combat.m_ragebot.groups[ std::clamp( menu_weapons::weapon_sel_rage.group_idx, 0, 5 ) ];

			const auto is_custom_legit = ( menu_weapons::weapon_sel_legit.weapon_flat_idx >= 0 &&
				menu_weapons::weapon_sel_legit.weapon_flat_idx < static_cast< int >( cstypes::weapons::k_total_weapons ) );
			if ( is_custom_legit && settings::g_combat.m_legitbot.weapons[ menu_weapons::weapon_sel_legit.weapon_flat_idx ].override_group.value )
				s_last_legit_group = &settings::g_combat.m_legitbot.weapons[ menu_weapons::weapon_sel_legit.weapon_flat_idx ].cfg;
			else
				s_last_legit_group = &settings::g_combat.m_legitbot.groups[ std::clamp( menu_weapons::weapon_sel_legit.group_idx, 0, 5 ) ];
		}

		const auto active_rage_group = s_last_rage_group ? s_last_rage_group : &settings::g_combat.m_ragebot.groups[ 2 ];
		const auto active_legit_group = s_last_legit_group ? s_last_legit_group : &settings::g_combat.m_legitbot.groups[ 2 ];

		const auto is_in_rage_group = []( const xui::setting* s, const settings::combat::ragebot::weapon_group& wg ) {
			return s == &wg.min_damage_override || s == &wg.hitchance_override ||
				s == &wg.force_shot || s == &wg.force_shot_air || s == &wg.body_aim ||
				s == &wg.silent || s == &wg.no_spread || s == &wg.autostop ||
				s == &wg.dynamic_pointscale || s == &wg.debug_multipoints;
		};

		const auto is_in_legit_group = []( const xui::setting* s, const settings::combat::legitbot::weapon_group& wg ) {
			return s == &wg.aimbot || s == &wg.rcs || s == &wg.standalone_rcs ||
				s == &wg.triggerbot || s == &wg.trigger_head_only || s == &wg.give_me_your_seed ||
				s == &wg.autowall || s == &wg.smoke_check || s == &wg.scope_check ||
				s == &wg.flash_check || s == &wg.ground_check || s == &wg.visualize_fov;
		};

		// Ensure air strafer bind is always synchronized with airstrafe
		settings::g_movement.m_test_strafer.enabled.bind = settings::g_movement.airstrafe.bind;
		settings::g_movement.m_test_strafer.enabled.value = settings::g_movement.airstrafe.value;

		for ( const auto setting : xui::binds::all( ) )
		{
			if ( !setting || setting->bind.key == 0 || !setting->bind.active || count >= k_max_entries )
			{
				continue;
			}

			// Do not show airstrafe as a duplicate; only "air strafer" will be shown
			if ( setting == &settings::g_movement.airstrafe )
			{
				continue;
			}

			// Settings have stable addresses; membership does not depend on bind state.
			static std::unordered_map<const xui::setting*, bool> rage_membership;
			const auto [rage_it, new_rage_setting] = rage_membership.try_emplace( setting, false );
			if ( new_rage_setting )
			{
				for ( const auto& group : settings::g_combat.m_ragebot.groups )
					rage_it->second = rage_it->second || is_in_rage_group( setting, group );
				for ( const auto& weapon : settings::g_combat.m_ragebot.weapons )
					rage_it->second = rage_it->second || is_in_rage_group( setting, weapon.cfg );
			}
			const auto is_rage_group = rage_it->second;

			if ( is_rage_group )
			{
				if ( !settings::g_combat.m_ragebot.enabled )
				{
					continue;
				}

				if ( ctx.valid )
				{
					if ( !is_in_rage_group( setting, *active_rage_group ) )
					{
						continue;
					}
				}

				std::string clean_name = setting->name;
				if ( clean_name.empty( ) || clean_name == "enabled" )
				{
					if ( !setting->category.empty( ) )
						clean_name = setting->category;
					else
						clean_name = "ragebot";
				}

				bool duplicate = false;
				for ( auto j = 0; j < count; ++j )
				{
					if ( std::strcmp( entries[ j ].name, clean_name.c_str( ) ) == 0 )
					{
						duplicate = true;
						break;
					}
				}
				if ( duplicate )
				{
					continue;
				}

				auto& e = entries[ count++ ];
				format_key_name( setting->bind.key, e.key, sizeof( e.key ) );
				std::strncpy( e.name, clean_name.c_str( ), sizeof( e.name ) - 1 );
				e.name[ sizeof( e.name ) - 1 ] = '\0';
				e.mode = setting->bind.mode;

				const auto matched_group = is_in_rage_group( setting, *active_rage_group ) ? active_rage_group : &settings::g_combat.m_ragebot.groups[ 2 ];

				if ( setting == &matched_group->min_damage_override )
				{
					std::snprintf( e.value, sizeof( e.value ), "%d", matched_group->min_damage_override_value.value );
					e.has_value_pill = true;
				}
				else if ( setting == &matched_group->hitchance_override )
				{
					std::snprintf( e.value, sizeof( e.value ), "%d%%", matched_group->hitchance_override_value.value );
					e.has_value_pill = true;
				}
				else
				{
					e.has_value_pill = false;
					switch ( e.mode )
					{
					case xui::bind_mode::toggle:
						std::snprintf( e.value, sizeof( e.value ), "toggle" );
						break;
					case xui::bind_mode::hold_on:
						std::snprintf( e.value, sizeof( e.value ), "hold" );
						break;
					case xui::bind_mode::hold_off:
						std::snprintf( e.value, sizeof( e.value ), "release" );
						break;
					default:
						std::snprintf( e.value, sizeof( e.value ), "on" );
						break;
					}
				}
				continue;
			}

			static std::unordered_map<const xui::setting*, bool> legit_membership;
			const auto [legit_it, new_legit_setting] = legit_membership.try_emplace( setting, false );
			if ( new_legit_setting )
			{
				for ( const auto& group : settings::g_combat.m_legitbot.groups )
					legit_it->second = legit_it->second || is_in_legit_group( setting, group );
				for ( const auto& weapon : settings::g_combat.m_legitbot.weapons )
					legit_it->second = legit_it->second || is_in_legit_group( setting, weapon.cfg );
			}
			const auto is_legit_group = legit_it->second;

			if ( is_legit_group )
			{
				if ( !settings::g_combat.m_legitbot.enabled.value )
				{
					continue;
				}

				if ( ctx.valid )
				{
					if ( !is_in_legit_group( setting, *active_legit_group ) )
					{
						continue;
					}
				}

				if ( setting == &active_legit_group->give_me_your_seed && !active_legit_group->triggerbot.value )
				{
					continue;
				}

				std::string clean_name = setting->name;
				if ( clean_name.empty( ) || clean_name == "enabled" )
				{
					if ( !setting->category.empty( ) )
						clean_name = setting->category;
					else
						clean_name = "legitbot";
				}

				bool duplicate = false;
				for ( auto j = 0; j < count; ++j )
				{
					if ( std::strcmp( entries[ j ].name, clean_name.c_str( ) ) == 0 )
					{
						duplicate = true;
						break;
					}
				}
				if ( duplicate )
				{
					continue;
				}

				auto& e = entries[ count++ ];
				format_key_name( setting->bind.key, e.key, sizeof( e.key ) );
				std::strncpy( e.name, clean_name.c_str( ), sizeof( e.name ) - 1 );
				e.name[ sizeof( e.name ) - 1 ] = '\0';
				e.mode = setting->bind.mode;
				e.has_value_pill = false;

				switch ( e.mode )
				{
				case xui::bind_mode::toggle:
					std::snprintf( e.value, sizeof( e.value ), "toggle" );
					break;
				case xui::bind_mode::hold_on:
					std::snprintf( e.value, sizeof( e.value ), "hold" );
					break;
				case xui::bind_mode::hold_off:
					std::snprintf( e.value, sizeof( e.value ), "release" );
					break;
				default:
					std::snprintf( e.value, sizeof( e.value ), "on" );
					break;
				}
				continue;
			}

			const bool is_aa_subsetting = (
				setting == &settings::g_combat.m_antiaim.manual_left ||
				setting == &settings::g_combat.m_antiaim.manual_right ||
				setting == &settings::g_combat.m_antiaim.hide_shots ||
				setting == &settings::g_combat.m_antiaim.avoid_backstab ||
				setting == &settings::g_combat.m_antiaim.direction_indicator ||
				setting == &settings::g_combat.m_antiaim.direction_indicator_glow ||
				setting == &settings::g_combat.m_antiaim.spinbot ||
				setting == &settings::g_combat.m_antiaim.jitters ||
				setting == &settings::g_combat.m_antiaim.auto_yaw_adjust ||
				( setting != &settings::g_combat.m_antiaim.enabled && setting->category == "anti aim" )
			);

			if ( is_aa_subsetting )
			{
				if ( !settings::g_combat.m_antiaim.enabled.value )
				{
					continue;
				}
			}

			std::string clean_name = setting->name;
			if ( clean_name == "airstrafe" )
			{
				clean_name = "air strafer";
			}
			if ( clean_name.empty( ) || clean_name == "enabled" )
			{
				if ( !setting->category.empty( ) )
					clean_name = setting->category;
				else
					clean_name = "unnamed";
			}

			bool duplicate = false;
			for ( auto j = 0; j < count; ++j )
			{
				if ( std::strcmp( entries[ j ].name, clean_name.c_str( ) ) == 0 )
				{
					duplicate = true;
					break;
				}
			}
			if ( duplicate )
			{
				continue;
			}

			auto& e = entries[ count++ ];
			format_key_name( setting->bind.key, e.key, sizeof( e.key ) );
			std::strncpy( e.name, clean_name.c_str( ), sizeof( e.name ) - 1 );
			e.name[ sizeof( e.name ) - 1 ] = '\0';
			e.mode = setting->bind.mode;
			e.has_value_pill = false;

			switch ( e.mode )
			{
			case xui::bind_mode::toggle:
				std::snprintf( e.value, sizeof( e.value ), "toggle" );
				break;
			case xui::bind_mode::hold_on:
				std::snprintf( e.value, sizeof( e.value ), "hold" );
				break;
			case xui::bind_mode::hold_off:
				std::snprintf( e.value, sizeof( e.value ), "release" );
				break;
			default:
				std::snprintf( e.value, sizeof( e.value ), "on" );
				break;
			}
		}

		for ( const auto entry : xui::slider_binds::all( ) )
		{
			if ( !entry || count >= k_max_entries )
				continue;

			bool has_active = false;
			for ( std::size_t i = 0; i < entry->count; ++i )
			{
				if ( entry->binds[ i ].key != 0 && entry->binds[ i ].active )
				{
					has_active = true;
					break;
				}
			}
			if ( !has_active )
				continue;

			auto is_rage_group{ false };
			for ( auto i = 0u; i < settings::combat::ragebot::k_group_count; ++i )
			{
				const auto& g = settings::g_combat.m_ragebot.groups[ i ];
				if ( entry->ptr == &g.hitchance.value || entry->ptr == &g.min_damage.value || entry->ptr == &g.max_fov.value || entry->ptr == &g.pointscale.value )
				{
					is_rage_group = true;
					break;
				}
			}
			if ( !is_rage_group )
			{
				for ( auto i = 0u; i < settings::combat::ragebot::k_weapon_count; ++i )
				{
					const auto& w = settings::g_combat.m_ragebot.weapons[ i ].cfg;
					if ( entry->ptr == &w.hitchance.value || entry->ptr == &w.min_damage.value || entry->ptr == &w.max_fov.value || entry->ptr == &w.pointscale.value )
					{
						is_rage_group = true;
						break;
					}
				}
			}

			if ( is_rage_group )
			{
				if ( !settings::g_combat.m_ragebot.enabled )
				{
					continue;
				}

				if ( ctx.valid )
				{
					if ( entry->ptr != &active_rage_group->hitchance.value && entry->ptr != &active_rage_group->min_damage.value && entry->ptr != &active_rage_group->max_fov.value && entry->ptr != &active_rage_group->pointscale.value )
					{
						continue;
					}
				}
			}

			for ( std::size_t i = 0; i < entry->count; ++i )
			{
				const auto& b = entry->binds[ i ];
				if ( b.key == 0 || !b.active || count >= k_max_entries )
					continue;

				const auto hash_pos = entry->label.find( "##" );
				const auto name_len = ( hash_pos != std::string::npos ) ? hash_pos : entry->label.size( );
				std::string clean_name = entry->label.substr( 0, name_len );

				bool duplicate = false;
				for ( auto j = 0; j < count; ++j )
				{
					if ( std::strcmp( entries[ j ].name, clean_name.c_str( ) ) == 0 )
					{
						duplicate = true;
						break;
					}
				}
				if ( duplicate )
					continue;

				auto& e = entries[ count++ ];
				format_key_name( b.key, e.key, sizeof( e.key ) );
				std::strncpy( e.name, clean_name.c_str( ), sizeof( e.name ) - 1 );
				e.name[ sizeof( e.name ) - 1 ] = '\0';
				e.mode = b.mode;

				if ( entry->is_integral )
				{
					std::snprintf( e.value, sizeof( e.value ), "%d", static_cast< int >( std::roundf( b.value ) ) );
				}
				else
				{
					std::snprintf( e.value, sizeof( e.value ), "%.1f", b.value );
				}
				e.has_value_pill = true;
			}
		}

			float mw = 195.0f;
			constexpr float el_gap = 5.0f;
			for ( auto i = 0; i < count; ++i )
			{
				auto& e = entries[ i ];
				const auto [nw, nh] = xdraw::measure_text( e.name );
				const auto [vw, vh] = xdraw::measure_text( e.value );
				e.nw = nw;
				e.nh = nh;
				e.vw = vw;
				e.vh = vh;
				const float mode_w = std::max( 46.0f, vw + 14.0f );
				const float row_w = 14.0f + nw + 16.0f + el_gap + mode_w;
				if ( row_w > mw )
				{
					mw = row_w;
				}
			}
			const auto [header_tw, header_th] = xdraw::measure_text( "Keybinds" );
			if ( header_tw + 45.0f > mw )
			{
				mw = header_tw + 45.0f;
			}
			s_cached_max_w = mw;
			s_cached_count = count;
			for ( auto i = 0; i < count; ++i )
			{
				s_cached_entries[ i ] = entries[ i ];
			}
		}

		count = s_cached_count;
		for ( int i = 0; i < count; ++i )
		{
			entries[ i ] = s_cached_entries[ i ];
		}
		const float max_w = s_cached_max_w;

		// Keep the header visible as a preview while the menu is open.
		if ( count > 0 || g_menu.is_open( ) )
			container_alpha.fade_in( 0.2f );
		else
			container_alpha.fade_out( 0.2f );

		container_alpha.update( );
		if ( !container_alpha.visible( ) )
		{
			this->m_keybinds_hovered = false;
			this->m_keybinds_dragging = false;
			return;
		}

		const auto master_alpha = container_alpha.alpha( ) * std::clamp( settings::g_misc.m_widgets.keybinds_opacity.value, 0.0f, 100.0f ) / 100.0f;

		constexpr auto header_h{ 28.0f };
		constexpr auto header_gap{ 10.0f };
		constexpr auto row_h{ 26.0f };
		constexpr auto row_gap{ 6.0f };
		const auto card_r = xdraw::corner_radius{ 6.0f };
		const auto [header_tw, header_th] = xdraw::measure_text( "Keybinds" );

		auto draw_watermark_shadow = [&]( float sx, float sy, float sw, float sh ) {
			draw_list.rect_filled( sx - 4.0f, sy - 3.0f, sw + 8.0f, sh + 7.0f,
				xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 30.0f * master_alpha ) }, xdraw::corner_radius{ 9.0f } );
			draw_list.rect_filled( sx - 1.5f, sy - 1.0f, sw + 3.0f, sh + 3.0f,
				xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 65.0f * master_alpha ) }, xdraw::corner_radius{ 7.0f } );
		};

		constexpr float el_gap = 5.0f;

		auto& widgets_cfg = settings::g_misc.m_widgets;

		const auto body_h = ( count > 0 )
			? ( header_gap + static_cast< float >( count ) * row_h + static_cast< float >( count - 1 ) * row_gap )
			: ( g_menu.is_open( ) ? ( header_gap + row_h ) : 0.0f );
		const auto total_h = header_h + body_h;

		const auto max_screen_x = std::max( 0.0f, static_cast< float >( screen_w ) - max_w );
		const auto max_screen_y = std::max( 0.0f, static_cast< float >( screen_h ) - total_h );

		float current_x = widgets_cfg.keybinds_x.value;
		float current_y = widgets_cfg.keybinds_y.value;
		const bool has_custom_pos = ( current_x >= 0.0f && current_y >= 0.0f );

		const auto target_base_y = ( static_cast< float >( screen_h ) * 0.5f ) - ( total_h * 0.5f );
		if ( !has_custom_pos )
		{
			smoothed_base_y.set_target( target_base_y );
			smoothed_base_y.update( );
			current_x = margin;
			current_y = smoothed_base_y.value( );
		}
		else
		{
			smoothed_base_y.snap( current_y );
			current_x = std::clamp( current_x, 0.0f, max_screen_x );
			current_y = std::clamp( current_y, 0.0f, max_screen_y );
		}

		// Drag handling when menu is open
		static bool s_last_mouse_down{ false };
		static bool s_is_dragging{ false };
		static float s_drag_offset_x{ 0.0f };
		static float s_drag_offset_y{ 0.0f };

		const auto& input = xui::ctx( ).input;
		const bool lbutton_phys = ( GetAsyncKeyState( VK_LBUTTON ) & 0x8000 ) != 0;
		const bool mouse_down = input.mouse_down && lbutton_phys;
		const bool mouse_clicked = mouse_down && !s_last_mouse_down;
		const bool menu_open = g_menu.is_open( );

		const xui::rect widget_rect{ current_x, current_y, max_w, total_h };
		const bool hovered = menu_open && widget_rect.contains( input.mouse_x, input.mouse_y );

		this->m_keybinds_hovered = hovered;

		if ( !menu_open || !mouse_down )
		{
			s_is_dragging = false;
		}

		const bool can_start_drag = menu_open
			&& !this->m_spectators_dragging
			&& !this->m_teammate_damage_dragging
			&& !xui::ctx( ).overlay_blocking( )
			&& xui::ctx( ).active_window == xui::null_id
			&& xui::ctx( ).active_slider == xui::null_id
			&& xui::ctx( ).active_resize == xui::null_id
			&& xui::ctx( ).active_text_input == xui::null_id
			&& xui::ctx( ).active_child_scroll == xui::null_id;

		if ( can_start_drag && hovered && mouse_clicked )
		{
			s_is_dragging = true;
			s_drag_offset_x = input.mouse_x - current_x;
			s_drag_offset_y = input.mouse_y - current_y;
		}

		if ( s_is_dragging )
		{
			current_x = std::clamp( input.mouse_x - s_drag_offset_x, 0.0f, max_screen_x );
			current_y = std::clamp( input.mouse_y - s_drag_offset_y, 0.0f, max_screen_y );

			widgets_cfg.keybinds_x = current_x;
			widgets_cfg.keybinds_y = current_y;
		}

		this->m_keybinds_dragging = s_is_dragging;
		s_last_mouse_down = mouse_down;

		const auto x = current_x;
		const auto base_ry = current_y;

		// Header drop shadow (watermark style)
		draw_watermark_shadow( x, base_ry, max_w, header_h );

		// Header container
		draw_list.rect_filled( x, base_ry, max_w, header_h, tokens::col_dark.alpha( static_cast< std::uint8_t >( 230.0f * master_alpha ) ), card_r );

		const auto header_border_col = ( menu_open && ( hovered || s_is_dragging ) )
			? s.accent.alpha( static_cast< std::uint8_t >( ( s_is_dragging ? 220.0f : 140.0f ) * master_alpha ) )
			: tokens::col_border.alpha( static_cast< std::uint8_t >( 120.0f * master_alpha ) );
		draw_list.rect( x, base_ry, max_w, header_h, header_border_col, card_r, 1.0f );

		// Top subtle ambient neon reflection line
		const auto half_w = ( max_w - 20.0f ) * 0.5f;
		draw_list.rect_filled_gradient(
			x + 10.0f, base_ry, half_w, 1.2f,
			s.accent.alpha( 0 ),
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) ),
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) ),
			s.accent.alpha( 0 )
		);
		draw_list.rect_filled_gradient(
			x + 10.0f + half_w, base_ry, half_w, 1.2f,
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) ),
			s.accent.alpha( 0 ),
			s.accent.alpha( 0 ),
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) )
		);

		// Modern glowing brand indicator on left of header
		const auto dot_cx = x + 13.0f;
		const auto dot_cy = base_ry + header_h * 0.5f;
		draw_list.circle_filled( dot_cx, dot_cy, 4.5f, s.accent.alpha( static_cast< std::uint8_t >( 45.0f * master_alpha ) ) );
		draw_list.circle_filled( dot_cx, dot_cy, 2.2f, s.accent.alpha( static_cast< std::uint8_t >( 240.0f * master_alpha ) ) );
		draw_list.circle_filled( dot_cx, dot_cy, 0.8f, xdraw::color{ 255, 255, 255, static_cast< std::uint8_t >( 240.0f * master_alpha ) } );

		// Header title
		const auto title_x = dot_cx + 8.0f;
		const auto title_y = base_ry + ( header_h - header_th ) * 0.5f - 0.5f;
		draw_list.text( title_x, title_y, "Keybinds", tokens::col_text.alpha( static_cast< std::uint8_t >( 245.0f * master_alpha ) ), g_fonts.inter_bold[ fonts::size::petite ] );

		// Rows (separated individual cards)
		if ( count == 0 && g_menu.is_open( ) )
		{
			const auto empty_y = base_ry + header_h + header_gap;
			draw_watermark_shadow( x, empty_y, max_w, row_h );
			draw_list.rect_filled( x, empty_y, max_w, row_h, tokens::col_card.alpha( static_cast< std::uint8_t >( 230.0f * master_alpha ) ), card_r );
			draw_list.rect( x, empty_y, max_w, row_h, tokens::col_border.alpha( static_cast< std::uint8_t >( 100.0f * master_alpha ) ), card_r, 1.0f );

			const auto empty_text = "No active binds";
			const auto [ ew, eh ] = xdraw::measure_text( empty_text );
			draw_list.text( x + ( max_w - ew ) * 0.5f, empty_y + ( row_h - eh ) * 0.5f - 0.5f, empty_text, tokens::col_text_dim.alpha( static_cast< std::uint8_t >( 135.0f * master_alpha ) ) );
		}
		else
		{
			for ( auto i = 0; i < count; ++i )
			{
				const auto& e = entries[ i ];
				const auto row_y = base_ry + header_h + header_gap + static_cast< float >( i ) * ( row_h + row_gap );
				if ( row_y + row_h + 2.0f < 0.0f || row_y - 2.0f > static_cast<float>( screen_h ) )
					continue;
				const float nw = e.nw;
				const float nh = e.nh;
				const float vw = e.vw;
				const float vh = e.vh;

				const float mode_w = std::max( 46.0f, vw + 14.0f );
				const float mode_x = x + max_w - mode_w;
				const float mode_y = row_y;

				const float left_x = x;
				const float left_y = row_y;
				const float left_w = mode_x - el_gap - left_x;

				// Fast single-pass shadow for the row
				draw_list.rect_filled( x - 1.5f, row_y - 1.0f, max_w + 3.0f, row_h + 2.0f,
					xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 45.0f * master_alpha ) }, card_r );

				// 1. Element 1 (Left: Bind Name + Key)
				draw_list.rect_filled( left_x, left_y, left_w, row_h, tokens::col_card.alpha( static_cast< std::uint8_t >( 230.0f * master_alpha ) ), card_r );
				draw_list.rect( left_x, left_y, left_w, row_h, tokens::col_border.alpha( static_cast< std::uint8_t >( 110.0f * master_alpha ) ), card_r, 1.0f );

				// Sleek left indicator bar (zero heap allocations)
				const auto bar_col = ( e.mode == xui::bind_mode::hold_off )
					? tokens::col_text_dim.alpha( static_cast< std::uint8_t >( 120.0f * master_alpha ) )
					: s.accent.alpha( static_cast< std::uint8_t >( 245.0f * master_alpha ) );
				draw_list.rect_filled( left_x + 3.0f, left_y + 4.5f, 2.5f, row_h - 9.0f, bar_col, xdraw::corner_radius{ 1.25f } );

				// Name text
				const float name_x = left_x + 10.0f;
				draw_list.text( name_x, left_y + ( row_h - nh ) * 0.5f - 0.5f, e.name, tokens::col_text.alpha( static_cast< std::uint8_t >( 240.0f * master_alpha ) ) );

				// 2. Element 2 (Right: Mode / State)
				draw_list.rect_filled( mode_x, mode_y, mode_w, row_h, tokens::col_card.alpha( static_cast< std::uint8_t >( 230.0f * master_alpha ) ), card_r );

				if ( e.has_value_pill || e.mode != xui::bind_mode::hold_off )
				{
					draw_list.rect_filled( mode_x, mode_y, mode_w, row_h, s.accent.alpha( static_cast< std::uint8_t >( 30.0f * master_alpha ) ), card_r );
					draw_list.rect( mode_x, mode_y, mode_w, row_h, s.accent.alpha( static_cast< std::uint8_t >( 110.0f * master_alpha ) ), card_r, 1.0f );
					draw_list.text( mode_x + ( mode_w - vw ) * 0.5f, mode_y + ( row_h - vh ) * 0.5f - 0.5f, e.value, s.accent.alpha( static_cast< std::uint8_t >( 255.0f * master_alpha ) ) );
				}
				else
				{
					draw_list.rect( mode_x, mode_y, mode_w, row_h, tokens::col_border.alpha( static_cast< std::uint8_t >( 90.0f * master_alpha ) ), card_r, 1.0f );
					draw_list.text( mode_x + ( mode_w - vw ) * 0.5f, mode_y + ( row_h - vh ) * 0.5f - 0.5f, e.value, tokens::col_text_dim.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) ) );
				}
			}
		}
	}

	void widgets::teammate_damage( xdraw::draw_list& draw_list )
	{
		auto& cfg = settings::g_misc.m_widgets;
		const auto& ctx = xui::ctx( );
		const auto& input = ctx.input;
		const bool mouse_down = input.mouse_down && ( GetAsyncKeyState( VK_LBUTTON ) & 0x8000 ) != 0;
		const bool mouse_clicked = mouse_down && !this->m_teammate_damage_mouse_down;
		this->m_teammate_damage_mouse_down = mouse_down;
		const bool menu_open = g_menu.is_open( );
		if ( !cfg.teammate_damage.value )
		{
			this->m_teammate_damage_hovered = false;
			this->m_teammate_damage_dragging = false;
			return;
		}

		const auto [screen_w, screen_h] = xdraw::viewport_size( );
		constexpr float header_h = 28.0f, header_gap = 10.0f, row_h = 26.0f;
		constexpr float total_h = header_h + header_gap + row_h;
		xdraw::push_font( g_fonts.inter_bold[ fonts::size::petite ] );
		const auto [title_w, title_h] = xdraw::measure_text( "Teammate damage" );
		xdraw::pop_font( );
		const auto text = std::format( "Kills: {}/3  |  Damage: {}/300", s_team_kills, s_team_damage );
		const auto [text_w, text_h] = xdraw::measure_text( text );
		const auto width = std::max( 195.0f, std::max( title_w + 45.0f, text_w + 28.0f ) );
		const auto max_x = std::max( 0.0f, static_cast<float>( screen_w ) - width );
		const auto max_y = std::max( 0.0f, static_cast<float>( screen_h ) - total_h );
		auto x = std::clamp( cfg.teammate_damage_x.value >= 0.0f ? cfg.teammate_damage_x.value : 10.0f, 0.0f, max_x );
		auto y = std::clamp( cfg.teammate_damage_y.value >= 0.0f ? cfg.teammate_damage_y.value : static_cast<float>( screen_h ) * 0.75f, 0.0f, max_y );
		const xui::rect bounds{ x, y, width, total_h };
		this->m_teammate_damage_hovered = menu_open && bounds.contains( input.mouse_x, input.mouse_y );
		if ( !menu_open || !mouse_down )
			this->m_teammate_damage_dragging = false;

		const bool can_start_drag = menu_open
			&& !this->m_keybinds_dragging && !this->m_spectators_dragging
			&& !ctx.overlay_blocking( )
			&& ctx.active_window == xui::null_id
			&& ctx.active_slider == xui::null_id
			&& ctx.active_resize == xui::null_id
			&& ctx.active_text_input == xui::null_id
			&& ctx.active_child_scroll == xui::null_id;
		if ( can_start_drag && this->m_teammate_damage_hovered && mouse_clicked )
		{
			this->m_teammate_damage_dragging = true;
			this->m_teammate_damage_drag_x = input.mouse_x - x;
			this->m_teammate_damage_drag_y = input.mouse_y - y;
		}
		if ( this->m_teammate_damage_dragging )
		{
			x = std::clamp( input.mouse_x - this->m_teammate_damage_drag_x, 0.0f, max_x );
			y = std::clamp( input.mouse_y - this->m_teammate_damage_drag_y, 0.0f, max_y );
			cfg.teammate_damage_x = x;
			cfg.teammate_damage_y = y;
		}

		const auto opacity = std::clamp( cfg.teammate_damage_opacity.value, 0.0f, 100.0f ) / 100.0f;
		const auto alpha = [opacity]( float value ) { return static_cast<std::uint8_t>( value * opacity ); };
		const auto radius = xdraw::corner_radius{ 6.0f };
		const auto& accent = ctx.style.accent;
		const auto draw_card = [&]( float cy, float height, xdraw::color background, xdraw::color border ) {
			draw_list.rect_filled( x - 4.0f, cy - 3.0f, width + 8.0f, height + 7.0f, xdraw::color{ 0, 0, 0, alpha( 30.0f ) }, xdraw::corner_radius{ 9.0f } );
			draw_list.rect_filled( x - 1.5f, cy - 1.0f, width + 3.0f, height + 3.0f, xdraw::color{ 0, 0, 0, alpha( 65.0f ) }, xdraw::corner_radius{ 7.0f } );
			draw_list.rect_filled( x, cy, width, height, background.alpha( alpha( 230.0f ) ), radius );
			draw_list.rect( x, cy, width, height, border, radius, 1.0f );
		};
		const auto border = this->m_teammate_damage_hovered || this->m_teammate_damage_dragging
			? accent.alpha( alpha( this->m_teammate_damage_dragging ? 220.0f : 140.0f ) )
			: tokens::col_border.alpha( alpha( 120.0f ) );
		draw_card( y, header_h, tokens::col_dark, border );
		const auto half_w = ( width - 20.0f ) * 0.5f;
		draw_list.rect_filled_gradient( x + 10.0f, y, half_w, 1.2f, accent.alpha( 0 ), accent.alpha( alpha( 170.0f ) ), accent.alpha( alpha( 170.0f ) ), accent.alpha( 0 ) );
		draw_list.rect_filled_gradient( x + 10.0f + half_w, y, half_w, 1.2f, accent.alpha( alpha( 170.0f ) ), accent.alpha( 0 ), accent.alpha( 0 ), accent.alpha( alpha( 170.0f ) ) );
		draw_list.circle_filled( x + 13.0f, y + header_h * 0.5f, 4.5f, accent.alpha( alpha( 45.0f ) ) );
		draw_list.circle_filled( x + 13.0f, y + header_h * 0.5f, 2.2f, accent.alpha( alpha( 240.0f ) ) );
		draw_list.circle_filled( x + 13.0f, y + header_h * 0.5f, 0.8f, xdraw::color{ 255, 255, 255, alpha( 240.0f ) } );
		draw_list.text( x + 21.0f, y + ( header_h - title_h ) * 0.5f - 0.5f, "Teammate damage", tokens::col_text.alpha( alpha( 245.0f ) ), g_fonts.inter_bold[ fonts::size::petite ] );
		const auto row_y = y + header_h + header_gap;
		draw_card( row_y, row_h, tokens::col_card, tokens::col_border.alpha( alpha( 110.0f ) ) );
		auto text_color = tokens::col_text;
		if ( s_team_kills >= 2 || s_team_damage >= 200 )
			text_color = xdraw::color{ 255, 100, 100, 255 };
		else if ( s_team_kills >= 1 || s_team_damage >= 100 )
			text_color = xdraw::color{ 255, 200, 80, 255 };
		draw_list.text( x + ( width - text_w ) * 0.5f, row_y + ( row_h - text_h ) * 0.5f - 0.5f, text, text_color.alpha( alpha( 240.0f ) ) );
	}

	void widgets::spectators( xdraw::draw_list& draw_list )
	{
		struct avatar_cache
		{
			struct entry
			{
				Microsoft::WRL::ComPtr<ID3D11ShaderResourceView> texture{};
				std::chrono::steady_clock::time_point last_request{};
			};

			std::unordered_map<std::uint64_t, entry> m_entries{};
			std::chrono::steady_clock::time_point m_last_load{};

			[[nodiscard]] ID3D11ShaderResourceView* get( std::uint64_t steam_id )
			{
				if ( steam_id < 76561197960265728ull )
				{
					return nullptr;
				}

				if ( !steam_id )
				{
					return nullptr;
				}

				auto it = this->m_entries.find( steam_id );
				if ( it != this->m_entries.end( ) && it->second.texture )
				{
					return it->second.texture.Get( );
				}

				const auto now = std::chrono::steady_clock::now( );
				if ( it != this->m_entries.end( ) )
				{
					if ( std::chrono::duration<float>( now - it->second.last_request ).count( ) < 2.0f )
					{
						return nullptr;
					}
				}

				// Spread Steam calls and GPU uploads across frames, including failed requests.
				if ( now - this->m_last_load < std::chrono::milliseconds( 50 ) )
					return nullptr;
				this->m_last_load = now;

				auto& e = this->m_entries[ steam_id ];
				e.last_request = now;

				const auto image_handle = steam::friends::get_medium_friend_avatar( steam_id );
				if ( image_handle <= 0 )
				{
					steam::friends::request_user_information( steam_id, false );
					return nullptr;
				}

				std::uint32_t w{}, h{};
				if ( !steam::utils::get_image_size( image_handle, &w, &h ) || !w || !h || w > 512 || h > 512 )
				{
					return nullptr;
				}

				std::vector<std::uint8_t> rgba( static_cast< std::size_t >( w ) * h * 4 );
				if ( !steam::utils::get_image_rgba( image_handle, rgba.data( ), static_cast< int >( rgba.size( ) ) ) )
				{
					return nullptr;
				}

				e.texture = xdraw::create_srv_from_rgba( rgba.data( ), static_cast< int >( w ), static_cast< int >( h ) );
				return e.texture.Get( );
			}

			void clear( )
			{
				this->m_entries.clear( );
			}
		};

		static avatar_cache avatars{};
		static std::string avatar_map;
		if ( avatar_map != s_map_name )
		{
			avatars.clear( );
			avatar_map = s_map_name;
		}

		struct row_anim_t
		{
			animation::fade alpha;
			animation::spring offset_y;
			bool active_this_frame{ false };
		};

		static std::map<std::string, row_anim_t> row_states;
		static animation::fade container_alpha;
		static animation::spring smoothed_base_y;

		const auto [screen_w, screen_h] = xdraw::viewport_size( );
		const auto& s = xui::ctx( ).style;

		constexpr auto margin{ 10.0f };

		struct spectator_entry
		{
			char name[ 128 ];
			float nw{ 0.0f }, nh{ 0.0f };
			std::uint64_t steam_id;
		};

		spectator_entry entries[ 32 ]{};
		auto count{ 0 };

		static spectator_entry s_cached_entries[ 32 ]{};
		static int s_cached_count = 0;
		static float s_cached_max_w = 175.0f;
		static auto s_last_spec_scan = std::chrono::steady_clock::time_point{};

		const auto now = std::chrono::steady_clock::now( );
		if ( std::chrono::duration<float>( now - s_last_spec_scan ).count( ) >= 0.1f )
		{
			s_last_spec_scan = now;
			s_cached_count = 0;

			const auto local = systems::g_local.get( );
			const auto game_rules = memory::safe_read<std::uintptr_t>( addresses::globals::game_rules ).value_or( 0 );
			const bool game_in_progress = game_rules && memory::safe_read<int>( game_rules + SCHEMA( "C_CSGameRules", "m_gamePhase"_hash ) ).value_or( 99 ) < 4;

			if ( local.is_valid( ) && systems::g_entities.exists( local.view_controller( ) ) && game_in_progress )
			{
				const auto local_controller = local.controller;
				const auto view_controller = local.view_controller( );
				const auto view_pawn = local.view_pawn( );
				if ( view_pawn )
				{
					for ( const auto& player : systems::g_entities.get_by_type( systems::entities::type::player ) )
					{
						if ( !player.ptr || player.ptr == view_controller || player.ptr == local_controller || s_cached_count >= 32 )
						{
							continue;
						}

						if ( memory::safe_read<bool>( player.ptr + SCHEMA( "CCSPlayerController", "m_bPawnIsAlive"_hash ) ).value_or( true ) )
						{
							continue;
						}

						const auto obs_pawn_handle = memory::safe_read<std::uint32_t>( player.ptr + SCHEMA( "CCSPlayerController", "m_hObserverPawn"_hash ) ).value_or( 0 );
						if ( !obs_pawn_handle || obs_pawn_handle == 0xffffffff )
						{
							continue;
						}

						const auto obs_pawn = systems::g_entities.lookup( obs_pawn_handle );
						if ( !obs_pawn )
						{
							continue;
						}

						const auto observer_services = memory::safe_read<std::uintptr_t>( obs_pawn + SCHEMA( "C_BasePlayerPawn", "m_pObserverServices"_hash ) ).value_or( 0 );
						if ( !observer_services || ( observer_services >> 48 ) != 0 )
						{
							continue;
						}

						const auto observer_target_handle = memory::safe_read<std::uint32_t>( observer_services + SCHEMA( "CPlayer_ObserverServices", "m_hObserverTarget"_hash ) ).value_or( 0 );
						if ( !observer_target_handle || observer_target_handle == 0xffffffff )
						{
							continue;
						}

						const auto observer_target = systems::g_entities.lookup( observer_target_handle );
						if ( observer_target != view_pawn )
						{
							continue;
						}

						const auto name_ptr = memory::safe_read<std::uintptr_t>( player.ptr + SCHEMA( "CCSPlayerController", "m_sSanitizedPlayerName"_hash ) ).value_or( 0 );
						if ( !name_ptr )
						{
							continue;
						}

						auto name = memory::read_string( name_ptr, 127 );
						if ( name.empty( ) )
						{
							name = "spectator";
						}
						std::ranges::transform( name, name.begin( ), [ ]( unsigned char c ) { return std::tolower( c ); } );

						const auto [ nw, nh ] = xdraw::measure_text( name );
						auto& e = s_cached_entries[ s_cached_count++ ];
						strncpy_s( e.name, name.c_str( ), sizeof( e.name ) - 1 );
						e.name[ sizeof( e.name ) - 1 ] = '\0';
						e.nw = nw;
						e.nh = nh;
						e.steam_id = memory::safe_read<std::uint64_t>( player.ptr + SCHEMA( "CBasePlayerController", "m_steamID"_hash ) ).value_or( 0 );
					}
				}
			}

			float mw = 175.0f;
			constexpr float av_size = 32.0f;
			for ( auto i = 0; i < s_cached_count; ++i )
			{
				const float row_w = av_size + 14.0f + s_cached_entries[ i ].nw + 16.0f;
				if ( row_w > mw )
				{
					mw = row_w;
				}
			}
			const auto [header_tw, header_th] = xdraw::measure_text( "Spectators" );
			if ( header_tw + 45.0f > mw )
			{
				mw = header_tw + 45.0f;
			}
			s_cached_max_w = mw;
		}

		count = s_cached_count;
		for ( int i = 0; i < count; ++i )
		{
			entries[ i ] = s_cached_entries[ i ];
		}
		const float max_w = s_cached_max_w;

		if ( count > 0 || g_menu.is_open( ) )
			container_alpha.fade_in( 0.2f );
		else
			container_alpha.fade_out( 0.2f );

		container_alpha.update( );
		if ( !container_alpha.visible( ) )
		{
			this->m_spectators_hovered = false;
			this->m_spectators_dragging = false;
			return;
		}

		const auto master_alpha = container_alpha.alpha( ) * std::clamp( settings::g_misc.m_widgets.spectator_opacity.value, 0.0f, 100.0f ) / 100.0f;

		constexpr auto header_h{ 28.0f };
		constexpr auto header_gap{ 10.0f };
		constexpr auto row_h{ 26.0f };
		constexpr auto row_gap{ 10.0f };
		const auto card_r = xdraw::corner_radius{ 6.0f };
		const auto [header_tw, header_th] = xdraw::measure_text( "Spectators" );

		auto draw_watermark_shadow = [&]( float sx, float sy, float sw, float sh ) {
			draw_list.rect_filled( sx - 4.0f, sy - 3.0f, sw + 8.0f, sh + 7.0f,
				xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 30.0f * master_alpha ) }, xdraw::corner_radius{ 9.0f } );
			draw_list.rect_filled( sx - 1.5f, sy - 1.0f, sw + 3.0f, sh + 3.0f,
				xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 65.0f * master_alpha ) }, xdraw::corner_radius{ 7.0f } );
		};

		constexpr float av_size = 32.0f;

		auto& widgets_cfg = settings::g_misc.m_widgets;

		const auto body_h = ( count > 0 )
			? ( header_gap + static_cast< float >( count ) * row_h + static_cast< float >( count - 1 ) * row_gap )
			: ( g_menu.is_open( ) ? ( header_gap + row_h ) : 0.0f );
		const auto total_h = header_h + body_h;

		const auto max_screen_x = std::max( 0.0f, static_cast< float >( screen_w ) - max_w );
		const auto max_screen_y = std::max( 0.0f, static_cast< float >( screen_h ) - total_h );

		float current_x = widgets_cfg.spectator_x.value;
		float current_y = widgets_cfg.spectator_y.value;
		const bool has_custom_pos = ( current_x >= 0.0f && current_y >= 0.0f );

		const auto target_base_y = ( static_cast< float >( screen_h ) * 0.5f ) - ( total_h * 0.5f );
		if ( !has_custom_pos )
		{
			smoothed_base_y.set_target( target_base_y );
			smoothed_base_y.update( );
			current_x = std::max( 0.0f, static_cast< float >( screen_w ) - max_w - margin );
			current_y = smoothed_base_y.value( );
		}
		else
		{
			smoothed_base_y.snap( current_y );
			current_x = std::clamp( current_x, 0.0f, max_screen_x );
			current_y = std::clamp( current_y, 0.0f, max_screen_y );
		}

		// Drag handling when menu is open
		static bool s_last_mouse_down{ false };
		static bool s_is_dragging{ false };
		static float s_drag_offset_x{ 0.0f };
		static float s_drag_offset_y{ 0.0f };

		const auto& input = xui::ctx( ).input;
		const bool lbutton_phys = ( GetAsyncKeyState( VK_LBUTTON ) & 0x8000 ) != 0;
		const bool mouse_down = input.mouse_down && lbutton_phys;
		const bool mouse_clicked = mouse_down && !s_last_mouse_down;
		const bool menu_open = g_menu.is_open( );

		const xui::rect widget_rect{ current_x, current_y, max_w, total_h };
		const bool hovered = menu_open && widget_rect.contains( input.mouse_x, input.mouse_y );

		this->m_spectators_hovered = hovered;

		if ( !menu_open || !mouse_down )
		{
			s_is_dragging = false;
		}

		const bool can_start_drag = menu_open
			&& !this->m_keybinds_dragging
			&& !this->m_teammate_damage_dragging
			&& !xui::ctx( ).overlay_blocking( )
			&& xui::ctx( ).active_window == xui::null_id
			&& xui::ctx( ).active_slider == xui::null_id
			&& xui::ctx( ).active_resize == xui::null_id
			&& xui::ctx( ).active_text_input == xui::null_id
			&& xui::ctx( ).active_child_scroll == xui::null_id;

		if ( can_start_drag && hovered && mouse_clicked )
		{
			s_is_dragging = true;
			s_drag_offset_x = input.mouse_x - current_x;
			s_drag_offset_y = input.mouse_y - current_y;
		}

		if ( s_is_dragging )
		{
			current_x = std::clamp( input.mouse_x - s_drag_offset_x, 0.0f, max_screen_x );
			current_y = std::clamp( input.mouse_y - s_drag_offset_y, 0.0f, max_screen_y );

			widgets_cfg.spectator_x = current_x;
			widgets_cfg.spectator_y = current_y;
		}

		this->m_spectators_dragging = s_is_dragging;
		s_last_mouse_down = mouse_down;

		const auto x = current_x;
		const auto base_ry = current_y;

		// Header drop shadow (watermark style)
		draw_watermark_shadow( x, base_ry, max_w, header_h );

		// Header container
		draw_list.rect_filled( x, base_ry, max_w, header_h, tokens::col_dark.alpha( static_cast< std::uint8_t >( 230.0f * master_alpha ) ), card_r );

		const auto header_border_col = ( menu_open && ( hovered || s_is_dragging ) )
			? s.accent.alpha( static_cast< std::uint8_t >( ( s_is_dragging ? 220.0f : 140.0f ) * master_alpha ) )
			: tokens::col_border.alpha( static_cast< std::uint8_t >( 120.0f * master_alpha ) );
		draw_list.rect( x, base_ry, max_w, header_h, header_border_col, card_r, 1.0f );

		// Top subtle ambient neon reflection line
		const auto half_w = ( max_w - 20.0f ) * 0.5f;
		draw_list.rect_filled_gradient(
			x + 10.0f, base_ry, half_w, 1.2f,
			s.accent.alpha( 0 ),
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) ),
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) ),
			s.accent.alpha( 0 )
		);
		draw_list.rect_filled_gradient(
			x + 10.0f + half_w, base_ry, half_w, 1.2f,
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) ),
			s.accent.alpha( 0 ),
			s.accent.alpha( 0 ),
			s.accent.alpha( static_cast< std::uint8_t >( 170.0f * master_alpha ) )
		);

		// Modern glowing brand indicator on left of header
		const auto dot_cx = x + 13.0f;
		const auto dot_cy = base_ry + header_h * 0.5f;
		draw_list.circle_filled( dot_cx, dot_cy, 4.5f, s.accent.alpha( static_cast< std::uint8_t >( 45.0f * master_alpha ) ) );
		draw_list.circle_filled( dot_cx, dot_cy, 2.2f, s.accent.alpha( static_cast< std::uint8_t >( 240.0f * master_alpha ) ) );
		draw_list.circle_filled( dot_cx, dot_cy, 0.8f, xdraw::color{ 255, 255, 255, static_cast< std::uint8_t >( 240.0f * master_alpha ) } );

		// Header title
		const auto title_x = dot_cx + 8.0f;
		const auto title_y = base_ry + ( header_h - header_th ) * 0.5f - 0.5f;
		draw_list.text( title_x, title_y, "Spectators", tokens::col_text.alpha( static_cast< std::uint8_t >( 245.0f * master_alpha ) ), g_fonts.inter_bold[ fonts::size::petite ] );

		// Rows (separated individual cards)
		if ( count == 0 && g_menu.is_open( ) )
		{
			const auto empty_y = base_ry + header_h + header_gap;
			draw_watermark_shadow( x, empty_y, max_w, row_h );
			draw_list.rect_filled( x, empty_y, max_w, row_h, tokens::col_card.alpha( static_cast< std::uint8_t >( 230.0f * master_alpha ) ), card_r );
			draw_list.rect( x, empty_y, max_w, row_h, tokens::col_border.alpha( static_cast< std::uint8_t >( 100.0f * master_alpha ) ), card_r, 1.0f );

			const auto empty_text = "No spectators";
			const auto [ ew, eh ] = xdraw::measure_text( empty_text );
			draw_list.text( x + ( max_w - ew ) * 0.5f, empty_y + ( row_h - eh ) * 0.5f - 0.5f, empty_text, tokens::col_text_dim.alpha( static_cast< std::uint8_t >( 135.0f * master_alpha ) ) );
		}
		else
		{
			for ( auto i = 0; i < count; ++i )
			{
				const auto& e = entries[ i ];
				const auto row_y = base_ry + header_h + header_gap + static_cast< float >( i ) * ( row_h + row_gap );
				const float nw = e.nw;
				const float nh = e.nh;
				// Include the avatar and shadow overhang when culling off-screen rows.
				if ( row_y + row_h + 5.0f < 0.0f || row_y - 5.0f > static_cast<float>( screen_h ) )
					continue;
				const auto avatar_tex = avatars.get( e.steam_id );

				const auto card_x = x + 4.0f;
				const auto card_w = max_w - 4.0f;

				// Fast single-pass card shadow
				draw_list.rect_filled( card_x - 1.5f, row_y - 1.0f, card_w + 3.0f, row_h + 2.0f,
					xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 45.0f * master_alpha ) }, card_r );
				draw_list.rect_filled( card_x, row_y, card_w, row_h, tokens::col_card.alpha( static_cast< std::uint8_t >( 230.0f * master_alpha ) ), card_r );
				draw_list.rect( card_x, row_y, card_w, row_h, tokens::col_border.alpha( static_cast< std::uint8_t >( 110.0f * master_alpha ) ), card_r, 1.0f );

				// Steam avatar icon: slightly larger than the element background card
				const auto av_x = x;
				const auto av_y = row_y + ( row_h - av_size ) * 0.5f;
				const auto av_r = xdraw::corner_radius{ 6.0f };

				// Avatar fast soft drop shadow
				draw_list.rect_filled( av_x - 1.0f, av_y - 0.5f, av_size + 2.0f, av_size + 2.0f,
					xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 55.0f * master_alpha ) }, av_r );

				if ( avatar_tex )
				{
					draw_list.image( av_x, av_y, av_size, av_size, avatar_tex, av_r, xdraw::color{ 255, 255, 255, static_cast< std::uint8_t >( 255.0f * master_alpha ) } );
					draw_list.rect( av_x, av_y, av_size, av_size, tokens::col_border.alpha( static_cast< std::uint8_t >( 150.0f * master_alpha ) ), av_r, 1.0f );
				}
				else
				{
					draw_list.rect_filled( av_x, av_y, av_size, av_size, tokens::col_elevated.alpha( static_cast< std::uint8_t >( 220.0f * master_alpha ) ), av_r );
					draw_list.rect( av_x, av_y, av_size, av_size, tokens::col_border.alpha( static_cast< std::uint8_t >( 130.0f * master_alpha ) ), av_r, 1.0f );
					const char letter_str[ 2 ] = { static_cast< char >( std::toupper( static_cast< unsigned char >( e.name[ 0 ] ? e.name[ 0 ] : '?' ) ) ), '\0' };
					draw_list.text( av_x + ( av_size - 8.0f ) * 0.5f, av_y + ( av_size - 11.0f ) * 0.5f - 0.5f, letter_str, tokens::col_text_dim.alpha( static_cast< std::uint8_t >( 200.0f * master_alpha ) ) );
				}

				// Name text (SPEC badge removed)
				const float name_x = av_x + av_size + 8.0f;
				draw_list.text( name_x, row_y + ( row_h - nh ) * 0.5f - 0.5f, e.name, tokens::col_text.alpha( static_cast< std::uint8_t >( 245.0f * master_alpha ) ) );
			}
		}
	}

} // namespace rendering
