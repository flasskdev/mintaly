#define NOMINMAX
#include <pch/pch.hpp>
#include "xui.hpp"
#include <external/nlohmann/json.hpp>
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <mutex>

namespace {

	std::mutex pending_input_mutex;
	xui::input_state pending_input;

	struct overlay_storage
	{
		std::vector<std::unique_ptr<xui::overlay>> list{};
		std::unordered_set<std::uintptr_t> touched_this_frame{};
		std::unordered_set<std::uintptr_t> touched_last_frame{};
	};

	static overlay_storage& get_overlays( )
	{
		static overlay_storage s{};
		return s;
	}

	static std::unordered_map<std::uintptr_t, float>& get_anim_states( )
	{
		static std::unordered_map<std::uintptr_t, float> s{};
		return s;
	}

	struct double_click_state
	{
		std::chrono::steady_clock::time_point last_time{};
		float last_x{};
		float last_y{};
	};

	static double_click_state& get_double_click( )
	{
		static double_click_state s{};
		return s;
	}

	static xui::context& get_ctx( )
	{
		static xui::context c{};
		return c;
	}

	static HWND& get_hwnd( )
	{
		static HWND h{ nullptr };
		return h;
	}

	struct highlight_state
	{
		std::string label{};
		std::chrono::steady_clock::time_point expires_at{};
	};

	static highlight_state& get_highlight_state( )
	{
		static highlight_state s{};
		return s;
	}

	static bool clipboard_copy( HWND hwnd, const std::string& text )
	{
		if ( !OpenClipboard( hwnd ) )
		{
			return false;
		}

		EmptyClipboard( );

		const auto size = ( text.size( ) + 1 ) * sizeof( char );
		auto mem = GlobalAlloc( GMEM_MOVEABLE, size );

		if ( !mem )
		{
			CloseClipboard( );
			return false;
		}

		auto dest = GlobalLock( mem );
		if ( dest )
		{
			std::memcpy( dest, text.c_str( ), size );
			GlobalUnlock( mem );
		}

		SetClipboardData( CF_TEXT, mem );
		CloseClipboard( );
		return true;
	}

	static std::string clipboard_paste( HWND hwnd )
	{
		if ( !OpenClipboard( hwnd ) )
		{
			return {};
		}

		std::string result{};
		auto mem = GetClipboardData( CF_TEXT );

		if ( mem )
		{
			auto data = static_cast< const char* >( GlobalLock( mem ) );
			if ( data )
			{
				result = data;
				GlobalUnlock( mem );
			}
		}

		CloseClipboard( );
		return result;
	}

	static float* resolve_style_var( xui::style& s, xui::style_var var )
	{
		switch ( var )
		{
		case xui::style_var::rounding: return &s.rounding;
		case xui::style_var::window_rounding: return &s.window_rounding;
		case xui::style_var::checkbox_rounding: return &s.checkbox_rounding;
		case xui::style_var::slider_rounding: return &s.slider_rounding;
		case xui::style_var::button_rounding: return &s.button_rounding;
		case xui::style_var::keybind_rounding: return &s.keybind_rounding;
		case xui::style_var::combo_rounding: return &s.combo_rounding;
		case xui::style_var::popup_rounding: return &s.popup_rounding;
		case xui::style_var::combo_popup_rounding: return &s.combo_popup_rounding;
		case xui::style_var::picker_popup_rounding: return &s.picker_popup_rounding;
		case xui::style_var::color_swatch_rounding: return &s.color_swatch_rounding;
		case xui::style_var::text_input_rounding: return &s.text_input_rounding;
		case xui::style_var::window_pad_x: return &s.window_pad_x;
		case xui::style_var::window_pad_y: return &s.window_pad_y;
		case xui::style_var::item_spacing_x: return &s.item_spacing_x;
		case xui::style_var::item_spacing_y: return &s.item_spacing_y;
		case xui::style_var::frame_pad_x: return &s.frame_pad_x;
		case xui::style_var::frame_pad_y: return &s.frame_pad_y;
		case xui::style_var::border_thickness: return &s.border_thickness;
		case xui::style_var::checkbox_size: return &s.checkbox_size;
		case xui::style_var::slider_h: return &s.slider_h;
		case xui::style_var::keybind_w: return &s.keybind_w;
		case xui::style_var::keybind_h: return &s.keybind_h;
		case xui::style_var::combo_h: return &s.combo_h;
		case xui::style_var::combo_item_h: return &s.combo_item_h;
		case xui::style_var::swatch_w: return &s.swatch_w;
		case xui::style_var::swatch_h: return &s.swatch_h;
		case xui::style_var::text_input_h: return &s.text_input_h;
		default: return nullptr;
		}
	}

	static xdraw::color* resolve_style_color( xui::style& s, xui::style_col idx )
	{
		switch ( idx )
		{
		case xui::style_col::window_bg: return &s.window_bg;
		case xui::style_col::window_border: return &s.window_border;
		case xui::style_col::child_bg: return &s.child_bg;
		case xui::style_col::child_border: return &s.child_border;
		case xui::style_col::checkbox_bg: return &s.checkbox_bg;
		case xui::style_col::checkbox_border: return &s.checkbox_border;
		case xui::style_col::checkbox_mark: return &s.checkbox_mark;
		case xui::style_col::checkbox_mark_icon: return &s.checkbox_mark_icon;
		case xui::style_col::slider_track: return &s.slider_track;
		case xui::style_col::slider_fill: return &s.slider_fill;
		case xui::style_col::button_bg: return &s.button_bg;
		case xui::style_col::button_border: return &s.button_border;
		case xui::style_col::button_hovered: return &s.button_hovered;
		case xui::style_col::button_active: return &s.button_active;
		case xui::style_col::keybind_bg: return &s.keybind_bg;
		case xui::style_col::keybind_border: return &s.keybind_border;
		case xui::style_col::keybind_waiting: return &s.keybind_waiting;
		case xui::style_col::combo_bg: return &s.combo_bg;
		case xui::style_col::combo_border: return &s.combo_border;
		case xui::style_col::combo_arrow: return &s.combo_arrow;
		case xui::style_col::combo_hovered: return &s.combo_hovered;
		case xui::style_col::combo_popup_bg: return &s.combo_popup_bg;
		case xui::style_col::combo_popup_border: return &s.combo_popup_border;
		case xui::style_col::combo_popup_item_hovered: return &s.combo_popup_item_hovered;
		case xui::style_col::combo_popup_item_selected: return &s.combo_popup_item_selected;
		case xui::style_col::popup_bg: return &s.popup_bg;
		case xui::style_col::popup_border: return &s.popup_border;
		case xui::style_col::picker_bg: return &s.picker_bg;
		case xui::style_col::picker_border: return &s.picker_border;
		case xui::style_col::picker_popup_bg: return &s.picker_popup_bg;
		case xui::style_col::picker_popup_border: return &s.picker_popup_border;
		case xui::style_col::text_input_bg: return &s.text_input_bg;
		case xui::style_col::text_input_border: return &s.text_input_border;
		case xui::style_col::separator: return &s.separator;
		case xui::style_col::text: return &s.text;
		case xui::style_col::text_dim: return &s.text_dim;
		case xui::style_col::accent: return &s.accent;
		default: return nullptr;
		}
	}

} // namespace

namespace xui {

	constexpr rect rect::offset( float dx, float dy ) const noexcept
	{
		return { x + dx, y + dy, w, h };
	}

	constexpr rect rect::expand( float amount ) const noexcept
	{
		return { x - amount, y - amount, w + amount * 2.0f, h + amount * 2.0f };
	}

	constexpr rect rect::shrink( float amount ) const noexcept
	{
		return expand( -amount );
	}

	constexpr rect rect::intersect( const rect& o ) const noexcept
	{
		const auto x0 = ( x > o.x ) ? x : o.x;
		const auto y0 = ( y > o.y ) ? y : o.y;
		const auto x1 = ( right( ) < o.right( ) ) ? right( ) : o.right( );
		const auto y1 = ( bottom( ) < o.bottom( ) ) ? bottom( ) : o.bottom( );
		return { x0, y0, ( x1 > x0 ) ? ( x1 - x0 ) : 0.0f, ( y1 > y0 ) ? ( y1 - y0 ) : 0.0f };
	}


	std::pair<std::string_view, std::string_view> parse_label( std::string_view label ) noexcept
	{
		const auto pos = label.find( "##" );
		if ( pos == std::string_view::npos )
		{
			return { label, label };
		}

		return { label.substr( 0, pos ), label };
	}

	void set_highlight_target( std::string_view label, float duration_seconds )
	{
		auto& hl = get_highlight_state( );
		hl.label = std::string( label );
		hl.expires_at = std::chrono::steady_clock::now( ) + std::chrono::duration_cast< std::chrono::steady_clock::duration >( std::chrono::duration<float>( std::max( duration_seconds, 0.1f ) ) );
	}

	xdraw::color lighten( xdraw::color c, float factor ) noexcept
	{
		return xdraw::color
		{
			static_cast< std::uint8_t >( std::min( c.r * factor, 255.0f ) ),
			static_cast< std::uint8_t >( std::min( c.g * factor, 255.0f ) ),
			static_cast< std::uint8_t >( std::min( c.b * factor, 255.0f ) ),
			c.a
		};
	}

	xdraw::color darken( xdraw::color c, float factor ) noexcept
	{
		return xdraw::color
		{
			static_cast< std::uint8_t >( c.r * factor ),
			static_cast< std::uint8_t >( c.g * factor ),
			static_cast< std::uint8_t >( c.b * factor ),
			c.a
		};
	}

	xdraw::color alpha_mod( xdraw::color c, float a ) noexcept
	{
		return xdraw::color{ c.r, c.g, c.b, static_cast< std::uint8_t >( a * 255.0f ) };
	}

	xdraw::color lerp( xdraw::color a, xdraw::color b, float t ) noexcept
	{
		return xdraw::color
		{
			static_cast< std::uint8_t >( a.r + ( b.r - a.r ) * t ),
			static_cast< std::uint8_t >( a.g + ( b.g - a.g ) * t ),
			static_cast< std::uint8_t >( a.b + ( b.b - a.b ) * t ),
			static_cast< std::uint8_t >( a.a + ( b.a - a.a ) * t )
		};
	}

	hsv rgb_to_hsv( xdraw::color c ) noexcept
	{
		const auto r = c.r / 255.0f;
		const auto g = c.g / 255.0f;
		const auto b = c.b / 255.0f;

		const auto max_c = std::max( { r, g, b } );
		const auto min_c = std::min( { r, g, b } );
		const auto delta = max_c - min_c;

		hsv result{};
		result.v = max_c;
		result.s = ( max_c != 0.0f ) ? ( delta / max_c ) : 0.0f;
		result.a = c.a / 255.0f;

		if ( delta != 0.0f )
		{
			if ( max_c == r )
			{
				result.h = 60.0f * std::fmod( ( g - b ) / delta, 6.0f );
			}
			else if ( max_c == g )
			{
				result.h = 60.0f * ( 2.0f + ( b - r ) / delta );
			}
			else
			{
				result.h = 60.0f * ( 4.0f + ( r - g ) / delta );
			}
		}

		if ( result.h < 0.0f )
		{
			result.h += 360.0f;
		}

		return result;
	}

	xdraw::color hsv_to_rgb( const hsv& c ) noexcept
	{
		const auto ch = c.v * c.s;
		const auto hp = c.h / 60.0f;
		const auto x = ch * ( 1.0f - std::abs( std::fmod( hp, 2.0f ) - 1.0f ) );
		const auto m = c.v - ch;

		float r1, g1, b1;

		if ( hp < 1.0f ) { r1 = ch; g1 = x; b1 = 0.0f; }
		else if ( hp < 2.0f ) { r1 = x; g1 = ch; b1 = 0.0f; }
		else if ( hp < 3.0f ) { r1 = 0.0f; g1 = ch; b1 = x; }
		else if ( hp < 4.0f ) { r1 = 0.0f; g1 = x; b1 = ch; }
		else if ( hp < 5.0f ) { r1 = x; g1 = 0.0f; b1 = ch; }
		else { r1 = ch; g1 = 0.0f; b1 = x; }

		return xdraw::color
		{
			static_cast< std::uint8_t >( ( r1 + m ) * 255.0f ),
			static_cast< std::uint8_t >( ( g1 + m ) * 255.0f ),
			static_cast< std::uint8_t >( ( b1 + m ) * 255.0f ),
			static_cast< std::uint8_t >( c.a * 255.0f )
		};
	}

	xdraw::color hsv_to_rgb( float h, float s, float v, float a ) noexcept
	{
		return hsv_to_rgb( hsv{ h, s, v, a } );
	}

	std::string color_to_hex( xdraw::color c, bool include_alpha ) noexcept
	{
		char buf[ 16 ]{};

		if ( include_alpha && c.a != 255 )
		{
			std::snprintf( buf, sizeof( buf ), "#%02X%02X%02X%02X", c.r, c.g, c.b, c.a );
		}
		else
		{
			std::snprintf( buf, sizeof( buf ), "#%02X%02X%02X", c.r, c.g, c.b );
		}

		return std::string{ buf };
	}

	std::optional<xdraw::color> hex_to_color( std::string_view hex ) noexcept
	{
		if ( hex.empty( ) )
		{
			return std::nullopt;
		}

		if ( hex.front( ) == '#' )
		{
			hex.remove_prefix( 1 );
		}

		while ( !hex.empty( ) && ( hex.back( ) == ' ' || hex.back( ) == '\r' || hex.back( ) == '\n' || hex.back( ) == '\t' ) )
		{
			hex.remove_suffix( 1 );
		}

		const auto parse_byte = [ ]( char hi, char lo ) -> std::optional<std::uint8_t>
			{
				const auto nibble = [ ]( char c ) -> int
					{
						if ( c >= '0' && c <= '9' ) return c - '0';
						if ( c >= 'a' && c <= 'f' ) return 10 + c - 'a';
						if ( c >= 'A' && c <= 'F' ) return 10 + c - 'A';
						return -1;
					};

				const auto h = nibble( hi );
				const auto l = nibble( lo );

				if ( h < 0 || l < 0 )
				{
					return std::nullopt;
				}

				return static_cast< std::uint8_t >( h * 16 + l );
			};

		if ( hex.size( ) == 6 )
		{
			const auto r = parse_byte( hex[ 0 ], hex[ 1 ] );
			const auto g = parse_byte( hex[ 2 ], hex[ 3 ] );
			const auto b = parse_byte( hex[ 4 ], hex[ 5 ] );

			if ( r && g && b )
			{
				return xdraw::color{ *r, *g, *b, 255 };
			}
		}
		else if ( hex.size( ) == 8 )
		{
			const auto r = parse_byte( hex[ 0 ], hex[ 1 ] );
			const auto g = parse_byte( hex[ 2 ], hex[ 3 ] );
			const auto b = parse_byte( hex[ 4 ], hex[ 5 ] );
			const auto a = parse_byte( hex[ 6 ], hex[ 7 ] );

			if ( r && g && b && a )
			{
				return xdraw::color{ *r, *g, *b, *a };
			}
		}
		else if ( hex.size( ) == 3 )
		{
			const auto nibble = [ ]( char c ) -> int
				{
					if ( c >= '0' && c <= '9' ) return c - '0';
					if ( c >= 'a' && c <= 'f' ) return 10 + c - 'a';
					if ( c >= 'A' && c <= 'F' ) return 10 + c - 'A';
					return -1;
				};

			const auto r = nibble( hex[ 0 ] );
			const auto g = nibble( hex[ 1 ] );
			const auto b = nibble( hex[ 2 ] );

			if ( r >= 0 && g >= 0 && b >= 0 )
			{
				return xdraw::color
				{
					static_cast< std::uint8_t >( r * 17 ),
					static_cast< std::uint8_t >( g * 17 ),
					static_cast< std::uint8_t >( b * 17 ),
					255
				};
			}
		}

		return std::nullopt;
	}

	namespace ease {

		float linear( float t ) noexcept { return t; }
		float in_quad( float t ) noexcept { return t * t; }
		float out_quad( float t ) noexcept { return t * ( 2.0f - t ); }
		float in_out_quad( float t ) noexcept { return t < 0.5f ? 2.0f * t * t : -1.0f + ( 4.0f - 2.0f * t ) * t; }
		float in_cubic( float t ) noexcept { return t * t * t; }
		float out_cubic( float t ) noexcept { const auto f = t - 1.0f; return f * f * f + 1.0f; }
		float in_out_cubic( float t ) noexcept { return t < 0.5f ? 4.0f * t * t * t : 1.0f - std::pow( -2.0f * t + 2.0f, 3.0f ) / 2.0f; }
		float smoothstep( float t ) noexcept { return t * t * ( 3.0f - 2.0f * t ); }

	} // namespace ease

	std::span<const wchar_t> input_state::chars( ) const noexcept
	{
		return std::span( this->char_queue.data( ), this->char_count );
	}

	std::span<const int> input_state::key_presses( ) const noexcept
	{
		return std::span( this->key_press_queue.data( ), this->key_press_count );
	}

	std::span<const int> input_state::key_releases( ) const noexcept
	{
		return std::span( this->key_release_queue.data( ), this->key_release_count );
	}

	bool input_state::key_down( int vk ) const noexcept
	{
		const auto it = this->keys.find( vk );
		return it != this->keys.end( ) && it->second;
	}

	bool input_state::shift_held( ) const noexcept
	{
		return this->key_down( VK_SHIFT ) || this->key_down( VK_LSHIFT ) || this->key_down( VK_RSHIFT );
	}

	bool input_state::ctrl_held( ) const noexcept
	{
		return this->key_down( VK_CONTROL ) || this->key_down( VK_LCONTROL ) || this->key_down( VK_RCONTROL );
	}

	void input_state::push_char( wchar_t c )
	{
		if ( this->char_count < this->char_queue.size( ) )
		{
			this->char_queue[ this->char_count++ ] = c;
		}
	}

	void input_state::push_key_press( int vk )
	{
		if ( this->key_press_count < this->key_press_queue.size( ) )
		{
			this->key_press_queue[ this->key_press_count++ ] = vk;
		}
	}

	void input_state::push_key_release( int vk )
	{
		if ( this->key_release_count < this->key_release_queue.size( ) )
		{
			this->key_release_queue[ this->key_release_count++ ] = vk;
		}
	}

	void input_state::clear_frame( )
	{
		this->prev_mouse_x = this->mouse_x;
		this->prev_mouse_y = this->mouse_y;

		this->mouse_clicked = false;
		this->mouse_released = false;
		this->mouse_double_clicked = false;

		this->rmb_clicked = false;
		this->rmb_released = false;

		this->scroll_delta = 0.0f;

		this->char_count = 0;
		this->key_press_count = 0;
		this->key_release_count = 0;
	}

	bool feed_wndproc( input_state& s, UINT msg, WPARAM wp, LPARAM lp )
	{
		switch ( msg )
		{
		case WM_MOUSEMOVE:
			s.mouse_x = static_cast< float >( static_cast< short >( LOWORD( lp ) ) );
			s.mouse_y = static_cast< float >( static_cast< short >( HIWORD( lp ) ) );
			return true;

		case WM_LBUTTONDOWN:
		case WM_LBUTTONDBLCLK:
			s.mouse_x = static_cast<float>( static_cast<short>( LOWORD( lp ) ) );
			s.mouse_y = static_cast<float>( static_cast<short>( HIWORD( lp ) ) );
			s.mouse_down = true;
			s.mouse_clicked = true;
			return true;

		case WM_LBUTTONUP:
			s.mouse_down = false;
			s.mouse_released = true;
			return true;

		case WM_RBUTTONDOWN:
		case WM_RBUTTONDBLCLK:
			s.mouse_x = static_cast<float>( static_cast<short>( LOWORD( lp ) ) );
			s.mouse_y = static_cast<float>( static_cast<short>( HIWORD( lp ) ) );
			s.rmb_down = true;
			s.rmb_clicked = true;
			return true;

		case WM_RBUTTONUP:
			s.rmb_down = false;
			s.rmb_released = true;
			return true;

		case WM_KILLFOCUS:
			s.keys.clear( );
			s.mouse_down = s.rmb_down = false;
			s.mouse_clicked = s.rmb_clicked = false;
			s.mouse_released = s.rmb_released = true;
			return true;

		case WM_MOUSEWHEEL:
		{
			const auto delta = static_cast< float >( GET_WHEEL_DELTA_WPARAM( wp ) ) / static_cast< float >( WHEEL_DELTA );
			s.scroll_delta += delta;
			return true;
		}

		case WM_CHAR:
		{
			const auto c = static_cast< wchar_t >( wp );
			if ( c >= 32 && c != 127 )
			{
				s.push_char( c );
			}

			return true;
		}

		case WM_KEYDOWN:
		case WM_SYSKEYDOWN:
		{
			auto vk = static_cast< int >( wp );
			const auto scancode = static_cast< UINT >( ( lp >> 16 ) & 0xFF );
			const bool extended = ( lp >> 24 ) & 1;

			switch ( vk )
			{
			case VK_SHIFT:
				vk = static_cast< int >( MapVirtualKeyW( scancode, MAPVK_VSC_TO_VK_EX ) );
				break;
			case VK_CONTROL:
				vk = extended ? VK_RCONTROL : VK_LCONTROL;
				break;
			case VK_MENU:
				vk = extended ? VK_RMENU : VK_LMENU;
				break;
			}

			if ( !s.key_down( vk ) )
			{
				s.push_key_press( vk );
				s.keys[ vk ] = true;
			}

			return true;
		}

		case WM_KEYUP:
		case WM_SYSKEYUP:
		{
			auto vk = static_cast< int >( wp );
			const auto scancode = static_cast< UINT >( ( lp >> 16 ) & 0xFF );
			const bool extended = ( lp >> 24 ) & 1;

			switch ( vk )
			{
			case VK_SHIFT:
				vk = static_cast< int >( MapVirtualKeyW( scancode, MAPVK_VSC_TO_VK_EX ) );
				break;
			case VK_CONTROL:
				vk = extended ? VK_RCONTROL : VK_LCONTROL;
				break;
			case VK_MENU:
				vk = extended ? VK_RMENU : VK_LMENU;
				break;
			}

			s.push_key_release( vk );
			s.keys[ vk ] = false;
			return true;
		}

		case WM_MBUTTONDOWN:
			s.push_key_press( VK_MBUTTON );
			s.keys[ VK_MBUTTON ] = true;
			return true;

		case WM_MBUTTONUP:
			s.push_key_release( VK_MBUTTON );
			s.keys[ VK_MBUTTON ] = false;
			return true;

		case WM_XBUTTONDOWN:
		{
			const auto button = GET_XBUTTON_WPARAM( wp );
			const auto vk = ( button == XBUTTON1 ) ? VK_XBUTTON1 : VK_XBUTTON2;
			s.push_key_press( vk );
			s.keys[ vk ] = true;
			return true;
		}

		case WM_XBUTTONUP:
		{
			const auto button = GET_XBUTTON_WPARAM( wp );
			const auto vk = ( button == XBUTTON1 ) ? VK_XBUTTON1 : VK_XBUTTON2;
			s.push_key_release( vk );
			s.keys[ vk ] = false;
			return true;
		}

		default:
			return false;
		}
	}

	void push_style_var( style_var var, float value )
	{
		auto& c = get_ctx( );
		auto ptr = resolve_style_var( c.style, var );

		if ( !ptr )
		{
			return;
		}

		c.style_var_stack.push_back( { var, *ptr } );
		*ptr = value;
	}

	void pop_style_var( int count )
	{
		auto& c = get_ctx( );

		for ( int i = 0; i < count && !c.style_var_stack.empty( ); ++i )
		{
			const auto& [var, prev] = c.style_var_stack.back( );
			auto ptr = resolve_style_var( c.style, var );

			if ( ptr )
			{
				*ptr = prev;
			}

			c.style_var_stack.pop_back( );
		}
	}

	void push_style_color( style_col idx, xdraw::color col )
	{
		auto& c = get_ctx( );
		auto ptr = resolve_style_color( c.style, idx );

		if ( !ptr )
		{
			return;
		}

		c.style_color_stack.push_back( { idx, *ptr } );
		*ptr = col;
	}

	void pop_style_color( int count )
	{
		auto& c = get_ctx( );

		for ( int i = 0; i < count && !c.style_color_stack.empty( ); ++i )
		{
			const auto& [idx, prev] = c.style_color_stack.back( );
			auto ptr = resolve_style_color( c.style, idx );

			if ( ptr )
			{
				*ptr = prev;
			}

			c.style_color_stack.pop_back( );
		}
	}

	namespace anim {

		float lerp( std::uintptr_t id, float target, float speed, float initial )
		{
			auto& states = get_anim_states( );
			auto it = states.find( id );

			if ( it == states.end( ) )
			{
				it = states.emplace( id, initial ).first;
			}

			const auto dt = xdraw::delta_time( );
			it->second = it->second + ( target - it->second ) * std::min( speed * dt, 1.0f );
			return it->second;
		}

		float smooth( std::uintptr_t id, float target, float speed, float initial )
		{
			const auto raw = lerp( id, target, speed, initial );
			return raw * raw * ( 3.0f - 2.0f * raw );
		}

		float get( std::uintptr_t id, float fallback )
		{
			const auto& states = get_anim_states( );
			const auto it = states.find( id );
			return ( it != states.end( ) ) ? it->second : fallback;
		}

		void set( std::uintptr_t id, float value )
		{
			get_anim_states( )[ id ] = value;
		}

		void remove( std::uintptr_t id )
		{
			get_anim_states( ).erase( id );
		}

		void clear_all( )
		{
			get_anim_states( ).clear( );
		}

	} // namespace anim

	namespace binds {

		namespace {

			struct bind_registry
			{
				std::vector<xui::setting*> settings{};
				std::unordered_map<int, bool> prev_key_state{};
				std::uintptr_t listening_setting{};
				std::uint64_t activation_counter{};
			};

			bind_registry& get_bind_registry( )
			{
				static bind_registry r{};
				return r;
			}

		} // the bind_registry namespace

		void register_setting( setting* s )
		{
			if ( !s )
			{
				return;
			}

			auto& reg = get_bind_registry( );

			for ( const auto existing : reg.settings )
			{
				if ( existing == s )
				{
					return;
				}
			}

			if ( s->bind.key != 0 && s->bind.mode == bind_mode::toggle )
			{
				s->bind.active = s->value;
			}

			reg.settings.push_back( s );
		}

		void unregister_setting( setting* s )
		{
			auto& reg = get_bind_registry( );
			auto& v = reg.settings;
			v.erase( std::remove( v.begin( ), v.end( ), s ), v.end( ) );
		}

		void process( const input_state& input )
		{
			auto& reg = get_bind_registry( );

			for ( auto* s : reg.settings )
			{
				if ( !s || s->bind.key == 0 )
				{
					continue;
				}

				const auto vk = s->bind.key;
				const auto held = input.key_down( vk );
				const auto was_held = reg.prev_key_state[ vk ];
				const auto just_pressed = held && !was_held;

				switch ( s->bind.mode )
				{
				case bind_mode::toggle:
				{
					if ( just_pressed )
					{
						if ( s->bind.excludes && s->bind.excludes->value )
						{
							s->bind.excludes->bind.active = false;
							s->bind.excludes->value = false;
						}

						s->bind.active = !s->bind.active;
						s->value = s->bind.active;
					}

					break;
				}
				case bind_mode::hold_on:
				{
					s->bind.active = held;
					s->value = held;

					if ( s->bind.active && s->bind.excludes )
					{
						s->bind.excludes->bind.active = false;
						s->bind.excludes->value = false;
					}

					break;
				}
				case bind_mode::hold_off:
				{
					s->bind.active = !held;
					s->value = !held;
					break;
				}
				}
			}

			for ( auto* s : reg.settings )
			{
				if ( !s || !s->bind.excludes )
				{
					continue;
				}

				if ( s->value && s->bind.excludes->value )
				{
					s->bind.excludes->value = false;
					s->bind.excludes->bind.active = false;
				}
			}

			for ( auto* s : reg.settings )
			{
				if ( s && s->bind.key != 0 )
				{
					reg.prev_key_state[ s->bind.key ] = input.key_down( s->bind.key );
				}
			}
		}

		std::span<setting* const> all( )
		{
			return get_bind_registry( ).settings;
		}

		std::size_t count( )
		{
			return get_bind_registry( ).settings.size( );
		}

		void clear_all( )
		{
			auto& reg = get_bind_registry( );
			reg.settings.clear( );
			reg.prev_key_state.clear( );
			reg.listening_setting = 0;
			reg.activation_counter = 0;
		}

		std::uintptr_t listening_id( )
		{
			return get_bind_registry( ).listening_setting;
		}

		const char* mode_name( bind_mode m ) noexcept
		{
			switch ( m )
			{
			case bind_mode::toggle:   return "toggle";
			case bind_mode::hold_on:  return "hold on";
			case bind_mode::hold_off: return "hold off";
			default:                  return "unknown";
			}
		}

	} // namespace binds

	popup_overlay::popup_overlay( std::uintptr_t id, const rect& anchor, float width, const rect& parent_bounds ) : overlay{ id, anchor }, m_width{ width }, m_parent_bounds{ parent_bounds } { }

	bool popup_overlay::hit_test( float x, float y ) const
	{
		return this->get_popup( ).contains( x, y ) || this->m_anchor.contains( x, y );
	}

	bool popup_overlay::process_input( const input_state& input )
	{
		if ( this->m_closing )
		{
			return false;
		}

		const auto popup = this->get_popup( );
		if ( input.mouse_clicked && !popup.contains( input.mouse_x, input.mouse_y ) && !this->m_anchor.contains( input.mouse_x, input.mouse_y ) )
		{
			this->m_closing = true;
			return true;
		}

		return popup.contains( input.mouse_x, input.mouse_y );
	}

	void popup_overlay::render( const style&, const input_state& ) {}

	void popup_overlay::tick( )
	{
		const auto dt = xdraw::delta_time( );
		const auto speed = this->m_closing ? 16.0f : 14.0f;
		const auto target = this->m_closing ? 0.0f : 1.0f;

		this->m_open_anim += ( target - this->m_open_anim ) * std::min( speed * dt, 1.0f );
		if ( this->m_open_anim < 0.01f && this->m_closing )
		{
			this->m_closed = true;
		}
	}

	void popup_overlay::set_content_h( float h ) { this->m_content_h = h; }
	float popup_overlay::open_anim( ) const { return this->m_open_anim; }
	bool popup_overlay::closing( ) const { return this->m_closing; }

	rect popup_overlay::get_popup( ) const
	{
		const auto [vw, vh] = xdraw::viewport_size( );
		float max_h = 520.0f;
		if ( vh > 0 )
		{
			max_h = std::max( 300.0f, std::min( 600.0f, static_cast< float >( vh ) - 60.0f ) );
		}
		const auto clamped = std::min( this->m_content_h, max_h );

		auto px = this->m_anchor.x;
		if ( this->m_parent_bounds.w > 0.0f )
		{
			if ( px + this->m_width > this->m_parent_bounds.right( ) - 10.0f )
			{
				px = this->m_parent_bounds.right( ) - 10.0f - this->m_width;
			}
			if ( px < this->m_parent_bounds.x + 10.0f )
			{
				px = this->m_parent_bounds.x + 10.0f;
			}
		}
		else if ( vw > 0 && px + this->m_width > static_cast< float >( vw ) - 10.0f )
		{
			px = this->m_anchor.right( ) - this->m_width;
		}

		if ( vw > 0 && px + this->m_width > static_cast< float >( vw ) - 10.0f )
		{
			px = static_cast< float >( vw ) - 10.0f - this->m_width;
		}
		if ( px < 10.0f )
		{
			px = 10.0f;
		}

		auto py = this->m_anchor.bottom( ) + 4.0f;
		if ( vh > 0 && py + clamped > static_cast< float >( vh ) - 10.0f )
		{
			py = this->m_anchor.y - clamped - 4.0f;
		}
		if ( vh > 0 && py + clamped > static_cast< float >( vh ) - 10.0f )
		{
			py = static_cast< float >( vh ) - 10.0f - clamped;
		}
		if ( py < 10.0f )
		{
			py = 10.0f;
		}

		return { px, py, this->m_width, clamped };
	}

	namespace overlays {

		bool is_open( std::uintptr_t id )
		{
			auto& store = get_overlays( );

			for ( const auto& o : store.list )
			{
				if ( o && o->id( ) == id && !o->is_closing( ) )
				{
					return true;
				}
			}

			return false;
		}

		overlay* find( std::uintptr_t id )
		{
			auto& store = get_overlays( );

			for ( auto& o : store.list )
			{
				if ( o && o->id( ) == id )
				{
					return o.get( );
				}
			}

			return nullptr;
		}

		void close( std::uintptr_t id )
		{
			auto& store = get_overlays( );

			for ( auto& o : store.list )
			{
				if ( o && o->id( ) == id )
				{
					o->request_close( );
					break;
				}
			}
		}

		void close_all( )
		{
			auto& store = get_overlays( );

			for ( auto& o : store.list )
			{
				if ( o )
				{
					o->request_close( );
				}
			}
		}

		void touch( std::uintptr_t owner_id )
		{
			get_overlays( ).touched_this_frame.insert( owner_id );
		}

		bool wants_input( float x, float y )
		{
			auto& store = get_overlays( );

			for ( const auto& o : store.list )
			{
				if ( o && o->hit_test( x, y ) )
				{
					return true;
				}
			}

			return false;
		}

		bool has_any( )
		{
			return !get_overlays( ).list.empty( );
		}

		bool has_any_except( std::uintptr_t exclude )
		{
			auto& store = get_overlays( );

			for ( const auto& o : store.list )
			{
				if ( o && o->id( ) != exclude && !o->is_closed( ) )
				{
					return true;
				}
			}

			return false;
		}

		void process( const input_state& input )
		{
			auto& store = get_overlays( );

			for ( auto it = store.list.rbegin( ); it != store.list.rend( ); ++it )
			{
				if ( *it && ( *it )->process_input( input ) )
				{
					return;
				}
			}
		}

		void render( const style& style, const input_state& input )
		{
			auto& store = get_overlays( );

			for ( auto& o : store.list )
			{
				if ( o )
				{
					o->render( style, input );
				}
			}
		}

		void sweep( )
		{
			auto& store = get_overlays( );

			for ( auto& o : store.list )
			{
				if ( !o || o->is_closing( ) || o->is_closed( ) )
				{
					continue;
				}

				const auto id = o->id( );

				if ( store.touched_last_frame.contains( id ) && !store.touched_this_frame.contains( id ) )
				{
					o->request_close( );
				}
			}

			store.list.erase( std::remove_if( store.list.begin( ), store.list.end( ), [ ]( const std::unique_ptr<overlay>& o ) { return !o || o->is_closed( ); } ), store.list.end( ) );
			store.touched_last_frame = std::move( store.touched_this_frame );
			store.touched_this_frame.clear( );
		}

		void add( std::unique_ptr<overlay> ov )
		{
			get_overlays( ).list.push_back( std::move( ov ) );
		}

	} // namespace overlays

	void push_id( std::uintptr_t id )
	{
		get_ctx( ).id_stack.push_back( id );
	}

	void push_id( std::string_view sv )
	{
		push_id( fnv1a( sv ) );
	}

	void push_id( const void* ptr )
	{
		push_id( reinterpret_cast< std::uintptr_t >( ptr ) );
	}

	void pop_id( )
	{
		auto& stack = get_ctx( ).id_stack;
		if ( !stack.empty( ) )
		{
			stack.pop_back( );
		}
	}

	std::uintptr_t make_id( std::string_view label )
	{
		auto h = fnv1a( label );

		for ( const auto parent : get_ctx( ).id_stack )
		{
			h ^= parent;
			h *= 1099511628211ull;
		}

		return h;
	}

	namespace draw {

		xdraw::draw_list& current( )
		{
			auto& c = get_ctx( );
			if ( !c.layer_stack.empty( ) )
			{
				return xdraw::get( c.layer_stack.back( ) );
			}

			return xdraw::get( );
		}

		void push_layer( xdraw::layer l )
		{
			get_ctx( ).layer_stack.push_back( l );
		}

		void pop_layer( )
		{
			auto& stack = get_ctx( ).layer_stack;
			if ( !stack.empty( ) )
			{
				stack.pop_back( );
			}
		}

	} // namespace draw

	namespace layout {

		window_state* current_window( )
		{
			auto& wins = get_ctx( ).windows;
			return wins.empty( ) ? nullptr : &wins.back( );
		}

		const window_state* current_window_const( )
		{
			const auto& wins = get_ctx( ).windows;
			return wins.empty( ) ? nullptr : &wins.back( );
		}

		std::pair<float, float> avail( )
		{
			const auto win = current_window_const( );
			if ( !win )
			{
				return { 0.0f, 0.0f };
			}

			const auto& s = get_ctx( ).style;
			const auto max_x = win->bounds.w - s.window_pad_x;
			const auto max_y = win->bounds.h - s.window_pad_y;

			auto next_x = win->cursor_x;
			auto next_y = win->cursor_y;

			if ( win->line_h > 0.0f )
			{
				next_y += win->line_h + s.item_spacing_y;
			}

			return
			{
				std::max( 0.0f, max_x - next_x ),
				std::max( 0.0f, max_y - next_y )
			};
		}

		float item_width( int count )
		{
			const auto [aw, ah] = avail( );

			if ( count <= 0 )
			{
				return aw;
			}

			const auto spacing = get_ctx( ).style.item_spacing_x;
			return ( aw - spacing * ( count - 1 ) ) / static_cast< float >( count );
		}

		rect item( float w, float h, float label_h )
		{
			auto win = current_window( );
			if ( !win )
			{
				return { 0, 0, 0, 0 };
			}

			if ( win->line_h > 0.0f )
			{
				auto spacing = get_ctx( ).style.item_spacing_y;

				if ( label_h > 0.0f )
				{
					spacing = std::max( spacing * 0.5f, spacing - label_h * 0.25f );
				}

				win->cursor_y += win->line_h + spacing;
			}

			const auto local = rect{ win->cursor_x, win->cursor_y, w, h };
			win->last_item = local;
			win->last_item_is_toggle = false;
			win->last_toggle_x = 0.0f;
			win->line_h = h;
			win->content_h = std::max( win->content_h, win->cursor_y + h );

			return rect
			{
				std::floorf( local.x + win->bounds.x ),
				std::floorf( local.y + win->bounds.y ),
				std::floorf( local.w ),
				std::floorf( local.h )
			};
		}

		void same_line( float offset )
		{
			auto win = current_window( );
			if ( !win || win->line_h <= 0.0f )
			{
				return;
			}

			const auto spacing = ( offset == 0.0f ) ? get_ctx( ).style.item_spacing_x : offset;
			win->cursor_x = win->last_item.x + win->last_item.w + spacing;
			win->cursor_y = win->last_item.y;
			win->line_h = 0.0f;
		}

		void new_line( )
		{
			auto win = current_window( );
			if ( !win )
			{
				return;
			}

			if ( win->line_h > 0.0f )
			{
				win->cursor_y += win->line_h + get_ctx( ).style.item_spacing_y;
			}

			win->cursor_x = get_ctx( ).style.window_pad_x;
			win->line_h = 0.0f;
		}

		void spacing( float amount )
		{
			auto win = current_window( );
			if ( !win )
			{
				return;
			}

			if ( amount <= 0.0f )
			{
				amount = get_ctx( ).style.item_spacing_y;
			}

			win->cursor_y += amount;
		}

		void indent( float amount )
		{
			auto win = current_window( );
			if ( !win )
			{
				return;
			}

			if ( amount <= 0.0f )
			{
				amount = get_ctx( ).style.window_pad_x;
			}

			win->cursor_x += amount;
		}

		void unindent( float amount )
		{
			auto win = current_window( );
			if ( !win )
			{
				return;
			}

			if ( amount <= 0.0f )
			{
				amount = get_ctx( ).style.window_pad_x;
			}

			win->cursor_x = std::max( get_ctx( ).style.window_pad_x, win->cursor_x - amount );
		}

		void separator( )
		{
			auto win = current_window( );
			if ( !win )
			{
				return;
			}

			const auto& s = get_ctx( ).style;
			const auto sep_pad = s.item_spacing_y * 0.5f;

			if ( win->line_h > 0.0f )
			{
				win->cursor_y += win->line_h + s.item_spacing_y;
				win->line_h = 0.0f;
			}

			const auto max_x = win->bounds.w - s.window_pad_x;
			const auto w = std::max( 0.0f, max_x - win->cursor_x );
			const auto abs = item( w, 1.0f + sep_pad * 2.0f );

			draw::current( ).line( abs.x, abs.y + sep_pad, abs.x + w, abs.y + sep_pad, s.separator, 1.0f );
		}

		void set_cursor( float x, float y )
		{
			auto win = current_window( );
			if ( !win )
			{
				return;
			}

			win->cursor_x = x;
			win->cursor_y = y;
			win->line_h = 0.0f;
		}

		std::pair<float, float> get_cursor( )
		{
			const auto win = current_window_const( );
			if ( !win )
			{
				return { 0.0f, 0.0f };
			}

			return { win->cursor_x, win->cursor_y };
		}

	} // namespace layout

	bool context::overlay_blocking( ) const
	{
		if ( this->inside_overlay != null_id )
		{
			return overlays::has_any_except( this->inside_overlay );
		}

		return overlays::has_any( ) || this->modal_blocking;
	}

	context& ctx( )
	{
		return get_ctx( );
	}

	std::string_view truncate( std::string_view text, float max_width )
	{
		const auto [tw, th] = xdraw::measure_text( text );
		if ( tw <= max_width )
		{
			return text;
		}

		const auto [ew, eh] = xdraw::measure_text( "..." );
		if ( max_width < ew )
		{
			return "...";
		}

		const auto avail = max_width - ew;

		std::size_t lo{ 0 };
		std::size_t hi = text.size( );
		std::size_t best{ 0 };

		while ( lo <= hi && hi != static_cast< std::size_t >( -1 ) )
		{
			const auto mid = lo + ( hi - lo ) / 2;
			const auto [cw, ch] = xdraw::measure_text( text.substr( 0, mid ) );

			if ( cw <= avail )
			{
				best = mid;
				lo = mid + 1;
			}
			else
			{
				hi = mid - 1;
			}
		}

		auto& scratch = get_ctx( ).truncation_scratch;
		scratch.clear( );
		scratch.reserve( best + 3 );
		scratch.assign( text.data( ), best );
		scratch.append( "..." );
		return scratch;
	}

	const char* vk_name( int key )
	{
		if ( key == 0 )
		{
			return "none";
		}

		if ( key >= 0x41 && key <= 0x5A )
		{
			static char buf[ 2 ]{};
			buf[ 0 ] = static_cast< char >( std::tolower( key ) );
			buf[ 1 ] = '\0';
			return buf;
		}

		if ( key >= 0x30 && key <= 0x39 )
		{
			static char buf[ 2 ]{};
			buf[ 0 ] = static_cast< char >( key );
			buf[ 1 ] = '\0';
			return buf;
		}

		switch ( key )
		{
		// Mouse buttons
		case VK_LBUTTON: return "lmb";
		case VK_RBUTTON: return "rmb";
		case VK_MBUTTON: return "mmb";
		case VK_XBUTTON1: return "mb4";
		case VK_XBUTTON2: return "mb5";

		// Common control & edit keys
		case VK_BACK: return "back";
		case VK_TAB: return "tab";
		case VK_RETURN: return "enter";
		case VK_ESCAPE: return "esc";
		case VK_SPACE: return "space";
		case VK_CAPITAL: return "caps";
		case VK_SHIFT: case VK_LSHIFT: case VK_RSHIFT: return "shift";
		case VK_CONTROL: case VK_LCONTROL: case VK_RCONTROL: return "ctrl";
		case VK_MENU: case VK_LMENU: case VK_RMENU: return "alt";
		case VK_PAUSE: return "pause";
		case VK_PRIOR: return "pgup";
		case VK_NEXT: return "pgdn";
		case VK_END: return "end";
		case VK_HOME: return "home";
		case VK_LEFT: return "left";
		case VK_UP: return "up";
		case VK_RIGHT: return "right";
		case VK_DOWN: return "down";
		case VK_SNAPSHOT: return "prtsc";
		case VK_INSERT: return "insert";
		case VK_DELETE: return "delete";
		case VK_LWIN: return "lwin";
		case VK_RWIN: return "rwin";
		case VK_APPS: return "apps";

		// Numpad keys
		case VK_NUMPAD0: return "num0";
		case VK_NUMPAD1: return "num1";
		case VK_NUMPAD2: return "num2";
		case VK_NUMPAD3: return "num3";
		case VK_NUMPAD4: return "num4";
		case VK_NUMPAD5: return "num5";
		case VK_NUMPAD6: return "num6";
		case VK_NUMPAD7: return "num7";
		case VK_NUMPAD8: return "num8";
		case VK_NUMPAD9: return "num9";
		case VK_MULTIPLY: return "num*";
		case VK_ADD: return "num+";
		case VK_SEPARATOR: return "num sep";
		case VK_SUBTRACT: return "num-";
		case VK_DECIMAL: return "num.";
		case VK_DIVIDE: return "num/";
		case VK_NUMLOCK: return "numlk";
		case VK_SCROLL: return "scrlk";

		// Function keys
		case VK_F1: return "f1";
		case VK_F2: return "f2";
		case VK_F3: return "f3";
		case VK_F4: return "f4";
		case VK_F5: return "f5";
		case VK_F6: return "f6";
		case VK_F7: return "f7";
		case VK_F8: return "f8";
		case VK_F9: return "f9";
		case VK_F10: return "f10";
		case VK_F11: return "f11";
		case VK_F12: return "f12";
		case VK_F13: return "f13";
		case VK_F14: return "f14";
		case VK_F15: return "f15";
		case VK_F16: return "f16";
		case VK_F17: return "f17";
		case VK_F18: return "f18";
		case VK_F19: return "f19";
		case VK_F20: return "f20";
		case VK_F21: return "f21";
		case VK_F22: return "f22";
		case VK_F23: return "f23";
		case VK_F24: return "f24";

		// Standard OEM punctuation & symbols
		case VK_OEM_1: return ";";
		case VK_OEM_PLUS: return "=";
		case VK_OEM_COMMA: return ",";
		case VK_OEM_MINUS: return "-";
		case VK_OEM_PERIOD: return ".";
		case VK_OEM_2: return "/";
		case VK_OEM_3: return "~";
		case VK_OEM_4: return "[";
		case VK_OEM_5: return "\\";
		case VK_OEM_6: return "]";
		case VK_OEM_7: return "'";
		case VK_OEM_102: return "\\";
		}

		// Windows API GetKeyNameTextA fallback for any other keyboard layout keys
		const UINT scan = MapVirtualKeyA( static_cast< UINT >( key ), MAPVK_VK_TO_VSC );
		if ( scan != 0 )
		{
			LONG param = static_cast< LONG >( scan << 16 );
			if ( key == VK_LEFT || key == VK_UP || key == VK_RIGHT || key == VK_DOWN ||
				 key == VK_PRIOR || key == VK_NEXT || key == VK_END || key == VK_HOME ||
				 key == VK_INSERT || key == VK_DELETE || key == VK_DIVIDE || key == VK_NUMLOCK ||
				 key == VK_RCONTROL || key == VK_RMENU )
			{
				param |= ( 1 << 24 );
			}

			static char sys_name[ 32 ]{};
			if ( GetKeyNameTextA( param, sys_name, sizeof( sys_name ) ) > 0 )
			{
				for ( char* p = sys_name; *p; ++p )
				{
					*p = static_cast< char >( std::tolower( static_cast< unsigned char >( *p ) ) );
				}
				return sys_name;
			}
		}

		// Fallback to hex code if key is unrecognized non-zero
		static char hex_buf[ 16 ]{};
		std::snprintf( hex_buf, sizeof( hex_buf ), "vk%02x", key & 0xFF );
		return hex_buf;
	}

	bool initialize( HWND hwnd )
	{
		get_hwnd( ) = hwnd;
		return hwnd != nullptr;
	}

	void begin( )
	{
		auto& c = get_ctx( );
		{
			std::lock_guard lock( pending_input_mutex );
			c.input = pending_input;
			pending_input.clear_frame( );
		}

		{
			auto& dc = get_double_click( );
			c.input.mouse_double_clicked = false;

			if ( c.input.mouse_clicked )
			{
				const auto now = std::chrono::steady_clock::now( );
				const auto elapsed = std::chrono::duration<float>( now - dc.last_time ).count( );

				if ( elapsed < 0.4f )
				{
					const auto dx = c.input.mouse_x - dc.last_x;
					const auto dy = c.input.mouse_y - dc.last_y;

					if ( dx * dx + dy * dy < 25.0f )
					{
						c.input.mouse_double_clicked = true;
					}
				}

				dc.last_time = now;
				dc.last_x = c.input.mouse_x;
				dc.last_y = c.input.mouse_y;
			}
		}

		binds::process( c.input );
		slider_binds::process( c.input );

		c.windows.clear( );
		c.id_stack.clear( );
	}

	namespace tooltips {

		inline std::vector<std::string> wrap_text( std::string_view text, float max_width )
		{
			std::vector<std::string> lines;
			std::string current_line;
			std::size_t start = 0;
			while ( start < text.size( ) )
			{
				while ( start < text.size( ) && text[ start ] == ' ' )
					start++;
				if ( start >= text.size( ) )
					break;
				std::size_t end = text.find( ' ', start );
				if ( end == std::string_view::npos )
					end = text.size( );

				std::string_view word = text.substr( start, end - start );
				start = end;

				std::string test_line = current_line.empty( ) ? std::string( word ) : current_line + " " + std::string( word );
				if ( !current_line.empty( ) && xdraw::measure_text( test_line ).first > max_width )
				{
					lines.push_back( std::move( current_line ) );
					current_line = std::string( word );
				}
				else
				{
					current_line = std::move( test_line );
				}
			}
			if ( !current_line.empty( ) )
				lines.push_back( std::move( current_line ) );
			return lines;
		}

		struct state {
			std::uintptr_t current_hovered_id{ 0 };
			std::string current_title{};
			std::string current_desc{};
			float current_mouse_x{ 0.0f };
			float current_mouse_y{ 0.0f };

			std::uintptr_t active_id{ 0 };
			std::string active_title{};
			std::string active_desc{};
			float hover_timer{ 0.0f };
			float alpha{ 0.0f };
			float target_alpha{ 0.0f };
			float pos_x{ 0.0f };
			float pos_y{ 0.0f };
		};

		inline state g_tooltip{};
		inline bool g_enabled{ true };

		void set_enabled( bool enabled ) noexcept
		{
			g_enabled = enabled;
			if ( !enabled )
			{
				g_tooltip.current_hovered_id = 0;
				g_tooltip.active_id = 0;
				g_tooltip.target_alpha = 0.0f;
				g_tooltip.alpha = 0.0f;
			}
		}

		bool is_enabled( ) noexcept
		{
			return g_enabled;
		}

		inline std::string normalize_label( std::string_view label )
		{
			auto [display, full] = parse_label( label );
			std::string result;
			result.reserve( display.size( ) );
			for ( char ch : display )
			{
				result.push_back( static_cast<char>( std::tolower( static_cast<unsigned char>( ch ) ) ) );
			}
			while ( !result.empty( ) && ( result.front( ) == ' ' || result.front( ) == '\t' ) )
				result.erase( result.begin( ) );
			while ( !result.empty( ) && ( result.back( ) == ' ' || result.back( ) == '\t' ) )
				result.pop_back( );
			return result;
		}

		inline std::string normalize_full( std::string_view label )
		{
			std::string result;
			result.reserve( label.size( ) );
			for ( char ch : label )
			{
				result.push_back( static_cast<char>( std::tolower( static_cast<unsigned char>( ch ) ) ) );
			}
			while ( !result.empty( ) && ( result.front( ) == ' ' || result.front( ) == '\t' ) )
				result.erase( result.begin( ) );
			while ( !result.empty( ) && ( result.back( ) == ' ' || result.back( ) == '\t' ) )
				result.pop_back( );
			return result;
		}

		inline bool is_ambiguous( std::string_view norm ) noexcept
		{
			return norm == "enable" || norm == "enabled" || norm == "color" || norm == "type" || norm == "style" ||
			       norm == "mode" || norm == "thickness" || norm == "intensity" || norm == "softness" ||
			       norm == "opacity" || norm == "inner spread" || norm == "pulse speed" || norm == "glow" ||
			       norm == "speed" || norm == "density" || norm == "duration" || norm == "passes" ||
			       norm == "jump steps" || norm == "preview" || norm == "fill" || norm == "outline" ||
			       norm == "material" || norm == "filled" || norm == "only when scoped" || norm == "position" ||
			       norm == "value" || norm == "strength" || norm == "display" || norm == "flags" ||
			       norm == "min" || norm == "max" || norm == "delay" || norm == "text" || norm == "samples" ||
			       norm == "smoothness" || norm == "primary" || norm == "secondary" || norm == "radius" ||
			       norm == "width" || norm == "height" || norm == "size" || norm == "fade" || norm == "sound" ||
			       norm == "volume" || norm == "group";
		}

		inline std::string get_fallback_description( std::string_view label )
		{
			const auto norm = normalize_label( label );
			if ( norm.find( "color" ) != std::string::npos )
				return "Adjusts color tint and opacity level";
			if ( norm.find( "fov" ) != std::string::npos )
				return "Adjusts field of view angle";
			if ( norm.find( "speed" ) != std::string::npos )
				return "Adjusts movement or animation speed";
			if ( norm.find( "thickness" ) != std::string::npos )
				return "Adjusts line or border thickness";
			if ( norm.find( "alpha" ) != std::string::npos || norm.find( "opacity" ) != std::string::npos )
				return "Adjusts transparency and opacity level";
			if ( norm.find( "radius" ) != std::string::npos )
				return "Adjusts effect radius and range";
			if ( norm.find( "distance" ) != std::string::npos || norm.find( "dist" ) != std::string::npos )
				return "Adjusts maximum distance range";
			if ( norm.find( "material" ) != std::string::npos )
				return "Selects surface texture shader material";
			if ( norm.find( "style" ) != std::string::npos || norm.find( "mode" ) != std::string::npos )
				return "Selects visual style or operational mode";
			if ( norm.find( "volume" ) != std::string::npos )
				return "Adjusts audio playback volume";
			if ( norm.find( "duration" ) != std::string::npos )
				return "Adjusts on-screen duration in seconds";
			if ( norm.find( "scale" ) != std::string::npos || norm.find( "size" ) != std::string::npos )
				return "Adjusts size scaling";
			if ( norm.find( "save" ) != std::string::npos )
				return "Saves current configuration to disk";
			if ( norm.find( "load" ) != std::string::npos )
				return "Loads selected configuration from disk";
			if ( norm.find( "reset" ) != std::string::npos )
				return "Resets settings to default values";
			if ( norm.find( "import" ) != std::string::npos )
				return "Imports configuration from clipboard";
			if ( norm.find( "export" ) != std::string::npos )
				return "Exports current configuration to clipboard";
			if ( norm.find( "delete" ) != std::string::npos )
				return "Deletes selected configuration profile";
			if ( norm.find( "refresh" ) != std::string::npos )
				return "Refreshes available configuration files";
			if ( norm.find( "glow" ) != std::string::npos )
				return "Renders an illuminated glow effect";
			if ( norm.find( "outline" ) != std::string::npos )
				return "Renders a dark outer border outline";
			if ( norm.find( "spread" ) != std::string::npos )
				return "Adjusts dispersion and spread radius";
			if ( norm.find( "density" ) != std::string::npos )
				return "Adjusts visual particle and effect density";
			if ( norm.find( "indicator" ) != std::string::npos )
				return "Renders on-screen visual indicator";
			if ( norm.find( "delay" ) != std::string::npos )
				return "Adjusts timing delay in milliseconds or seconds";
			if ( norm.find( "smooth" ) != std::string::npos )
				return "Adjusts movement smoothing factor";
			if ( norm.find( "strength" ) != std::string::npos )
				return "Adjusts effect or feature strength multiplier";
			if ( norm.find( "damage" ) != std::string::npos )
				return "Adjusts minimum damage threshold";
			if ( norm.find( "hitchance" ) != std::string::npos || norm.find( "chance" ) != std::string::npos )
				return "Adjusts required hit probability percentage";
			if ( norm.find( "smoke" ) != std::string::npos )
				return "Smoke grenade visibility check";
			if ( norm.find( "scope" ) != std::string::npos )
				return "Weapon sniper scope check or overlay";
			if ( norm.find( "flash" ) != std::string::npos )
				return "Flashbang blindness check or alpha cap";
			if ( norm.find( "seed" ) != std::string::npos )
				return "Pattern seed or spread prediction calculation";
			if ( norm.find( "hitbox" ) != std::string::npos )
				return "Configures target body hitboxes";
			if ( norm.find( "recoil" ) != std::string::npos || norm.find( "rcs" ) != std::string::npos )
				return "Compensates for weapon recoil and spray pattern";
			if ( norm.find( "chams" ) != std::string::npos )
				return "Custom player or model material chams";
			if ( norm.find( "blur" ) != std::string::npos )
				return "Directional motion or camera blur effect";
			if ( norm.find( "wind" ) != std::string::npos )
				return "Simulates ambient air currents for weather particles";
			if ( norm.find( "wet" ) != std::string::npos )
				return "Simulates surface wetness and glossy puddles";
			if ( norm.find( "aspect" ) != std::string::npos )
				return "Overrides display aspect ratio";
			if ( norm.find( "key" ) != std::string::npos || norm.find( "bind" ) != std::string::npos )
				return "Assigns activation keybind toggle";

			return "Configure " + std::string( label ) + " setting";
		}

	} // namespace tooltips

	std::string_view get_function_description( std::string_view label )
	{
		static const std::unordered_map<std::string, std::string_view> k_exact = {
			// Ragebot
			{ "enable ragebot", "Enables automated target acquisition and firing system" },
			{ "weapon group", "Select weapon category to configure independent combat settings" },
			{ "silent aim", "Silently aims at targets without visibly snapping your crosshair" },
			{ "field of view", "Maximum field of view angle for aimbot target scanning" },
			{ "target fov", "Maximum field of view angle for aimbot target scanning" },
			{ "no spread", "Completely eliminates bullet spread for pinpoint accuracy" },
			{ "extrapolation", "Extrapolates enemy movement to compensate for latency and tickrate" },
			{ "max ticks", "Maximum tick count for backtrack and extrapolation simulation" },
			{ "force bodyaim", "Forces aimbot to prioritize targeting enemy torso instead of head" },
			{ "pointscale", "Scale factor for multi-point scanning coverage on target hitboxes" },
			{ "hitboxes", "Select eligible enemy body hitboxes for aimbot targeting" },
			{ "auto stop", "Automatically halts movement before firing to ensure maximum accuracy" },
			{ "auto scope", "Automatically zooms sniper rifles when a target is acquirable" },
			{ "hit chance", "Minimum calculated hit probability percentage required before firing" },
			{ "hitchance", "Minimum calculated hit probability percentage required before firing" },
			{ "minimum damage", "Minimum required penetration damage to attempt a shot" },
			{ "min damage", "Minimum required penetration damage to attempt a shot" },
			{ "hitchance override", "Temporarily overrides minimum hit chance while keybind is active" },
			{ "mindamage override", "Temporarily overrides minimum damage threshold while keybind is active" },
			{ "anti aim", "Desynchronizes player view angles to make head hitboxes harder to hit" },
			{ "auto yaw adjust", "Dynamically adjusts yaw angles relative to threatening enemy positions" },
			{ "hide onshot", "Suppresses anti-aim angle flicking when firing a weapon" },
			{ "avoid backstab", "Rotates player model away from enemies attempting to knife your back" },
			{ "direction indicator", "Renders directional arrow indicators showing anti-aim yaw angle" },
			{ "pitch", "Adjusts vertical head pitch angle (none, down, or up)" },
			{ "quick peek assist", "Assists peeking corners and snaps back to starting cover position" },
			{ "duck peek assist", "Automatically crouches upon peeking to reduce hitbox exposure" },
			{ "start color", "Indicator color at quick peek origin position" },
			{ "retrack color", "Indicator color during automated return to cover" },
			{ "auto revolver", "Automatically cocks R8 Revolver hammer to fire instantly on sight" },
			{ "zeusbot", "Automatically discharges Zeus x27 when an enemy enters lethal range" },
			{ "knifebot", "Automatically slashes or stabs enemies when within knife reach" },

			// Legitbot
			{ "enable legitbot", "Enables smooth, humanized aim assistance for stealthy gameplay" },
			{ "aimbot", "Smoothly assists crosshair tracking toward nearest enemy hitbox" },
			{ "smoothness", "Crosshair movement smoothing to simulate natural human aim" },
			{ "draw fov", "Draws visible circular overlay indicating aimbot acquisition radius" },
			{ "visualize fov", "Draws visible circular overlay indicating aimbot acquisition radius" },
			{ "recoil control (rcs)", "Compensates for weapon recoil and spray patterns while shooting" },
			{ "check smoke", "Prevents aimbot or triggerbot from locking on or firing through smoke grenades" },
			{ "smoke check", "Prevents aimbot or triggerbot from locking on or firing through smoke grenades" },
			{ "smoke check (approx.)", "Prevents aimbot or triggerbot from locking on or firing through smoke grenades" },
			{ "check scope", "Restricts sniper aimbot assistance to when you are zoomed in scope" },
			{ "scope check", "Restricts sniper aimbot assistance to when you are zoomed in scope" },
			{ "scope check (no auto-scope)", "Restricts sniper aimbot assistance to when you are zoomed in scope" },
			{ "flash check", "Disables aimbot and triggerbot assistance while you are blinded by flashbangs" },
			{ "only on ground", "Restricts aimbot assistance to when player is standing on the ground (no air-aim)" },
			{ "ground check", "Restricts aimbot assistance to when player is standing on the ground" },
			{ "triggerbot", "Automatically fires when an enemy crosses your crosshair" },
			{ "trigger head only", "Only triggers automated firing when aiming specifically at enemy head" },
			{ "reaction delay", "Human reaction delay in milliseconds before triggerbot fires" },
			{ "seed prediction", "Predicts weapon seed spread to land accurate first shots" },
			{ "standalone rcs", "Compensates for weapon recoil independently without aimbot active" },
			{ "autowall", "Allows firing through wallbangable obstacles if damage threshold is met" },

			// Player ESP & Visuals
			{ "enable esp", "Enables player ESP overlays and visuals" },
			{ "box", "Displays a 2D bounding box around the player silhouette" },
			{ "box esp", "Displays a 2D bounding box around the player silhouette" },
			{ "skeleton", "Renders player bone skeleton joints through walls" },
			{ "health bar", "Displays dynamic health bar showing target player HP" },
			{ "armor", "Displays player body armor status and durability" },
			{ "armor bar", "Displays player body armor status and durability" },
			{ "name", "Displays player username above their character model" },
			{ "name esp", "Displays player username above their character model" },
			{ "weapon", "Displays active weapon name or graphic icon held by player" },
			{ "weapon text", "Displays text name of player's active weapon" },
			{ "ammo", "Displays ammunition counter bar for active weapon" },
			{ "ammo bar", "Displays ammunition counter bar for active weapon" },
			{ "distance", "Displays distance in meters to target player" },
			{ "snaplines", "Draws tracer line from screen edge or crosshair to player" },
			{ "offscreen", "Directional arrows on screen border pointing toward off-screen enemies" },
			{ "oof arrows", "Directional arrows on screen border pointing toward off-screen enemies" },
			{ "player glow", "Renders vibrant outline glow aura around player models" },
			{ "item glow", "Renders glowing outline aura around dropped weapons on ground" },
			{ "ragdoll glow", "Renders glowing outline aura around dead player bodies" },
			{ "chams", "Replaces standard player textures with custom colored materials" },
			{ "player chams", "Replaces player model textures with custom colored materials" },
			{ "visible chams", "Material and color applied to visible, non-occluded player models" },
			{ "through wall", "Renders occluded chams through walls when player is hidden behind obstacles" },
			{ "occluded chams", "Renders occluded chams through walls when player is hidden behind obstacles" },
			{ "backtrack chams", "Renders ghost chams models at historical lag compensation tick positions" },
			{ "onshot chams", "Renders frozen ghost chams model at the exact position an enemy fired a shot" },
			{ "weapon chams", "Applies custom colored shader materials to your first-person viewmodel weapon" },
			{ "arms chams", "Applies custom colored shader materials to your first-person viewmodel hands and arms" },
			{ "glow settings", "Configures advanced bloom, thickness, and animation parameters for outline glow chams" },
			{ "flags", "Displays tactical status tags: armor, helmet, flashed, scoped, defusing" },
			{ "info flags", "Displays tactical status tags: armor, helmet, flashed, scoped, defusing" },
			{ "corner length", "Length of corner brackets when cornered box style is active" },
			{ "gradient", "Applies a smooth color gradient across the indicator bar" },
			{ "show value", "Displays exact numerical value beside the indicator bar" },
			{ "lower opacity", "Fades local player model transparency when zooming or near camera" },
			{ "only when scoped", "Only apply model transparency while aiming through a weapon scope" },

			// World ESP & Atmosphere
			{ "item esp", "Highlights dropped weapons, grenades, and equipment on the ground" },
			{ "dropped items esp", "Highlights dropped weapons, grenades, and equipment on the ground" },
			{ "item chams", "Applies custom colored materials to dropped weapons and items" },
			{ "projectile esp", "Displays active grenade trajectories and detonation countdown timers" },
			{ "inferno esp", "Displays burning molotov/incendiary fire boundaries on the ground" },
			{ "landing indicator", "Renders an indicator circle where the grenade will land or detonate" },
			{ "indicator", "Renders an on-screen visual warning indicator" },
			{ "bomb esp", "Displays C4 plant status, detonation timer, and defuse progress" },
			{ "bomb timer", "Displays C4 countdown timer until detonation and defusal progress" },
			{ "defusing", "Displays bomb defusal progress bar and remaining time" },
			{ "defuser", "Shows whether bomb defuser has a defuse kit equipped" },
			{ "ambience", "Opens the map ambience and atmospheric environment visualizer modal" },
			{ "nightmode", "Darkens map ambient lighting for high-contrast night atmosphere" },
			{ "override sunlight", "Overrides map sunlight and ambient illumination with custom color and brightness" },
			{ "fullbright", "Illuminates all map geometry, shadows, and player models with uniform shadowless bright lighting" },
			{ "override sky", "Overrides skybox texture dome and atmospheric lighting colors" },
			{ "overlight", "Dramatically boosts skybox luminosity and bloom exposure for glowing bright skies" },
			{ "damage effect", "Displays floating damage numbers at the hit position with custom color, scale, and hide delay" },
			{ "skybox", "Selects custom high-definition skybox texture" },
			{ "skybox material", "Selects custom high-definition skybox texture" },
			{ "custom skybox", "Selects custom high-definition skybox texture" },
			{ "custom colors", "Enables custom color tints for sky dome, atmospheric clouds, and sunlight" },
			{ "skybox color", "Custom color tint applied to the sky dome" },
			{ "sky color", "Custom color tint applied to the sky dome" },
			{ "sun color", "Custom color tint applied to map sunlight" },
			{ "cloud color", "Custom color tint applied to atmospheric clouds" },
			{ "world color", "Custom color tint applied to map geometry and surfaces" },
			{ "world lighting", "Adjusts ambient world lighting intensity and coloration" },
			{ "lighting", "Adjusts ambient world lighting intensity and coloration" },
			{ "props color", "Custom color tint applied to static props and map objects" },
			{ "wall color", "Custom color tint applied to map walls" },
			{ "wall material", "Selects texture shader material for map walls" },
			{ "ragdoll chams", "Applies custom shader materials to dead player bodies" },
			{ "bullet tracers", "Displays glowing beam lines tracing fired bullet trajectories" },
			{ "bullet impacts", "Renders 3D boxes and spark particles marking bullet impact points" },
			{ "projectile trajectory", "Predicts and draws throw trajectory and bounce arc for grenades" },
			{ "grenade prediction", "Predicts and draws throw trajectory and bounce arc for grenades" },
			{ "straight throw", "Shows trajectory line for standard primary attack throw" },
			{ "held damage", "Calculates blast damage dealt by currently held cooked grenade" },
			{ "thrown damage", "Calculates blast damage dealt by thrown grenades in flight" },
			{ "can penetrate", "Crosshair indicator showing whether surface can be penetrated" },
			{ "dynamic light", "Emits dynamic light source from your player illuminating dark areas" },
			{ "bloom", "Soft glow effect around bright lights and reflective surfaces" },
			{ "bloom effect", "Soft glow effect around bright lights and reflective surfaces" },
			{ "override bloom", "Overrides post-processing bloom glow intensity around lights and reflections" },
			{ "gamma", "Adjusts display brightness and color gamma response" },
			{ "override gamma", "Overrides display brightness and color gamma response curve" },
			{ "chromatic aberration", "Color fringing dispersion effect around screen edges" },
			{ "flash alpha", "Caps maximum flashbang blindness screen opacity percentage" },
			{ "fog", "Adds dense atmospheric distance fog across the map" },
			{ "override fog", "Adds custom dense atmospheric distance fog across the map" },
			{ "anisotropy", "Directional light scattering through atmospheric distance fog" },
			{ "draw distance", "Maximum rendering distance for atmospheric distance fog" },
			{ "depth of field", "Applies cinematic camera focus depth blur to distant backgrounds" },
			{ "override dof", "Enables cinematic camera focus depth blur for foreground and distant backgrounds" },
			{ "near blurry", "Near camera blur start distance for depth of field" },
			{ "near crisp", "Near camera sharp focal plane distance for depth of field" },
			{ "far crisp", "Far camera sharp focal plane distance for depth of field" },
			{ "far blurry", "Far camera blur start distance for depth of field" },
			{ "wetness", "Simulates glossy rain puddles and slick surface reflections" },
			{ "wetness density", "Intensity and puddle coverage of the slick ground wetness effect" },
			{ "wetness speed", "Animation speed of surface ripples and glossy reflections" },
			{ "weather", "Spawns custom environmental weather particles such as rain, snow, or stars" },
			{ "wind", "Simulates ambient air currents that push weather particles" },
			{ "wind strength", "Wind velocity affecting atmospheric weather particle movement" },
			{ "wind direction", "Compass angle heading of ambient wind direction (0-360°)" },
			{ "wind turbulence", "Erratic gusts and turbulence applied to falling weather particles" },

			// Movement
			{ "auto jump", "Automatically jumps continuously upon landing while holding spacebar" },
			{ "bunnyhop", "Automatically jumps continuously upon landing while holding spacebar" },
			{ "bunny hop", "Automatically jumps continuously upon landing while holding spacebar" },
			{ "auto strafe", "Automatically maneuvers in air to maximize velocity and speed gain" },
			{ "air strafe", "Automatically maneuvers in air to maximize velocity and speed gain" },
			{ "fast stop", "Instantly halts movement momentum upon releasing keys for maximum accuracy" },
			{ "quick stop", "Instantly halts movement momentum or prevents falling off edges" },
			{ "edge jump", "Automatically executes a jump right before stepping off an edge" },
			{ "jump bug", "Exploits jump bug mechanics to preserve velocity without fall damage" },
			{ "edge bug", "Glides along surface edges to nullify fall damage and preserve velocity" },
			{ "pixel surf", "Locks onto and surfs along pixel-thin wall seams" },
			{ "long jump", "Optimizes jump trajectory and crouch timing for maximum jump distance" },
			{ "fast ladder", "Accelerates ladder climbing speed to maximum allowed velocity" },
			{ "slow walk", "Reduces movement speed below audio threshold for pinpoint accuracy" },
			{ "slow walk speed", "Maximum player movement speed limit in units per second during slow walk" },
			{ "air duck", "Automatically crouches in mid-air to reach high ledges" },

			// Misc & Removals & HUD
			{ "unlock spectating", "Allows switching spectator camera to any player without restriction" },
			{ "spectator thirdperson", "Enables thirdperson camera while spectating other players" },
			{ "thirdperson", "Switches camera to third-person perspective behind your player model" },
			{ "freecam", "Detaches camera for free-flight spectator navigation around the map" },
			{ "freecam speed", "Flight movement speed of the free spectator camera" },
			{ "freecam block input", "Disables player movement and firing while flying free camera" },
			{ "block movement", "Disables player movement inputs while controlling free camera" },
			{ "hull size", "Camera collision hull radius to prevent clipping through walls" },
			{ "hit logs", "Logs weapon damage dealt and hit locations on screen" },
			{ "miss logs", "Logs detailed miss reasons: spread, occlusion, or resolver correction" },
			{ "console logs", "Echoes combat hit and miss events directly to the developer console" },
			{ "chat logs", "Prints combat event summaries in local client chat" },
			{ "vote logs", "Logs vote kick attempts and player vote responses in real time" },
			{ "hit sound", "Plays customizable audio feedback chime upon registering a hit" },
			{ "death sound", "Plays customizable sound effect upon killing an opponent" },
			{ "hit marker", "Displays visual crosshair ticks or floating damage numbers on hit" },
			{ "damage marker", "Displays floating damage numbers over target upon hit" },
			{ "hit effect", "Displays spark particles and screen flash at bullet impact point" },
			{ "death effect", "Displays visual particle burst upon landing a fatal kill shot" },
			{ "disable game logs", "Suppresses default in-game damage printouts in chat" },
			{ "preserve killfeed", "Prevents kill notices from expiring quickly so they remain visible longer" },
			{ "reveal radar", "Reveals all enemy positions on the in-game radar map" },
			{ "vote kick self", "Calls a vote to kick yourself from the match" },
			{ "vote kick now", "Initiates a self vote kick immediately" },
			{ "penetration crosshair", "Dynamic indicator showing whether surfaces can be penetrated (wallbang)" },
			{ "nickname override", "Spoofs your visible in-game player name" },
			{ "clantag", "Sets custom animated or static clan tag beside your name" },
			{ "scoreboard weapons", "Displays icons of all player held weapons in the scoreboard" },
			{ "auto buy", "Automatically purchases your selected weapon loadout each round" },
			{ "kill say", "Automatically sends a custom message in game chat after eliminating an enemy" },
			{ "chat spam", "Repeatedly sends automated text messages into game or team chat" },
			{ "custom fov", "Overrides default camera field of view angle" },
			{ "scoped fov override", "Override camera field of view while zooming with scoped rifles" },
			{ "scoped fov", "Custom field of view applied while zooming with scoped rifles" },
			{ "viewmodel adjust", "Customizes weapon viewmodel offset coordinates and viewmodel FOV" },
			{ "custom aspect ratio", "Overrides screen aspect ratio (e.g. 4:3 stretched, 16:9, 16:10)" },
			{ "motion blur", "Applies cinematic directional camera motion blur while turning and moving" },
			{ "remove crosshair", "Hides default game crosshair" },
			{ "remove scope", "Removes black scope overlay border when zooming with sniper rifles" },
			{ "remove smoke", "Removes smoke grenade particle clouds for clear visibility" },
			{ "remove visual recoil", "Completely eliminates weapon punch and screen shake while firing" },
			{ "remove skybox fog", "Removes default skybox fog for crystal-clear sky visibility" },
			{ "remove overhead", "Hides overhead player markers, names, and team arrows" },
			{ "remove legs", "Hides local player first-person legs model when looking downward" },
			{ "remove 3d skybox", "Disables 3D skybox geometry outside the map for increased FPS" },
			{ "remove decals", "Clears bullet holes, blood splatters, and blast marks from surfaces" },
			{ "crosshair overlay", "Custom static screen crosshair with customizable size and colors" },
			{ "scope overlay", "Custom crosshair overlay replacing standard sniper scope" },
			{ "hat", "Renders a custom 3D cosmetic hat accessory on your player model" },
			{ "velocity counter", "Numeric real-time movement velocity readout on HUD" },
			{ "velocity chart", "Real-time graph displaying acceleration and jump velocity curves" },
			{ "keybinds list", "Draggable HUD window displaying active toggled keys and bindings" },
			{ "spectator list", "Draggable HUD window displaying spectators currently watching you" },
			{ "rank revealer", "Reveals competitive ranks and skill ratings for all players on scoreboard" },
			{ "auto accept", "Automatically accepts matchmaking competitive match invites" },
			{ "menu key", "Keyboard key to toggle cheat menu visibility" },
			{ "dpi scale", "Scales menu UI dimensions to match screen DPI scaling" },
			{ "accent color", "Primary accent color for the cheat interface" },
			{ "color palette", "Select menu color scheme preset" },
			{ "theme", "Opens menu color scheme preset selection list" },
			{ "unload", "Safely uninjects and unloads cheat module from game memory" },
			{ "watermark", "Displays branded status watermark overlay with game stats" },
			{ "steam username", "Shows your Steam profile name in watermark" },
			{ "fps", "Shows current real-time frames per second" },
			{ "ping", "Shows current latency round-trip time in milliseconds" },
			{ "loss", "Shows packet loss percentage in watermark" },
			{ "clock", "Shows local system clock time" },
			{ "map", "Shows currently loaded map name" },
			{ "tick rate", "Shows current server tickrate" },
			{ "velocity", "Shows current movement speed value in watermark" },
			{ "tooltips", "Toggles interactive help tooltips throughout the cheat interface" },

			// Skins & Config & Generic Actions
			{ "wear", "Skin wear float value (0.00 Factory New to 1.00 Battle-Scarred)" },
			{ "pattern seed", "Pattern seed integer determining paint texture placement (0-1000)" },
			{ "pattern seed (0-1000)", "Pattern seed integer determining paint texture placement (0-1000)" },
			{ "##seed_input", "Enter pattern seed integer (0-1000)" },
			{ "stattrak", "Enables StatTrak kill counter on the weapon" },
			{ "stattrak count", "Total kill count displayed on the StatTrak counter" },
			{ "skin changer", "Equip any weapon skin, knife, glove, or agent model in game" },
			{ "##cfg_name", "Enter configuration profile name or search query" },
			{ "save", "Save current configuration profile to disk" },
			{ "delete", "Delete selected configuration profile" },
			{ "refresh", "Reload configuration files from disk" },
			{ "confirm save?", "Confirm saving configuration to disk" },
			{ "overwrite?", "Confirm overwriting existing configuration file" },
			{ "confirm delete?", "Confirm permanent deletion of selected configuration" },
			{ "reset config", "Resets cheat settings for this profile back to default values" },
			{ "confirm reset?", "Confirm resetting this profile to default values" },
			{ "file", "Audio file path located in sounds directory" },
			{ "fill", "Renders a subtle semi-transparent background fill inside the 2D box" },
			{ "material", "Selects texture shader material: metallic, flat, glow, electric, distortion, hologram, outline glow, etc." },
			{ "filled", "Fills model interior when using outline or outline glow chams" }
		};

		// 1. Exact match on full label (e.g. "intensity##light", "color##world", etc.)
		const auto norm_full = tooltips::normalize_full( label );
		const auto it_full = k_exact.find( norm_full );
		if ( it_full != k_exact.end( ) )
		{
			return it_full->second;
		}

		// 2. Parse display name and suffix
		const auto [display_part, full_part] = parse_label( label );
		const auto norm_disp = tooltips::normalize_label( display_part );
		const auto hash_pos = label.find( "##" );
		std::string norm_suf;
		if ( hash_pos != std::string_view::npos )
		{
			norm_suf = tooltips::normalize_label( label.substr( hash_pos + 2 ) );
		}

		// 3. Exact match on display name if present in k_exact and unambiguous
		const auto it_disp = k_exact.find( norm_disp );
		if ( it_disp != k_exact.end( ) && !tooltips::is_ambiguous( norm_disp ) )
		{
			return it_disp->second;
		}

		// 4. Contextual disambiguation by suffix (when ## is present)
		if ( !norm_suf.empty( ) )
		{
			if ( norm_suf.starts_with( "rcs" ) )
			{
				if ( norm_disp == "min" ) return "Minimum recoil reduction percentage";
				if ( norm_disp == "max" ) return "Maximum recoil reduction percentage";
			}
			else if ( norm_suf.starts_with( "srcs" ) )
			{
				if ( norm_disp == "strength" ) return "Recoil compensation strength for standalone RCS";
				if ( norm_disp == "min" ) return "Minimum recoil reduction percentage";
				if ( norm_disp == "max" ) return "Maximum recoil reduction percentage";
			}
			else if ( norm_suf.starts_with( "aw" ) )
			{
				if ( norm_disp == "min damage" || norm_disp == "damage" ) return "Minimum penetration damage required to fire through wallbangable obstacles";
			}
			else if ( norm_suf.starts_with( "fov" ) )
			{
				if ( norm_disp.find( "color" ) != std::string::npos ) return "Color of visible circular aimbot FOV acquisition radius";
			}
			else if ( norm_suf.starts_with( "light" ) )
			{
				if ( norm_disp == "intensity" ) return "Adjusts ambient world lighting brightness and intensity";
				if ( norm_disp == "color" ) return "Custom color tint applied to ambient world lighting";
			}
			else if ( norm_suf.starts_with( "world" ) )
			{
				if ( norm_disp == "color" ) return "Custom color tint applied to map surfaces and textures";
			}
			else if ( norm_suf.starts_with( "fog" ) )
			{
				if ( norm_disp == "color" ) return "Custom color of the atmospheric distance fog";
				if ( norm_disp == "density" ) return "Density and thickness of atmospheric distance fog";
				if ( norm_disp == "anisotropy" ) return "Directional light scattering through atmospheric distance fog";
				if ( norm_disp == "draw distance" ) return "Maximum rendering distance for atmospheric distance fog";
			}
			else if ( norm_suf.starts_with( "wet" ) )
			{
				if ( norm_disp == "density" ) return "Intensity and puddle coverage of the wet surface effect";
				if ( norm_disp == "speed" ) return "Speed of surface ripple animations and slick reflections";
			}
			else if ( norm_suf.starts_with( "wind" ) )
			{
				if ( norm_disp == "strength" ) return "Wind velocity affecting weather particle movement";
				if ( norm_disp == "direction" ) return "Compass heading angle of ambient wind direction (0-360°)";
				if ( norm_disp == "turbulence" ) return "Turbulence and erratic gusts applied to weather particles";
			}
			else if ( norm_suf.starts_with( "weather" ) )
			{
				if ( norm_disp.find( "color" ) != std::string::npos ) return "Color tint for atmospheric weather particles";
				if ( norm_disp == "type" ) return "Select weather particle effect: snow, rain, or stars";
			}
			else if ( norm_suf.starts_with( "eb" ) )
			{
				if ( norm_disp == "mode" ) return "Edgebug calculation mode (0: loose, 1: edge trace, 2: no jump held, 3: min speed, 4: strict vz)";
				if ( norm_disp == "passes" ) return "Number of predictive simulation passes for edgebug detection";
				if ( norm_disp == "jump steps" ) return "Include jump tick simulation in edgebug prediction";
			}
			else if ( norm_suf.starts_with( "skel" ) )
			{
				if ( norm_disp == "mode" ) return "Skeleton render mode: normal bones or backtrack history ticks";
				if ( norm_disp == "thickness" ) return "Line width of rendered player skeleton bones";
				if ( norm_disp.find( "visible" ) != std::string::npos ) return "Skeleton color when player is in direct line of sight";
				if ( norm_disp.find( "occluded" ) != std::string::npos ) return "Skeleton color when player is occluded behind walls";
			}
			else if ( norm_suf.starts_with( "box" ) )
			{
				if ( norm_disp == "style" ) return "Select full 2D bounding box or cornered bracket style";
				if ( norm_disp.find( "visible" ) != std::string::npos ) return "Bounding box color when player is in direct line of sight";
				if ( norm_disp.find( "occluded" ) != std::string::npos ) return "Bounding box color when player is occluded behind walls";
			}
			else if ( norm_suf.starts_with( "hp" ) )
			{
				if ( norm_disp == "position" ) return "Screen position of player health bar (left, top, bottom)";
				if ( norm_disp == "outline" ) return "Renders dark outer border outline around the health bar";
				if ( norm_disp == "gradient" ) return "Smooth color gradient transition along the health bar";
				if ( norm_disp == "show value" ) return "Displays exact numerical health value beside the health bar";
				if ( norm_disp == "glow" ) return "Applies a glowing aura around the health bar";
				if ( norm_disp == "glow strength" ) return "Bloom intensity and spread of the health bar glow";
				if ( norm_disp == "full color" ) return "Health bar color when player is at full health";
				if ( norm_disp == "low color" ) return "Health bar color when player is at critical low health";
				if ( norm_disp == "background" ) return "Background bar fill color behind the health indicator";
				if ( norm_disp == "outline color" ) return "Border outline color surrounding the health bar";
				if ( norm_disp == "text color" ) return "Text color of the numerical health value";
				if ( norm_disp == "glow color" ) return "Glow aura color surrounding the health bar";
			}
			else if ( norm_suf.starts_with( "ammo" ) )
			{
				if ( norm_disp == "position" ) return "Screen position of player ammo bar (left, top, bottom)";
				if ( norm_disp == "outline" ) return "Renders dark outer border outline around the ammo bar";
				if ( norm_disp == "gradient" ) return "Smooth color gradient transition along the ammo bar";
				if ( norm_disp == "show value" ) return "Displays remaining magazine ammunition count beside the ammo bar";
				if ( norm_disp == "glow" ) return "Applies a glowing aura around the ammo bar";
				if ( norm_disp == "glow strength" ) return "Bloom intensity and spread of the ammo bar glow";
				if ( norm_disp == "full color" ) return "Ammo bar color when magazine is full";
				if ( norm_disp == "low color" ) return "Ammo bar color when magazine is nearly empty";
				if ( norm_disp == "background" ) return "Background bar fill color behind the ammo indicator";
				if ( norm_disp == "outline color" ) return "Border outline color surrounding the ammo bar";
				if ( norm_disp == "text color" ) return "Text color of the numerical ammo value";
				if ( norm_disp == "glow color" ) return "Glow aura color surrounding the ammo bar";
			}
			else if ( norm_suf.starts_with( "wep" ) )
			{
				if ( norm_disp == "display" ) return "Weapon ESP display style: text name, graphic icon, or both";
				if ( norm_disp == "text color" ) return "Color of player weapon text label";
				if ( norm_disp == "icon color" ) return "Color of player weapon graphic icon";
			}
			else if ( norm_suf.starts_with( "flags" ) || norm_suf == "mc" )
			{
				if ( norm_disp == "flags" ) return "Select player status flags to display (money, armor, kit, scoped, defusing, flashed, distance)";
				if ( norm_disp.find( "money" ) != std::string::npos ) return "Color tint for player account balance status tag";
				if ( norm_disp.find( "armor" ) != std::string::npos ) return "Color tint for body armor and helmet indicator tag";
				if ( norm_disp.find( "kit" ) != std::string::npos ) return "Color tint for defuse kit indicator tag";
				if ( norm_disp.find( "scoped" ) != std::string::npos ) return "Color tint for scoped rifle zoom status flag";
				if ( norm_disp.find( "defusing" ) != std::string::npos ) return "Color tint for active bomb defusal status flag";
				if ( norm_disp.find( "flashed" ) != std::string::npos ) return "Color tint for flashbang blindness indicator tag";
				if ( norm_disp.find( "distance" ) != std::string::npos ) return "Color tint for target distance measurement tag";
				return "Color tint for this player status indicator flag";
			}
			else if ( norm_suf.starts_with( "oof" ) )
			{
				if ( norm_disp == "glow" ) return "Applies a glowing aura around out-of-view directional arrows";
				if ( norm_disp == "width" ) return "Width of out-of-view directional arrow indicator";
				if ( norm_disp == "height" ) return "Height of out-of-view directional arrow indicator";
				if ( norm_disp == "radius x" ) return "Horizontal screen radius offset for out-of-view arrows";
				if ( norm_disp == "radius y" ) return "Vertical screen radius offset for out-of-view arrows";
				if ( norm_disp == "glow strength" ) return "Glow bloom intensity for out-of-view arrows";
				if ( norm_disp.find( "visible" ) != std::string::npos ) return "Arrow color when enemy is in direct line of sight";
				if ( norm_disp.find( "occluded" ) != std::string::npos ) return "Arrow color when enemy is behind walls";
			}
			else if ( norm_suf.starts_with( "glow" ) )
			{
				if ( norm_suf.find( "rag" ) != std::string::npos ) return "Outer glow outline color around dead ragdoll models";
				if ( norm_suf.find( "local" ) != std::string::npos ) return "Outer glow outline color around local player model";
				return "Outer glow outline color around player models";
			}
			else if ( norm_suf.starts_with( "name" ) )
			{
				if ( norm_disp.find( "color" ) != std::string::npos ) return "Color of player username text label";
			}
			else if ( norm_suf.starts_with( "inf" ) )
			{
				if ( norm_disp == "glow" ) return "Enables glowing heat aura around molotov fire zone";
				if ( norm_disp == "glow strength" ) return "Glow bloom intensity for molotov fire zone";
				if ( norm_disp == "fill color" ) return "Color of ground fill indicating active molotov fire zone";
				if ( norm_disp == "outline color" ) return "Outline color around the molotov fire boundary";
				if ( norm_disp == "outline thickness" ) return "Line thickness of molotov fire boundary";
			}
			else if ( norm_suf.starts_with( "ind" ) )
			{
				if ( norm_disp == "glow" ) return "Enables glowing aura around landing indicator circle";
				if ( norm_disp == "glow strength" ) return "Glow bloom intensity for landing indicator";
				if ( norm_disp == "arc color" ) return "Color of grenade flight trajectory arc";
				if ( norm_disp == "icon color" ) return "Color of projectile type graphic icon";
				if ( norm_disp == "background" ) return "Background color for landing indicator";
			}
			else if ( norm_suf.starts_with( "ie" ) )
			{
				if ( norm_disp == "display" ) return "Item ESP display style: text name, graphic icon, or both";
				if ( norm_disp == "max dist" ) return "Maximum rendering distance for dropped items";
				if ( norm_disp == "text color" ) return "Color of dropped item text label";
				if ( norm_disp == "icon color" ) return "Color of dropped item graphic icon";
			}
			else if ( norm_suf.starts_with( "ic" ) )
			{
				if ( norm_disp == "primary" ) return "Primary chams material layer for dropped weapons";
				if ( norm_disp == "secondary" ) return "Secondary chams material layer for dropped weapons";
			}
			else if ( norm_suf.starts_with( "pe" ) )
			{
				if ( norm_disp == "display" ) return "Projectile ESP display style: text name, graphic icon, or both";
				if ( norm_disp == "max dist" ) return "Maximum rendering distance for active projectiles";
				if ( norm_disp == "text color" ) return "Color of projectile text label";
				if ( norm_disp == "icon color" ) return "Color of projectile graphic icon";
			}
			else if ( norm_suf.starts_with( "ig" ) )
			{
				if ( norm_disp.find( "color" ) != std::string::npos ) return "Color of glowing outline aura around dropped items";
			}
			else if ( norm_suf.starts_with( "hl" ) )
			{
				if ( norm_disp == "duration" ) return "Duration in seconds hit log notices remain on screen";
			}
			else if ( norm_suf.starts_with( "ml" ) )
			{
				if ( norm_disp == "duration" ) return "Duration in seconds miss log notices remain on screen";
			}
			else if ( norm_suf.starts_with( "pen" ) )
			{
				if ( norm_disp == "glow" ) return "Enables glowing aura around penetration crosshair";
				if ( norm_disp == "glow strength" ) return "Glow bloom intensity for penetration crosshair";
				if ( norm_disp == "can penetrate" ) return "Color when obstacle can be penetrated by bullets (wallbang)";
				if ( norm_disp == "can pen outline" ) return "Outline color for penetrable surface indicator";
				if ( norm_disp == "blocked" ) return "Color when obstacle cannot be penetrated";
				if ( norm_disp == "blocked outline" ) return "Outline color when obstacle cannot be penetrated";
			}
			else if ( norm_suf.starts_with( "buy" ) )
			{
				if ( norm_disp == "primary" ) return "Primary weapon to purchase automatically at round start";
				if ( norm_disp == "secondary" ) return "Secondary pistol to purchase automatically at round start";
				if ( norm_disp == "armor" ) return "Automatically purchase kevlar body armor and helmet";
				if ( norm_disp == "defuser" ) return "Automatically purchase defusal kit at round start";
				if ( norm_disp == "taser" ) return "Automatically purchase Zeus x27 taser at round start";
				if ( norm_disp == "grenades" ) return "Select utility grenades to purchase automatically";
			}
			else if ( norm_suf.starts_with( "hudcross" ) )
			{
				if ( norm_disp == "size" ) return "Size and arm length of custom crosshair overlay";
				if ( norm_disp == "outline" ) return "Border thickness around custom crosshair arms";
				if ( norm_disp == "color" ) return "Color of the custom crosshair overlay";
				if ( norm_disp == "outline color" ) return "Outline color of the custom crosshair overlay";
			}
			else if ( norm_suf.starts_with( "hudscope" ) )
			{
				if ( norm_disp == "line length" ) return "Length of custom sniper scope crosshair lines";
				if ( norm_disp == "gap" ) return "Center gap offset of custom sniper scope lines";
				if ( norm_disp == "thickness" ) return "Line thickness of custom sniper scope crosshair";
				if ( norm_disp == "animation speed" ) return "Fade and transition speed for custom scope lines";
				if ( norm_disp == "color" ) return "Color of custom sniper scope crosshair";
				if ( norm_disp == "fade in" ) return "Smoothly fade scope lines in when zooming in";
				if ( norm_disp == "glow" ) return "Enables glowing aura around scope crosshair lines";
				if ( norm_disp == "glow strength" ) return "Glow bloom strength for custom sniper scope";
			}
			else if ( norm_suf.starts_with( "hat" ) )
			{
				if ( norm_disp == "type" ) return "Select 3D cosmetic hat model attached to your player head";
				if ( norm_disp == "color" ) return "Primary color and texture tint of the cosmetic hat";
				if ( norm_disp == "secondary color" ) return "Secondary accent color of the cosmetic hat";
				if ( norm_disp == "glow" ) return "Enables glowing outline around cosmetic hat model";
				if ( norm_disp == "glow strength" ) return "Glow bloom strength for cosmetic hat model";
			}
			else if ( norm_suf.starts_with( "velocity" ) )
			{
				if ( norm_disp == "color" ) return "Text and background color for speedometer counter";
				if ( norm_disp == "bottom offset" ) return "Vertical screen position offset from bottom of display";
				if ( norm_disp == "width" ) return "Horizontal width of the speed dynamics graph";
				if ( norm_disp == "height" ) return "Vertical height of the speed dynamics graph";
			}
			else if ( norm_suf.starts_with( "hs" ) )
			{
				if ( norm_disp == "type" ) return "Select sound effect played upon hitting an enemy";
				if ( norm_disp == "volume" ) return "Playback volume of hit sound effect";
				if ( norm_disp == "sound" ) return "Select or enter custom .wav audio file for hit sound";
				if ( norm_disp == "preview" || norm_disp.find( "preview" ) != std::string::npos ) return "Play a preview test of the selected hit sound";
			}
			else if ( norm_suf.starts_with( "ds" ) )
			{
				if ( norm_disp == "type" ) return "Select sound effect played upon killing an enemy";
				if ( norm_disp == "volume" ) return "Playback volume of death kill sound effect";
				if ( norm_disp == "sound" ) return "Select or enter custom .wav audio file for death kill sound";
				if ( norm_disp == "preview" || norm_disp.find( "preview" ) != std::string::npos ) return "Play a preview test of the selected death sound";
			}
			else if ( norm_suf.starts_with( "hm" ) )
			{
				if ( norm_disp == "type" ) return "Visual style of hit marker: classic crosshair ticks, damage numbers, or both";
				if ( norm_disp == "duration" ) return "Duration in seconds hit markers remain visible on screen";
				if ( norm_disp == "color" ) return "Color of hit marker crosshair ticks";
				if ( norm_disp == "glow" ) return "Enables glowing aura around hit marker";
				if ( norm_disp == "glow strength" ) return "Glow bloom intensity for hit marker";
			}
			else if ( norm_suf.starts_with( "he" ) )
			{
				if ( norm_disp == "color" ) return "Color of particle sparks and flash effect on hit";
				if ( norm_disp == "duration" ) return "Duration of hit visual particle effect";
				if ( norm_disp == "strength" ) return "Intensity and particle density of hit effect";
			}
			else if ( norm_suf.starts_with( "de" ) )
			{
				if ( norm_disp == "color" ) return "Color of visual effect displayed upon killing an enemy";
			}
			else if ( norm_suf.starts_with( "bi" ) )
			{
				if ( norm_disp == "type" ) return "Style of bullet impact marks: 3D box overlay, spark particles, or both";
				if ( norm_disp == "fill" ) return "Inner box color of 3D bullet impact markers";
				if ( norm_disp == "edge" ) return "Edge line color of 3D bullet impact markers";
				if ( norm_disp == "spark" ) return "Color of spark particles emitted from bullet impacts";
				if ( norm_disp == "duration" ) return "Lifetime in seconds before bullet impact markers disappear";
				if ( norm_disp == "glow" ) return "Enables glowing aura around bullet impact markers";
				if ( norm_disp == "glow strength" ) return "Glow bloom intensity for bullet impact markers";
			}
			else if ( norm_suf.starts_with( "tracer" ) )
			{
				if ( norm_disp == "color" ) return "Color of glowing beam line following bullet trajectory";
				if ( norm_disp == "duration" ) return "Duration bullet tracer beams remain visible";
			}
			else if ( norm_suf.starts_with( "traj" ) )
			{
				if ( norm_disp == "straight throw" ) return "Show trajectory line for standard primary attack throw";
				if ( norm_disp == "held" ) return "Color of trajectory line while holding grenade ready to throw";
				if ( norm_disp == "thrown" ) return "Color of trajectory line for grenades already flying in air";
				if ( norm_disp == "held damage" ) return "Warning color when held grenade blast radius will cause damage";
				if ( norm_disp == "thrown damage" ) return "Warning color when flying grenade will inflict damage upon explosion";
				if ( norm_disp == "glow" ) return "Enables glowing aura around grenade trajectory lines";
				if ( norm_disp == "glow strength" ) return "Glow bloom intensity for grenade trajectory lines";
			}
			else if ( norm_suf.starts_with( "dlight" ) )
			{
				if ( norm_disp == "color" ) return "Color of dynamic light source emitted from your player";
				if ( norm_disp == "radius" ) return "Illumination radius in game units for dynamic light";
				if ( norm_disp == "z offset" ) return "Vertical elevation offset of the dynamic light source";
			}
			else if ( norm_suf.starts_with( "wm" ) )
			{
				if ( norm_disp == "position" ) return "Screen corner anchor position for cheat watermark overlay";
				if ( norm_disp == "opacity" ) return "Background and text opacity of cheat watermark overlay";
			}
			else if ( norm_suf.starts_with( "vm_" ) )
			{
				if ( norm_disp == "x" ) return "Horizontal viewmodel weapon position offset";
				if ( norm_disp == "y" ) return "Forward/backward viewmodel weapon position offset";
				if ( norm_disp == "z" ) return "Vertical viewmodel weapon position offset";
				if ( norm_disp == "fov" ) return "Viewmodel field of view (hand and weapon scale)";
			}
			else if ( norm_suf.starts_with( "bloom" ) )
			{
				if ( norm_disp == "value" ) return "Bloom post-processing glow intensity multiplier";
			}
			else if ( norm_suf.starts_with( "gamma" ) )
			{
				if ( norm_disp == "value" ) return "Gamma brightness and contrast correction curve";
			}
			else if ( norm_suf.starts_with( "mb" ) )
			{
				if ( norm_disp == "strength" ) return "Intensity and exposure strength of camera motion blur";
				if ( norm_disp == "smoothness" ) return "Smoothing filter applied to camera rotational velocity";
				if ( norm_disp == "samples" ) return "Number of directional motion blur texture samples (quality)";
				if ( norm_disp == "center clarity" ) return "Preserves crosshair center screen sharpness to maintain aim visibility";
				if ( norm_disp == "movement blur" ) return "Includes linear player movement velocity in motion blur calculation";
			}
			else if ( norm_suf.starts_with( "chatspam" ) )
			{
				if ( norm_disp == "text" ) return "Message text string to broadcast in chat";
				if ( norm_disp == "delay" ) return "Delay interval in seconds between consecutive chat messages";
				if ( norm_disp == "targets" ) return "Target chat channels to broadcast to (all chat, team chat)";
			}
			else if ( norm_suf.starts_with( "killsay" ) )
			{
				if ( norm_disp == "text" ) return "Custom message text to send automatically after scoring a kill";
			}
			else if ( norm_suf.starts_with( "camera" ) )
			{
				if ( norm_disp.find( "aspect" ) != std::string::npos ) return "Custom screen aspect ratio value (e.g. 1.333 for 4:3, 1.777 for 16:9)";
			}
			else if ( norm_suf.starts_with( "scoreboard" ) )
			{
				if ( norm_disp == "color" ) return "Color tint for weapon icons displayed on scoreboard";
			}
			else if ( norm_suf.starts_with( "override" ) )
			{
				if ( norm_disp == "nickname" || norm_disp == "name" ) return "Enter custom spoofed player nickname";
			}
			else if ( norm_suf.starts_with( "visible" ) )
			{
				if ( norm_disp == "color" ) return "Color applied to visible player model surfaces";
				if ( norm_disp == "material" ) return "Texture shader material for visible player models";
				if ( norm_disp == "filled" ) return "Fills model body when using outline or outline glow chams";
			}
			else if ( norm_suf.starts_with( "wall" ) )
			{
				if ( norm_disp == "color" ) return "Color applied to occluded player model surfaces behind walls";
				if ( norm_disp == "material" ) return "Texture shader material for occluded player models behind walls";
				if ( norm_disp == "filled" ) return "Fills model body when using outline or outline glow chams";
			}
			else if ( norm_suf.starts_with( "overlay" ) )
			{
				if ( norm_disp == "color" ) return "Color applied to top chams overlay layer";
				if ( norm_disp == "material" ) return "Texture shader material for top chams overlay layer";
				if ( norm_disp == "filled" ) return "Fills model body when using outline or outline glow chams";
			}
			else if ( norm_suf.starts_with( "ft" ) )
			{
				if ( norm_disp == "fade" ) return "Fade-out lifetime duration in seconds for onshot ghost chams";
			}
			else if ( norm_suf.starts_with( "cfg" ) )
			{
				if ( norm_disp == "name" ) return "Enter configuration profile name or search filter";
			}
			else if ( norm_suf.find( "item_sel" ) != std::string::npos || norm_suf.find( "proj_sel" ) != std::string::npos )
			{
				if ( norm_disp == "group" ) return "Select category group to configure independent visuals";
			}
			else if ( norm_suf.find( "layer" ) != std::string::npos || norm_suf.find( "primary" ) != std::string::npos || norm_suf.find( "secondary" ) != std::string::npos )
			{
				if ( norm_disp.find( "primary" ) != std::string::npos ) return "First base material layer applied to player model";
				if ( norm_disp.find( "secondary" ) != std::string::npos ) return "Secondary overlay material layer applied to player model";
				if ( norm_disp.find( "overlay" ) != std::string::npos ) return "Topmost overlay material layer applied to player model";
			}

			// Outline glow parameters in popups
			if ( norm_disp == "intensity" ) return "Brightness and intensity multiplier of the outline glow effect";
			if ( norm_disp == "thickness" ) return "Outline border thickness of the glow effect";
			if ( norm_disp == "softness" ) return "Edge blur and dispersion softness of the outline glow";
			if ( norm_disp == "opacity" ) return "Opacity and transparency level of the outline glow";
			if ( norm_disp == "inner spread" ) return "Inward spread and coverage of the glow onto the model body";
			if ( norm_disp == "pulse speed" ) return "Animated breathing and pulse speed of the outline glow";
		}

		// 5. Contextual disambiguation by parent window title
		const auto cur_win = layout::current_window( );
		const std::string norm_parent = cur_win ? tooltips::normalize_label( cur_win->title ) : "";

		if ( norm_disp == "enable" || norm_disp == "enabled" )
		{
			if ( norm_parent.find( "rage" ) != std::string::npos ) return "Enables automated rage aimbot and shooting system";
			if ( norm_parent.find( "legit" ) != std::string::npos ) return "Enables smooth, humanized aim assistance for stealthy gameplay";
			if ( norm_parent.find( "player" ) != std::string::npos || norm_parent.find( "esp" ) != std::string::npos ) return "Enables visual ESP overlays for this player category";
			if ( norm_parent.find( "world" ) != std::string::npos ) return "Enables visual enhancements for world elements";
			if ( norm_parent.find( "mov" ) != std::string::npos ) return "Enables movement assistance features";
			if ( norm_parent.find( "watermark" ) != std::string::npos || norm_parent.find( "wm" ) != std::string::npos ) return "Enables branded watermark status overlay on screen";
			return "Enables or disables this feature";
		}
		if ( norm_disp == "fill" )
		{
			return "Renders a subtle semi-transparent background fill inside the 2D box";
		}
		if ( norm_disp == "outline" )
		{
			if ( norm_parent.find( "box" ) != std::string::npos ) return "Renders a dark outer border outline around the bounding box";
			if ( norm_parent.find( "health" ) != std::string::npos || norm_parent.find( "hp" ) != std::string::npos ) return "Renders a dark outer border outline around the health bar";
			if ( norm_parent.find( "ammo" ) != std::string::npos ) return "Renders a dark outer border outline around the ammo bar";
			return "Renders a dark high-contrast border outline";
		}
		if ( norm_disp == "material" )
		{
			return "Selects texture shader material: metallic, flat, glow, electric, distortion, hologram, outline glow, etc.";
		}
		if ( norm_disp == "filled" )
		{
			return "Fills model interior when using outline or outline glow chams";
		}
		if ( norm_disp == "color" )
		{
			if ( norm_parent.find( "name" ) != std::string::npos ) return "Color of player username text label";
			if ( norm_parent.find( "weather" ) != std::string::npos ) return "Color tint for atmospheric weather particles";
			if ( norm_parent.find( "world" ) != std::string::npos ) return "Custom color tint applied to map surfaces and textures";
			if ( norm_parent.find( "lighting" ) != std::string::npos ) return "Custom ambient lighting color applied to world surfaces";
			if ( norm_parent.find( "fog" ) != std::string::npos ) return "Custom color of the atmospheric distance fog";
			if ( norm_parent.find( "glow" ) != std::string::npos ) return "Color of the glowing outline aura";
			if ( norm_parent.find( "fov" ) != std::string::npos ) return "Color of the visible aimbot FOV circle";
			if ( norm_parent.find( "scoreboard" ) != std::string::npos ) return "Color tint for weapon icons displayed on scoreboard";
			if ( norm_parent.find( "theme" ) != std::string::npos ) return "Custom menu interface accent color";
			return "Color tint and opacity level for this element";
		}
		if ( norm_disp == "style" )
		{
			if ( norm_parent.find( "box" ) != std::string::npos ) return "Select full 2D bounding box or cornered bracket style";
			if ( norm_parent.find( "marker" ) != std::string::npos || norm_parent.find( "hm" ) != std::string::npos ) return "Visual style of hit marker: classic ticks, damage numbers, or both";
			return "Select visual rendering style";
		}
		if ( norm_disp == "mode" )
		{
			if ( norm_parent.find( "skel" ) != std::string::npos ) return "Skeleton render mode: normal bones or backtrack history ticks";
			if ( norm_parent.find( "edgebug" ) != std::string::npos || norm_parent.find( "eb" ) != std::string::npos ) return "Edgebug calculation mode (0: loose, 1: edge trace, 2: no jump held, 3: min speed, 4: strict vz)";
			return "Select operational mode";
		}
		if ( norm_disp == "type" )
		{
			if ( norm_parent.find( "weather" ) != std::string::npos ) return "Select weather particle effect: snow, rain, or stars";
			if ( norm_parent.find( "sound" ) != std::string::npos || norm_parent.find( "hs" ) != std::string::npos || norm_parent.find( "ds" ) != std::string::npos ) return "Select audio sound effect type";
			if ( norm_parent.find( "impact" ) != std::string::npos || norm_parent.find( "bi" ) != std::string::npos ) return "Style of bullet impact marks: 3D box overlay, spark particles, or both";
			if ( norm_parent.find( "marker" ) != std::string::npos || norm_parent.find( "hm" ) != std::string::npos ) return "Visual style of hit marker: classic ticks, damage numbers, or both";
			if ( norm_parent.find( "hat" ) != std::string::npos ) return "Select 3D cosmetic hat model attached to your player head";
			return "Select option type";
		}
		if ( norm_disp == "thickness" )
		{
			if ( norm_parent.find( "skel" ) != std::string::npos ) return "Line width of rendered player skeleton bones";
			if ( norm_parent.find( "glow" ) != std::string::npos ) return "Outline border thickness of the glow effect";
			if ( norm_parent.find( "scope" ) != std::string::npos ) return "Line thickness of custom sniper scope crosshair";
			return "Adjusts line and border thickness";
		}
		if ( norm_disp == "intensity" )
		{
			if ( norm_parent.find( "light" ) != std::string::npos ) return "Adjusts ambient world lighting brightness and intensity";
			if ( norm_parent.find( "glow" ) != std::string::npos ) return "Brightness and intensity multiplier of the outline glow effect";
			return "Adjusts effect intensity level";
		}
		if ( norm_disp == "softness" )
		{
			return "Edge blur and dispersion softness of the outline glow";
		}
		if ( norm_disp == "opacity" )
		{
			if ( norm_parent.find( "glow" ) != std::string::npos ) return "Opacity and transparency level of the outline glow";
			if ( norm_parent.find( "alpha" ) != std::string::npos ) return "Local player model opacity when zoomed in or near camera";
			if ( norm_parent.find( "wm" ) != std::string::npos || norm_parent.find( "watermark" ) != std::string::npos ) return "Background and text opacity of cheat watermark overlay";
			return "Adjusts transparency and opacity level";
		}
		if ( norm_disp == "inner spread" )
		{
			return "Inward spread and coverage of the glow onto the model body";
		}
		if ( norm_disp == "pulse speed" )
		{
			return "Animated breathing and pulse speed of the outline glow";
		}
		if ( norm_disp == "glow" )
		{
			if ( norm_parent.find( "oof" ) != std::string::npos ) return "Applies a glowing aura around out-of-view directional arrows";
			if ( norm_parent.find( "health" ) != std::string::npos || norm_parent.find( "hp" ) != std::string::npos ) return "Applies a glowing aura around the health bar";
			if ( norm_parent.find( "ammo" ) != std::string::npos ) return "Applies a glowing aura around the ammo bar";
			if ( norm_parent.find( "player" ) != std::string::npos || norm_parent.find( "local" ) != std::string::npos ) return "Renders a vibrant outline glow aura around the player model";
			if ( norm_parent.find( "item" ) != std::string::npos ) return "Renders a glowing outline aura around dropped weapons";
			if ( norm_parent.find( "ragdoll" ) != std::string::npos ) return "Renders a glowing outline aura around dead player bodies";
			return "Renders an illuminated glow effect around this element";
		}
		if ( norm_disp == "speed" )
		{
			if ( norm_parent.find( "freecam" ) != std::string::npos ) return "Flight movement speed of the free spectator camera";
			if ( norm_parent.find( "wet" ) != std::string::npos ) return "Speed of surface ripple animations and slick reflections";
			if ( norm_parent.find( "slow" ) != std::string::npos ) return "Maximum player movement speed limit during slow walk";
			return "Adjusts movement or animation speed";
		}
		if ( norm_disp == "density" )
		{
			if ( norm_parent.find( "fog" ) != std::string::npos ) return "Density and thickness of atmospheric distance fog";
			if ( norm_parent.find( "wet" ) != std::string::npos ) return "Intensity and puddle coverage of the wet surface effect";
			return "Adjusts visual particle and effect density";
		}
		if ( norm_disp == "duration" )
		{
			if ( norm_parent.find( "hitlog" ) != std::string::npos || norm_parent.find( "hl" ) != std::string::npos ) return "Duration in seconds hit log notices remain on screen";
			if ( norm_parent.find( "misslog" ) != std::string::npos || norm_parent.find( "ml" ) != std::string::npos ) return "Duration in seconds miss log notices remain on screen";
			if ( norm_parent.find( "marker" ) != std::string::npos || norm_parent.find( "hm" ) != std::string::npos ) return "Duration in seconds hit markers remain visible on screen";
			if ( norm_parent.find( "tracer" ) != std::string::npos ) return "Duration bullet tracer beams remain visible";
			if ( norm_parent.find( "impact" ) != std::string::npos || norm_parent.find( "bi" ) != std::string::npos ) return "Lifetime in seconds before bullet impact markers disappear";
			if ( norm_parent.find( "effect" ) != std::string::npos ) return "Duration of visual hit particle effect";
			return "Adjusts on-screen duration in seconds";
		}
		if ( norm_disp == "passes" )
		{
			return "Number of predictive simulation passes for edgebug detection";
		}
		if ( norm_disp == "jump steps" )
		{
			return "Include jump tick simulation in edgebug prediction";
		}
		if ( norm_disp == "only when scoped" )
		{
			return "Only apply model transparency while aiming through a weapon scope";
		}
		if ( norm_disp == "preview" || norm_disp.find( "preview" ) != std::string::npos )
		{
			return "Play a preview test of the selected sound effect";
		}
		if ( norm_disp == "min" )
		{
			return "Minimum recoil reduction percentage";
		}
		if ( norm_disp == "max" )
		{
			return "Maximum recoil reduction percentage";
		}
		if ( norm_disp == "strength" )
		{
			if ( norm_parent.find( "rcs" ) != std::string::npos || norm_parent.find( "legit" ) != std::string::npos ) return "Recoil compensation strength for standalone RCS";
			if ( norm_parent.find( "blur" ) != std::string::npos || norm_parent.find( "motion" ) != std::string::npos ) return "Intensity and exposure strength of camera motion blur";
			if ( norm_parent.find( "effect" ) != std::string::npos || norm_parent.find( "hit" ) != std::string::npos ) return "Intensity and particle density of hit effect";
			if ( norm_parent.find( "wind" ) != std::string::npos ) return "Wind velocity affecting atmospheric weather particles";
			return "Adjusts effect or feature strength multiplier";
		}
		if ( norm_disp == "smoothness" )
		{
			if ( norm_parent.find( "blur" ) != std::string::npos || norm_parent.find( "motion" ) != std::string::npos ) return "Smoothing filter applied to camera rotational velocity";
			return "Crosshair movement smoothing to simulate natural human aim";
		}
		if ( norm_disp == "samples" )
		{
			return "Number of directional motion blur texture samples (quality)";
		}
		if ( norm_disp == "delay" )
		{
			if ( norm_parent.find( "chat" ) != std::string::npos || norm_parent.find( "spam" ) != std::string::npos ) return "Delay interval in seconds between consecutive chat messages";
			return "Human reaction delay in milliseconds before triggerbot fires";
		}
		if ( norm_disp == "text" )
		{
			if ( norm_parent.find( "kill" ) != std::string::npos ) return "Custom message text to send automatically after scoring a kill";
			if ( norm_parent.find( "chat" ) != std::string::npos || norm_parent.find( "spam" ) != std::string::npos ) return "Message text string to broadcast in chat";
			return "Enter custom text string";
		}
		if ( norm_disp == "position" )
		{
			if ( norm_parent.find( "hp" ) != std::string::npos || norm_parent.find( "health" ) != std::string::npos ) return "Screen position of player health bar (left, top, bottom)";
			if ( norm_parent.find( "ammo" ) != std::string::npos ) return "Screen position of player ammo bar (left, top, bottom)";
			if ( norm_parent.find( "watermark" ) != std::string::npos || norm_parent.find( "wm" ) != std::string::npos ) return "Screen corner anchor position for cheat watermark overlay";
			return "Select on-screen display anchor position";
		}
		if ( norm_disp == "primary" )
		{
			if ( norm_parent.find( "buy" ) != std::string::npos ) return "Primary weapon to purchase automatically at round start";
			return "First base material layer applied to model";
		}
		if ( norm_disp == "secondary" )
		{
			if ( norm_parent.find( "buy" ) != std::string::npos ) return "Secondary pistol to purchase automatically at round start";
			return "Secondary overlay material layer applied to model";
		}

		// 6. Direct fallback exact match on norm_disp if in k_exact
		if ( it_disp != k_exact.end( ) )
		{
			return it_disp->second;
		}

		return {};
	}

	void set_hovered_tooltip( std::string_view label, std::string_view explicit_desc )
	{
		if ( !tooltips::is_enabled( ) )
		{
			return;
		}

		auto& c = get_ctx( );
		if ( c.overlay_blocking( ) )
		{
			return;
		}

		auto [display, full] = parse_label( label );
		if ( display.empty( ) )
		{
			if ( full.empty( ) )
			{
				return;
			}
			if ( full == "##seed_input" )
			{
				display = "Pattern Seed";
			}
			else
			{
				display = full;
			}
		}

		std::string desc_str;
		if ( !explicit_desc.empty( ) )
		{
			desc_str = std::string( explicit_desc );
		}
		else
		{
			auto d = get_function_description( label );
			if ( !d.empty( ) )
			{
				desc_str = std::string( d );
			}
			else
			{
				desc_str = tooltips::get_fallback_description( display );
			}
		}

		const auto id = fnv1a( label );
		auto& t = tooltips::g_tooltip;
		t.current_hovered_id = id;

		std::string title_str = std::string( display );
		bool cap_next = true;
		for ( auto& ch : title_str )
		{
			if ( std::isspace( static_cast<unsigned char>( ch ) ) || ch == '_' || ch == '-' || ch == '(' || ch == '/' )
			{
				cap_next = true;
			}
			else if ( cap_next )
			{
				ch = static_cast<char>( std::toupper( static_cast<unsigned char>( ch ) ) );
				cap_next = false;
			}
		}

		t.current_title = std::move( title_str );
		t.current_desc = std::move( desc_str );
		t.current_mouse_x = c.input.mouse_x;
		t.current_mouse_y = c.input.mouse_y;
	}


	void tooltip( std::string_view desc )
	{
		// Optional explicit tooltip call
	}

	static void render_active_tooltip( const style& st, const input_state& input )
	{
		if ( !tooltips::is_enabled( ) )
		{
			auto& t = tooltips::g_tooltip;
			t.alpha = 0.0f;
			t.target_alpha = 0.0f;
			t.current_hovered_id = 0;
			t.active_id = 0;
			return;
		}

		const float dt = std::clamp( xdraw::delta_time( ), 0.001f, 0.1f );
		auto& t = tooltips::g_tooltip;

		const bool is_hovered = ( t.current_hovered_id != 0 );

		if ( is_hovered )
		{
			if ( t.active_id != t.current_hovered_id )
			{
				t.active_id = t.current_hovered_id;
				t.active_title = std::move( t.current_title );
				t.active_desc = std::move( t.current_desc );
				if ( t.alpha < 0.2f )
				{
					t.hover_timer = 0.0f;
				}
				else
				{
					t.hover_timer = 0.06f;
				}
			}

			t.hover_timer += dt;
			if ( t.hover_timer >= 0.08f )
			{
				t.target_alpha = 1.0f;
			}
		}
		else
		{
			t.hover_timer = 0.0f;
			t.target_alpha = 0.0f;
		}

		// Clear current hovered id for next frame
		t.current_hovered_id = 0;

		const float speed = ( t.target_alpha > t.alpha ) ? 14.0f : 16.0f;
		t.alpha += ( t.target_alpha - t.alpha ) * std::min( speed * dt, 1.0f );

		if ( t.alpha < 0.005f )
		{
			t.alpha = 0.0f;
			if ( !is_hovered )
			{
				t.active_id = 0;
			}
			return;
		}

		const float ease_alpha = ease::out_cubic( t.alpha );

		const float target_mx = ( t.current_mouse_x > 0.0f ) ? t.current_mouse_x : input.mouse_x;
		const float target_my = ( t.current_mouse_y > 0.0f ) ? t.current_mouse_y : input.mouse_y;

		if ( t.alpha < 0.05f )
		{
			t.pos_x = target_mx + 14.0f;
			t.pos_y = target_my + 16.0f;
		}
		else
		{
			t.pos_x += ( ( target_mx + 14.0f ) - t.pos_x ) * std::min( 22.0f * dt, 1.0f );
			t.pos_y += ( ( target_my + 16.0f ) - t.pos_y ) * std::min( 22.0f * dt, 1.0f );
		}

		const auto lines = tooltips::wrap_text( t.active_desc, 230.0f );
		const auto [tw, th] = xdraw::measure_text( t.active_title );
		float max_line_w = tw;
		for ( const auto& line : lines )
		{
			max_line_w = std::max( max_line_w, xdraw::measure_text( line ).first );
		}

		constexpr float pad_x = 12.0f;
		const float tip_w = std::clamp( max_line_w + pad_x * 2.0f + 6.0f, 160.0f, 280.0f );
		constexpr float line_h = 15.0f;
		const float tip_h = 9.0f + th + ( lines.empty( ) ? 0.0f : ( 6.0f + static_cast<float>( lines.size( ) ) * line_h ) ) + 9.0f;

		auto [vw, vh] = xdraw::viewport_size( );
		if ( vw <= 0 || vh <= 0 )
		{
			vw = 1920;
			vh = 1080;
		}

		float draw_x = t.pos_x;
		float draw_y = t.pos_y + ( 1.0f - ease_alpha ) * 4.0f;

		if ( draw_x + tip_w > static_cast<float>( vw ) - 12.0f )
		{
			draw_x = target_mx - tip_w - 10.0f;
		}
		if ( draw_y + tip_h > static_cast<float>( vh ) - 12.0f )
		{
			draw_y = target_my - tip_h - 10.0f;
		}
		draw_x = std::clamp( draw_x, 10.0f, static_cast<float>( vw ) - tip_w - 10.0f );
		draw_y = std::clamp( draw_y, 10.0f, static_cast<float>( vh ) - tip_h - 10.0f );

		auto& dl = xdraw::get( xdraw::layer::top );

		// Outer soft drop shadow
		dl.rect_filled( draw_x - 3.0f, draw_y - 2.0f, tip_w + 6.0f, tip_h + 6.0f, xdraw::color{ 0, 0, 0, static_cast<std::uint8_t>( 95.0f * ease_alpha ) }, xdraw::corner_radius{ 7.0f } );
		// Backdrop blur
		dl.rect_filled_blurred( draw_x, draw_y, tip_w, tip_h, xdraw::corner_radius{ 6.0f }, xdraw::color{ 255, 255, 255, static_cast<std::uint8_t>( 200.0f * ease_alpha ) } );
		// Dark OLED base
		dl.rect_filled( draw_x, draw_y, tip_w, tip_h, xdraw::color{ 16, 16, 20, static_cast<std::uint8_t>( 242.0f * ease_alpha ) }, xdraw::corner_radius{ 6.0f } );
		// Border with accent tint
		dl.rect( draw_x, draw_y, tip_w, tip_h, lerp( st.child_border, st.accent, 0.35f ).alpha( static_cast<std::uint8_t>( 170.0f * ease_alpha ) ), xdraw::corner_radius{ 6.0f } );

		// Vertical accent indicator strip on left
		dl.rect_filled( draw_x + 1.0f, draw_y + 4.0f, 4.0f, tip_h - 8.0f, st.accent.alpha( static_cast<std::uint8_t>( 35.0f * ease_alpha ) ), xdraw::corner_radius{ 2.0f } );
		dl.rect_filled( draw_x + 2.0f, draw_y + 5.0f, 2.0f, tip_h - 10.0f, st.accent.alpha( static_cast<std::uint8_t>( 235.0f * ease_alpha ) ), xdraw::corner_radius{ 1.0f } );

		// Title
		dl.text( draw_x + pad_x, draw_y + 8.0f, t.active_title, st.text.alpha( static_cast<std::uint8_t>( 255.0f * ease_alpha ) ) );

		if ( !lines.empty( ) )
		{
			dl.line( draw_x + pad_x, draw_y + 8.0f + th + 3.0f, draw_x + tip_w - pad_x, draw_y + 8.0f + th + 3.0f, st.child_border.alpha( static_cast<std::uint8_t>( 120.0f * ease_alpha ) ) );

			float curr_y = draw_y + 8.0f + th + 8.0f;
			for ( const auto& line : lines )
			{
				dl.text( draw_x + pad_x, curr_y, line, st.text_dim.alpha( static_cast<std::uint8_t>( 225.0f * ease_alpha ) ) );
				curr_y += line_h;
			}
		}
	}

	void end( )
	{
		auto& c = get_ctx( );

		if ( overlays::has_any( ) )
		{
			overlays::process( c.input );
		}

		overlays::render( c.style, c.input );
		overlays::sweep( );

		render_active_tooltip( c.style, c.input );

		if ( c.input.mouse_released )
		{
			c.active_window = null_id;
			c.active_resize = null_id;
			c.active_slider = null_id;
			c.active_child_scroll = null_id;
		}

		c.input.clear_frame( );
	}

	bool wndproc( UINT msg, WPARAM wp, LPARAM lp )
	{
		// WndProc may run during rendering; never erase new events at frame end.
		std::lock_guard lock( pending_input_mutex );
		return feed_wndproc( pending_input, msg, wp, lp );
	}

	bool begin_window( std::string_view title, float& x, float& y, float& w, float& h, bool resizable, float min_w, float min_h, float reveal )
	{
		auto& c = get_ctx( );
		const auto id = make_id( title );
		const auto& s = c.style;
		const auto& input = c.input;
		const auto r = s.window_rounding;
		auto abs = rect{ std::floorf( x ), std::floorf( y ), std::floorf( w ), std::floorf( h ) };

		const auto reveal_clamped = std::clamp( reveal, 0.0f, 1.0f );
		const auto allow_window_drag = reveal_clamped >= 0.98f;

		constexpr auto grip_size{ 16.0f };
		const auto grip = rect{ abs.right( ) - grip_size, abs.bottom( ) - grip_size, grip_size, grip_size };
		const auto grip_hovered = resizable && allow_window_drag && input.in_rect( grip );
		const auto drag_region = title == "##menu" ? rect{abs.x, abs.y, abs.w, 68.0f} : abs;
        const auto window_hovered = allow_window_drag && input.in_rect(drag_region);

		if ( grip_hovered && input.mouse_clicked && c.active_resize == null_id )
		{
			c.active_resize = id;
		}

		if ( c.active_resize == id && input.mouse_down )
		{
			w = std::max( min_w, w + input.mouse_delta_x( ) );
			h = std::max( min_h, h + input.mouse_delta_y( ) );
			abs.w = w;
			abs.h = h;
		}
		else if ( window_hovered && !grip_hovered && input.mouse_clicked&& c.active_window == null_id&& c.active_slider == null_id&& c.active_resize == null_id&& c.active_text_input == null_id&& c.active_child_scroll == null_id&& !c.overlay_blocking( ) )
		{
			c.active_window = id;
		}

		if ( allow_window_drag && c.active_window == id && input.mouse_down&& c.active_slider == null_id&& c.active_resize == null_id&& c.active_text_input == null_id&& c.active_child_scroll == null_id )
		{
			// The press frame may include movement from before the click.
			if ( !input.mouse_clicked )
			{
				x += input.mouse_delta_x( );
				y += input.mouse_delta_y( );
			}
			abs.x = x;
			abs.y = y;
		}

		window_state state{};
		state.title = std::string( title );
		state.bounds = abs;
		state.cursor_x = s.window_pad_x;
		state.cursor_y = s.window_pad_y;
		state.is_child = false;

		c.windows.push_back( std::move( state ) );

		auto& dl = draw::current( );

		const auto draw_w = abs.w * reveal_clamped;
		const auto draw_h = abs.h * reveal_clamped;
		const auto draw_x = abs.x + ( abs.w - draw_w ) * 0.5f;
		const auto draw_y = abs.y + ( abs.h - draw_h ) * 0.5f;

		auto window_bg = s.window_bg;
		window_bg.a = static_cast< std::uint8_t >( window_bg.a * reveal_clamped );
		auto window_border = s.window_border;
		window_border.a = static_cast< std::uint8_t >( window_border.a * reveal_clamped );

		const auto blur_alpha = static_cast< std::uint8_t >( 170.0f * reveal_clamped );
		dl.rect_filled_blurred( draw_x, draw_y, draw_w, draw_h, xdraw::corner_radius{ r }, xdraw::color{ 55, 60, 70, blur_alpha } );

		dl.rect_filled( draw_x, draw_y, draw_w, draw_h, window_bg, xdraw::corner_radius{ r } );

		if ( s.border_thickness > 0.0f )
		{
			dl.rect( draw_x, draw_y, draw_w, draw_h, window_border, xdraw::corner_radius{ r }, s.border_thickness );
		}

		dl.push_clip( draw_x, draw_y, draw_w, draw_h );
		push_id( id );

		return true;
	}

	void end_window( )
	{
		draw::current( ).pop_clip( );
		get_ctx( ).windows.pop_back( );
		pop_id( );
	}

	bool begin_child( std::string_view title, float w, float h, bool scrollable, bool has_background )
	{
		auto& c = get_ctx( );
		const auto parent = layout::current_window_const( );

		if ( !parent )
		{
			return false;
		}

		const auto id = make_id( title );
		const auto& s = c.style;
		const auto r = s.rounding;

		if ( w <= 0.0f )
		{
			w = layout::item_width( );
		}

		auto pwin = layout::current_window( );
		const auto consumed_y = pwin->cursor_y + ( pwin->line_h > 0.0f ? pwin->line_h + s.item_spacing_y : 0.0f );
		const auto max_h = parent->bounds.h - consumed_y - s.window_pad_y;

		auto actual_h = h;
		if ( actual_h <= 0.0f )
		{
			actual_h = max_h > 0.0f ? max_h : 550.0f;
		}
		else if ( max_h > 0.0f )
		{
			actual_h = std::min( actual_h, max_h );
		}

		const auto abs = layout::item( w, actual_h );
		auto scroll_y{ 0.0f };

		if ( scrollable )
		{
			auto& cs = c.child_scroll_cache[ id ];
			scroll_y = cs.scroll;
		}

		window_state state{};
		state.title = std::string( title );
		state.bounds = rect{ abs.x, abs.y, abs.w, abs.h };
		state.cursor_x = has_background ? s.window_pad_x : 0.0f;
		state.cursor_y = ( has_background ? s.window_pad_y : 0.0f ) - scroll_y;
		state.is_child = true;
		state.group_id = id;
		state.scrollable = scrollable;
		state.scroll_y = scroll_y;

		c.windows.push_back( std::move( state ) );

		auto& dl = draw::current( );

		if ( has_background )
		{
			dl.rect_filled_blurred( abs.x, abs.y, abs.w, abs.h, xdraw::corner_radius{ r }, xdraw::color{ 45, 50, 60, 150 } );
			dl.rect_filled( abs.x, abs.y, abs.w, abs.h, s.child_bg, xdraw::corner_radius{ r } );

			// Subtle liquid glass sheen overlay on child panels
			dl.rect_filled_gradient( abs.x, abs.y, abs.w, std::min( abs.h, 24.0f ),
				xdraw::color{ 255, 255, 255, 6 }, xdraw::color{ 255, 255, 255, 6 },
				xdraw::color{ 255, 255, 255, 1 }, xdraw::color{ 255, 255, 255, 1 },
				xdraw::corner_radius::top( r ) );

			if ( s.border_thickness > 0.0f )
			{
				dl.rect( abs.x, abs.y, abs.w, abs.h, s.child_border, xdraw::corner_radius{ r }, s.border_thickness );
			}
		}

		dl.push_clip( abs.x, abs.y, abs.w, abs.h );
		push_id( id );

		return true;
	}

	void end_child( )
	{
		auto& c = get_ctx( );
		auto win = layout::current_window( );

		if ( win && win->group_id != null_id )
		{
			const auto& s = c.style;
			const auto& input = c.input;
			const auto true_content_h = win->content_h + win->scroll_y + s.window_pad_y;
			const auto visible_h = win->bounds.h;

			if ( win->scrollable )
			{
				const auto max_scroll = std::max( 0.0f, true_content_h - visible_h );
				auto& cs = c.child_scroll_cache[ win->group_id ];
				const auto dt = xdraw::delta_time( );

				const auto popup_hovered = !c.overlay_blocking( ) && input.in_rect( win->bounds );

				if ( max_scroll > 0.0f && !c.overlay_blocking( ) )
				{
					if ( popup_hovered && input.scroll_delta != 0.0f )
					{
						cs.scroll_target -= input.scroll_delta * 40.0f;
					}
				}

				cs.scroll_target = std::clamp( cs.scroll_target, 0.0f, max_scroll );
				cs.scroll += ( cs.scroll_target - cs.scroll ) * std::min( 18.0f * dt, 1.0f );
				cs.scroll = std::clamp( cs.scroll, 0.0f, max_scroll );

				draw::current( ).pop_clip( );
			}
			else
			{
				c.child_height_cache[ win->group_id ] = true_content_h;
				draw::current( ).pop_clip( );
			}
		}
		else
		{
			draw::current( ).pop_clip( );
		}

		c.windows.pop_back( );
		pop_id( );
	}

	void draw_gear( xdraw::draw_list& dl, float cx, float cy, xdraw::color col, float size )
	{
		const float r_outer = size * 0.5f;
		const float r_hub = size * 0.32f;
		const float r_inner = size * 0.25f;
		const float r_pin = size * 0.12f;
		const float tooth_thick = size * 0.18f;
		const float hub_thick = size * 0.14f;

		constexpr int k_teeth = 6;
		constexpr float k_step = 3.14159265f / 3.0f;
		for ( int i = 0; i < k_teeth; ++i )
		{
			const float a = static_cast< float >( i ) * k_step;
			const float cos_a = std::cos( a );
			const float sin_a = std::sin( a );
			dl.line( cx + cos_a * r_inner, cy + sin_a * r_inner,
					 cx + cos_a * r_outer, cy + sin_a * r_outer,
					 col, tooth_thick );
		}

		dl.circle( cx, cy, r_hub, col, hub_thick, 16 );

		if ( r_pin >= 0.8f )
		{
			dl.circle_filled( cx, cy, r_pin, col, 8 );
		}
	}

	bool begin_popup( std::string_view label, float width, const xdraw::color* swatch_color, bool is_arrow )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return false;
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto& s = c.style;
		const auto& input = c.input;

		constexpr auto dot_area_w{ 16.0f };
		const auto dot_area_h = win->last_item.h;
		float dot_x{ 0.0f };
		if ( win->last_item_is_toggle )
		{
			dot_x = win->last_toggle_x - dot_area_w - 6.0f;
		}
		else
		{
			dot_x = win->bounds.x + win->bounds.w - s.window_pad_x - dot_area_w;
		}
		const auto dot_local_y = win->last_item.y;
		const auto dot_abs = rect{ std::floorf( dot_x ), std::floorf( win->bounds.y + dot_local_y ), dot_area_w, dot_area_h };

		const auto is_open = overlays::is_open( id );
		const auto can_interact = !c.overlay_blocking( ) || is_open;
		const auto hovered = can_interact && input.in_rect( dot_abs );

		if ( hovered && !is_open )
		{
			set_hovered_tooltip( "Settings", "Configure advanced options for this feature" );
		}

		const auto hover_anim = anim::lerp( id + 1, hovered ? 1.0f : 0.0f, 12.0f );
		const auto open_anim = anim::lerp( id + 2, is_open ? 1.0f : 0.0f, 10.0f );
		auto dot_col = lerp( s.text_dim, s.accent, std::max( hover_anim, open_anim ) );

		auto& dl = draw::current( );

		if ( swatch_color )
		{
			constexpr auto sw_size = 14.0f;
			const auto sx = dot_abs.x + ( dot_area_w - sw_size ) * 0.5f;
			const auto sy = dot_abs.y + ( dot_area_h - sw_size ) * 0.5f;
			dl.rect_filled( sx, sy, sw_size, sw_size, *swatch_color, xdraw::corner_radius{ 3.5f } );
			dl.rect( sx, sy, sw_size, sw_size, xdraw::color{ 255, 255, 255, 45 }, xdraw::corner_radius{ 3.5f }, 1.0f );
		}
		else if ( is_arrow )
		{
			const auto ax = dot_abs.x + dot_area_w * 0.5f;
			const auto ay = dot_abs.y + dot_area_h * 0.5f;
			dl.line( ax - 2.0f, ay - 4.5f, ax + 2.5f, ay, dot_col, 1.6f );
			dl.line( ax + 2.5f, ay, ax - 2.0f, ay + 4.5f, dot_col, 1.6f );
		}
		else
		{
			const auto cx = dot_abs.x + dot_area_w * 0.5f;
			const auto cy = dot_abs.y + dot_area_h * 0.5f;
			draw_gear( dl, cx, cy, dot_col, 11.0f );
		}

		if ( hovered && input.mouse_clicked )
		{
			if ( is_open )
			{
				overlays::close( id );
			}
			else
			{
				float initial_h = 100.0f;
				if ( c.child_height_cache.contains( id ) && c.child_height_cache[ id ] > 0.0f )
				{
					initial_h = c.child_height_cache[ id ];
				}
				auto ov_ptr = std::make_unique<popup_overlay>( id, dot_abs, width, win->bounds );
				ov_ptr->set_content_h( initial_h );
				overlays::add( std::move( ov_ptr ) );
			}
		}

		auto ov = dynamic_cast< popup_overlay* >( overlays::find( id ) );
		if ( ov && !ov->is_closed( ) )
		{
			overlays::touch( id );
			ov->update_anchor( dot_abs );
			ov->update_parent_bounds( win->bounds );
			ov->tick( );

			const auto popup_rect = ov->get_popup( );
			const auto et = ease::out_cubic( ov->open_anim( ) );
			const auto animated_h = popup_rect.h * et;
			const auto alpha_mult = et;

			auto& top_dl = xdraw::get( xdraw::layer::top );

			auto bg = s.popup_bg;
			bg.a = static_cast< std::uint8_t >( bg.a * alpha_mult );
			auto border = lighten( s.popup_border, 1.1f );
			border.a = static_cast< std::uint8_t >( border.a * alpha_mult );

			if ( animated_h > 1.0f )
			{
				top_dl.rect_filled_blurred( popup_rect.x, popup_rect.y, popup_rect.w, animated_h, xdraw::corner_radius{ s.popup_rounding }, xdraw::color{ 255, 255, 255, static_cast< std::uint8_t >( 210.0f * alpha_mult ) } );
			}
			top_dl.rect_filled( popup_rect.x, popup_rect.y, popup_rect.w, animated_h, bg, xdraw::corner_radius{ s.popup_rounding } );
			top_dl.rect( popup_rect.x, popup_rect.y, popup_rect.w, animated_h, border, xdraw::corner_radius{ s.popup_rounding } );

			draw::push_layer( xdraw::layer::top );

			auto scroll_y{ 0.0f };
			auto& cs = c.child_scroll_cache[ id ];
			scroll_y = cs.scroll;

			window_state state{};
			state.title = std::string( label );
			state.bounds = popup_rect;
			state.cursor_x = s.window_pad_x;
			state.cursor_y = s.window_pad_y - scroll_y;
			state.is_child = true;
			state.group_id = id;
			state.scrollable = true;
			state.scroll_y = scroll_y;

			c.windows.push_back( std::move( state ) );
			push_id( id );

			top_dl.push_clip( popup_rect.x, popup_rect.y, popup_rect.w, animated_h );

			c.inside_overlay = id;

			return true;
		}

		return false;
	}

	void end_popup( )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return;
		}

		auto& c = get_ctx( );
		const auto& s = c.style;
		const auto& input = c.input;
		const auto true_content_h = win->content_h + win->scroll_y + s.window_pad_y;
		const auto visible_h = win->bounds.h;

		for ( auto& o : get_overlays( ).list )
		{
			auto ov = dynamic_cast< popup_overlay* >( o.get( ) );
			if ( ov && !ov->closing( ) )
			{
				ov->set_content_h( true_content_h );
				break;
			}
		}

		if ( win->group_id != null_id && win->scrollable )
		{
			c.child_height_cache[ win->group_id ] = true_content_h;

			const auto max_scroll = std::max( 0.0f, true_content_h - visible_h );
			auto& cs = c.child_scroll_cache[ win->group_id ];
			const auto dt = xdraw::delta_time( );

			const auto popup_hovered = input.in_rect( win->bounds );

			if ( max_scroll > 0.0f )
			{
				if ( popup_hovered && input.scroll_delta != 0.0f )
				{
					cs.scroll_target -= input.scroll_delta * 40.0f;
				}
			}

			cs.scroll_target = std::clamp( cs.scroll_target, 0.0f, max_scroll );
			cs.scroll += ( cs.scroll_target - cs.scroll ) * std::min( 18.0f * dt, 1.0f );
			cs.scroll = std::clamp( cs.scroll, 0.0f, max_scroll );

			// Draw sleek scrollbar if content exceeds visible area
			if ( max_scroll > 0.0f )
			{
				constexpr auto sb_w{ 3.5f };
				constexpr auto sb_pad{ 3.0f };
				const auto track_h = visible_h - sb_pad * 2.0f;
				const auto thumb_h = std::max( 16.0f, track_h * ( visible_h / true_content_h ) );
				const auto thumb_travel = track_h - thumb_h;
				const auto thumb_y = win->bounds.y + sb_pad + ( cs.scroll / max_scroll ) * thumb_travel;
				const auto thumb_x = win->bounds.right( ) - sb_w - sb_pad;

				const auto hit_rect = rect{ thumb_x - 4.0f, win->bounds.y + sb_pad, sb_w + 8.0f, track_h };
				const auto is_hovered = input.in_rect( hit_rect );

				if ( is_hovered && input.mouse_down && thumb_travel > 0.0f )
				{
					const auto rel_y = std::clamp( ( input.mouse_y - ( win->bounds.y + sb_pad + thumb_h * 0.5f ) ) / thumb_travel, 0.0f, 1.0f );
					cs.scroll_target = rel_y * max_scroll;
					cs.scroll = cs.scroll_target;
				}

				const auto sb_col = is_hovered ? s.accent : s.accent.alpha( 130 );

				auto& top_dl = xdraw::get( xdraw::layer::top );
				top_dl.rect_filled( thumb_x, thumb_y, sb_w, thumb_h, sb_col, xdraw::corner_radius{ sb_w * 0.5f } );
			}
		}

		c.inside_overlay = null_id;

		xdraw::get( xdraw::layer::top ).pop_clip( );
		pop_id( );
		c.windows.pop_back( );
		draw::pop_layer( );
	}

	void text( std::string_view label, xdraw::color col )
	{
		if ( !layout::current_window( ) )
		{
			return;
		}

		const auto [display, full] = parse_label( label );
		const auto [lw, lh] = xdraw::measure_text( display );
		const auto abs = layout::item( lw, lh );

		draw::current( ).text( abs.x, abs.y, display, col );
	}

	bool button( std::string_view label, float w, float h )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return false;
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto [display, full] = parse_label( label );
		const auto& s = c.style;
		const auto& input = c.input;

		const auto [avail_w, avail_h] = layout::avail( );
		const auto final_w = ( w > 0.0f ) ? w : avail_w;
		const auto final_h = ( h > 0.0f ) ? h : 28.0f;
		const auto abs = layout::item( final_w, final_h );
		const auto can_interact = !c.overlay_blocking( );
		const auto hovered = can_interact && input.in_rect( abs );
		const auto held = hovered && input.mouse_down;
		const auto pressed = hovered && input.mouse_clicked;

		if ( hovered )
		{
			set_hovered_tooltip( label );
		}

		const auto hover_anim = anim::lerp( id, hovered ? 1.0f : 0.0f, 12.0f );
		const auto active_anim = anim::lerp( id + 1, held ? 1.0f : 0.0f, 15.0f );

		auto bg = lerp( s.button_bg, s.button_hovered, hover_anim );
		bg = lerp( bg, s.button_active, active_anim );

		const auto r = s.button_rounding;
		const auto border = lerp( s.button_border, lighten( s.button_border, 1.2f ), hover_anim );

		auto& dl = draw::current( );
		dl.rect_filled( abs.x, abs.y, abs.w, abs.h, bg, xdraw::corner_radius{ r } );
		dl.rect( abs.x, abs.y, abs.w, abs.h, border, xdraw::corner_radius{ r } );

		if ( !display.empty( ) )
		{
			const auto available_w = abs.w - s.frame_pad_x * 2.0f;
			const auto label_text = truncate( display, available_w );
			const auto [lw, lh] = xdraw::measure_text( label_text );
			const auto tx = abs.x + ( abs.w - lw ) * 0.5f;
			const auto ty = abs.y + ( abs.h - lh ) * 0.5f;
			const auto text_col = lerp( s.text_dim, s.text, hover_anim );
			dl.text( tx, ty, label_text, text_col );
		}

		return pressed;
	}

	namespace {

		void draw_minimal_checkbox(
			xdraw::draw_list& dl,
			float x,
			float y,
			float size,
			float t,
			const style& st,
			float alpha_mult = 1.0f )
		{
			auto bg = st.checkbox_bg;
			bg.a = static_cast< std::uint8_t >( bg.a * alpha_mult );
			dl.rect_filled( x, y, size, size, bg, xdraw::corner_radius{ st.checkbox_rounding } );

			if ( t > 0.01f )
			{
				auto mark = st.checkbox_mark;
				mark.a = static_cast< std::uint8_t >( mark.a * t * alpha_mult );
				dl.rect_filled( x, y, size, size, mark, xdraw::corner_radius{ st.checkbox_rounding } );
			}
		}

        void draw_minimal_slider(xdraw::draw_list& dl, float x, float y, float w,
            float h, float norm_pos, const style& st)
        {
            constexpr float inset = 5.0f;
            const auto span = std::max(0.0f, w - inset * 2.0f);
            const auto amount = std::clamp(norm_pos, 0.0f, 1.0f);
            const auto cx = x + inset + amount * span;
            const auto cy = y + h * 0.5f;
            dl.rect_filled(x + inset, y, span, h, st.slider_track, xdraw::corner_radius{h * 0.5f});
            if (amount > 0.0f)
            {
                dl.rect_filled(x + inset, y - 2.0f, amount * span, h + 4.0f,
                    st.slider_fill.alpha(18), xdraw::corner_radius{h});
                dl.rect_filled(x + inset, y, amount * span, h,
                    st.slider_fill, xdraw::corner_radius{h * 0.5f});
            }
            dl.circle_filled(cx, cy, 7.0f, st.slider_fill.alpha(25));
            dl.circle_filled(cx, cy, 5.0f, st.slider_fill.alpha(85));
            dl.circle_filled(cx, cy, 3.5f, st.slider_fill);
            dl.circle_filled(cx, cy, 2.0f, xdraw::color{247,255,251});
        }

		class checkbox_bind_overlay : public overlay
		{
		public:
			checkbox_bind_overlay( std::uintptr_t id, const rect& anchor, setting* s ) : overlay{ id, anchor }, m_setting{ s }
			{
				this->m_hover_anims.fill( 0.0f );
				this->m_item_anims.fill( 0.0f );
			}

			[[nodiscard]] bool hit_test( float x, float y ) const override
			{
				return this->get_popup( ).contains( x, y );
			}

			bool process_input( const input_state& input ) override
			{
				if ( this->m_closing )
				{
					return false;
				}

				const auto popup = this->get_popup( );

				if ( this->m_listening )
				{
					if ( input.mouse_clicked && !popup.contains( input.mouse_x, input.mouse_y ) )
					{
						this->m_listening = false;
						binds::get_bind_registry( ).listening_setting = 0;
						return true;
					}

					for ( const auto vk : input.key_presses( ) )
					{
						if ( vk == VK_ESCAPE )
						{
							if ( this->m_setting )
							{
								this->m_setting->bind.key = 0;
								this->m_setting->bind.active = false;
							}
						}
						else
						{
							if ( this->m_setting )
							{
								this->m_setting->bind.key = vk;
							}
						}

						this->m_listening = false;
						binds::get_bind_registry( ).listening_setting = 0;
						return true;
					}

					if ( input.rmb_clicked )
					{
						if ( this->m_setting )
						{
							this->m_setting->bind.key = VK_RBUTTON;
						}

						this->m_listening = false;
						binds::get_bind_registry( ).listening_setting = 0;
						return true;
					}

					return true;
				}

				if ( ( input.mouse_clicked || input.rmb_clicked ) && !popup.contains( input.mouse_x, input.mouse_y ) )
				{
					this->m_closing = true;
					return true;
				}

				if ( input.mouse_clicked && popup.contains( input.mouse_x, input.mouse_y ) )
				{
					for ( int i = 0; i < k_item_count; ++i )
					{
						const auto ir = this->get_item_rect( popup, i );

						if ( ir.contains( input.mouse_x, input.mouse_y ) )
						{
							if ( i == 0 )
							{
								this->m_listening = true;
								binds::get_bind_registry( ).listening_setting = reinterpret_cast< std::uintptr_t >( this->m_setting );
							}
							else if ( i == 1 )
							{
								if ( this->m_setting )
								{
									auto m = static_cast< int >( this->m_setting->bind.mode );
									m = ( m + 1 ) % 3;
									this->m_setting->bind.mode = static_cast< bind_mode >( m );
								}
							}
							else if ( i == 2 )
							{
								if ( this->m_setting )
								{
									this->m_setting->bind.key = 0;
									this->m_setting->bind.active = false;
									this->m_setting->bind.mode = bind_mode::toggle;
								}

								this->m_closing = true;
							}

							return true;
						}
					}
				}

				return popup.contains( input.mouse_x, input.mouse_y );
			}

			void render( const style& style, const input_state& input ) override
			{
				const auto dt = xdraw::delta_time( );
				const auto popup = this->get_popup( );
				auto& dl = xdraw::get( xdraw::layer::top );

				const auto speed = this->m_closing ? 18.0f : 16.0f;
				const auto target = this->m_closing ? 0.0f : 1.0f;
				this->m_open_anim += ( target - this->m_open_anim ) * std::min( speed * dt, 1.0f );

				if ( this->m_open_anim < 0.01f && this->m_closing )
				{
					this->m_closed = true;
					return;
				}

				const auto ease_t = ease::out_cubic( this->m_open_anim );
				const auto alpha_mult = ease_t;
				const auto animated_h = popup.h * ease_t;
				const auto pr = style.popup_rounding;

				auto bg = style.popup_bg;
				bg.a = static_cast< std::uint8_t >( bg.a * alpha_mult );
				auto border = lighten( style.popup_border, 1.1f );
				border.a = static_cast< std::uint8_t >( border.a * alpha_mult );

				if ( animated_h > 1.0f )
				{
					dl.rect_filled_blurred( popup.x, popup.y, popup.w, animated_h, xdraw::corner_radius{ pr }, xdraw::color{ 255, 255, 255, static_cast< std::uint8_t >( 210.0f * alpha_mult ) } );
				}
				dl.rect_filled( popup.x, popup.y, popup.w, animated_h, bg, xdraw::corner_radius{ pr } );

				if ( border.a > 0 )
				{
					dl.rect( popup.x, popup.y, popup.w, animated_h, border, xdraw::corner_radius{ pr } );
				}

				dl.push_clip( popup.x, popup.y, popup.w, animated_h );

				const auto key_text = this->m_listening ? "..." : ( this->m_setting ? vk_name( this->m_setting->bind.key ) : "none" );
				const auto mode_text = this->m_setting ? binds::mode_name( this->m_setting->bind.mode ) : "toggle";

				for ( int i = 0; i < k_item_count; ++i )
				{
					const auto ir = this->get_item_rect( popup, i );

					const auto item_delay = i * 0.05f;
					const auto item_progress = std::clamp( this->m_open_anim - item_delay, 0.0f, 1.0f ) / ( 1.0f - std::min( item_delay, 0.25f ) );
					auto& ia = this->m_item_anims[ i ];
					ia = std::min( ia + 20.0f * dt, item_progress );

					const auto item_ease = ease::out_cubic( ia );
					const auto item_alpha = item_ease * alpha_mult;
					const auto slide = ( 1.0f - item_ease ) * 6.0f;

					const auto is_hovered = !this->m_closing && ir.contains( input.mouse_x, input.mouse_y ) && !( this->m_listening && i != 0 );
					auto& ha = this->m_hover_anims[ i ];
					ha += ( ( is_hovered ? 1.0f : 0.0f ) - ha ) * std::min( 18.0f * dt, 1.0f );

					const auto is_first = ( i == 0 );
					const auto is_last = ( i == k_item_count - 1 );

					if ( ha > 0.01f )
					{
						auto hov = style.combo_popup_item_hovered;
						hov.a = static_cast< std::uint8_t >( hov.a * item_alpha * ha );
						dl.rect_filled( ir.x, ir.y + slide, ir.w, ir.h, hov, xdraw::corner_radius{ is_first ? pr : 0.0f, is_first ? pr : 0.0f, is_last ? pr : 0.0f, is_last ? pr : 0.0f } );
					}

					if ( i == 0 && this->m_listening )
					{
						this->m_listen_pulse += dt * 3.0f;
						if ( this->m_listen_pulse > 6.28318f )
						{
							this->m_listen_pulse -= 6.28318f;
						}

						const auto pulse = std::sin( this->m_listen_pulse ) * 0.5f + 0.5f;
						auto pulse_col = style.keybind_waiting;
						pulse_col.a = static_cast< std::uint8_t >( 30.0f * item_alpha * ( 0.5f + pulse * 0.5f ) );
						dl.rect_filled( ir.x, ir.y + slide, ir.w, ir.h, pulse_col, xdraw::corner_radius{ is_first ? pr : 0.0f, is_first ? pr : 0.0f, 0.0f, 0.0f } );
					}

					if ( i == 2 )
					{
						auto text_col = style.text_dim;
						text_col = lerp( text_col, style.text, ha );
						text_col.a = static_cast< std::uint8_t >( text_col.a * item_alpha );

						const auto [cw, ch] = xdraw::measure_text( "clear bind" );
						dl.text( ir.x + ( ir.w - cw ) * 0.5f, ir.y + ( k_item_h - ch ) * 0.5f + slide, "clear bind", text_col );
					}
					else
					{
						static constexpr const char* row_labels[ ]{ "key", "mode" };
						const char* row_values[ ]{ key_text, mode_text };

						const auto [lw, lh] = xdraw::measure_text( row_labels[ i ] );
						auto label_col = style.text_dim;
						label_col.a = static_cast< std::uint8_t >( label_col.a * item_alpha );
						dl.text( ir.x + 8.0f, ir.y + ( k_item_h - lh ) * 0.5f + slide, row_labels[ i ], label_col );

						const auto [vw, vh] = xdraw::measure_text( row_values[ i ] );
						auto val_col = ( i == 0 && this->m_listening ) ? style.keybind_waiting : style.text;
						val_col = lerp( val_col, lighten( val_col, 1.3f ), ha );
						val_col.a = static_cast< std::uint8_t >( val_col.a * item_alpha );
						dl.text( ir.right( ) - vw - 8.0f, ir.y + ( k_item_h - vh ) * 0.5f + slide, row_values[ i ], val_col );
					}
				}

				dl.pop_clip( );
			}

		private:
			static constexpr auto k_item_count{ 3 };
			static constexpr auto k_item_h{ 24.0f };
			static constexpr auto k_pad{ 4.0f };
			static constexpr auto k_popup_w{ 150.0f };

			[[nodiscard]] rect get_popup( ) const
			{
				const auto h = k_pad * 2.0f + k_item_h * static_cast< float >( k_item_count );
				return { this->m_anchor.x, this->m_anchor.y, k_popup_w, h };
			}

			[[nodiscard]] rect get_item_rect( const rect& popup, int index ) const
			{
				return { popup.x + k_pad, popup.y + k_pad + static_cast< float >( index ) * k_item_h, popup.w - k_pad * 2.0f, k_item_h };
			}

			setting* m_setting{};
			float m_open_anim{};
			bool m_listening{};
			float m_listen_pulse{};
			std::array<float, k_item_count> m_hover_anims{};
			std::array<float, k_item_count> m_item_anims{};
		};

	} // the checkbox_bind namespace

	bool checkbox( std::string_view label, setting& s )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return false;
		}

		binds::register_setting( &s );

		if ( s.name.empty( ) )
		{
			const auto [display, full] = parse_label( label );
			s.name = std::string( display );
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto [display, full] = parse_label( label );
		const auto& st = c.style;
		const auto& input = c.input;

		const auto check_size = st.checkbox_size;
		const auto abs = layout::item( check_size, check_size );

		const auto [lw, lh] = xdraw::measure_text( display );
		const auto full_w = !display.empty( ) ? ( abs.w + st.item_spacing_x + lw ) : abs.w;
		const auto extended = rect{ abs.x, abs.y, full_w, abs.h };

		const auto can_interact = !c.overlay_blocking( );
		auto changed{ false };

		const auto badge_id = id + 300;
		auto& reg = binds::get_bind_registry( );
		const auto badge_listening = ( reg.listening_setting == badge_id );

		if ( badge_listening )
		{
			for ( const auto vk : input.key_presses( ) )
			{
				if ( vk == VK_ESCAPE )
				{
					s.bind.key = 0;
					s.bind.active = false;
				}
				else
				{
					s.bind.key = vk;
				}

				reg.listening_setting = 0;
				break;
			}

			if ( badge_listening && input.rmb_clicked )
			{
				s.bind.key = VK_RBUTTON;
				reg.listening_setting = 0;
			}
		}

		const auto hovered = can_interact && input.in_rect( extended ) && !badge_listening;
		if ( hovered )
		{
			set_hovered_tooltip( label );
		}
		if ( hovered && input.mouse_clicked )
		{
			s.value = !s.value;
			s.bind.active = s.value;

			if ( s.value && s.bind.excludes )
			{
				s.bind.excludes->bind.active = false;
				s.bind.excludes->value = false;
			}

			changed = true;
		}

		const auto ctx_id = id + 200;
		const auto ctx_is_open = overlays::is_open( ctx_id );

		if ( ctx_is_open )
		{
			overlays::touch( ctx_id );
		}

		if ( hovered && input.rmb_clicked && ( !c.overlay_blocking( ) || ctx_is_open ) )
		{
			if ( ctx_is_open )
			{
				overlays::close( ctx_id );
			}
			else if ( !c.overlay_blocking( ) )
			{
				const auto mouse_anchor = rect{ input.mouse_x, input.mouse_y, 0.0f, 0.0f };
				overlays::add( std::make_unique<checkbox_bind_overlay>( ctx_id, mouse_anchor, &s ) );
			}
		}

		const auto check_anim = anim::lerp( id, s.value ? 1.0f : 0.0f, 8.0f );
		const auto hover_anim = anim::lerp( id + 1, hovered ? 1.0f : 0.0f, 10.0f );
		const auto ease_t = ease::smoothstep( check_anim );

		auto& dl = draw::current( );

		const auto now = std::chrono::steady_clock::now( );
		const auto& hl = get_highlight_state( );
		const auto is_highlighted = !hl.label.empty( ) && now < hl.expires_at && display == hl.label;
		const auto highlight_anim = anim::lerp( id + 97, is_highlighted ? 1.0f : 0.0f, 18.0f );

		draw_minimal_checkbox( dl, abs.x, abs.y, abs.w, ease_t, st );

		if ( highlight_anim > 0.01f )
		{
			auto pulse = st.accent;
			pulse.a = static_cast< std::uint8_t >( std::min( 255.0f, pulse.a * ( 0.2f + highlight_anim * 0.55f ) ) );
			dl.rect_filled( extended.x - 4.0f, extended.y - 2.0f, extended.w + 8.0f, extended.h + 4.0f, pulse, xdraw::corner_radius{ 8.0f } );
		}

		if ( !display.empty( ) )
		{
			const auto tx = abs.x + abs.w + st.item_spacing_x;
			const auto ty = abs.y + ( check_size - lh ) * 0.5f;
			const auto available_w = win->bounds.right( ) - tx - st.window_pad_x;
			const auto label_text = truncate( display, available_w );
			auto label_col = lerp( st.text_dim, st.text, std::max( check_anim, hover_anim ) );
			if ( highlight_anim > 0.01f )
			{
				const auto glow_col = lerp( st.accent, st.text, 0.35f );
				label_col = lerp( label_col, glow_col, std::clamp( highlight_anim, 0.0f, 1.0f ) );

				auto shadow = st.accent;
				shadow.a = static_cast< std::uint8_t >( std::min( 255.0f, 120.0f * highlight_anim ) );
				dl.text( tx + 1.0f, ty, label_text, shadow );
			}
			dl.text( tx, ty, label_text, label_col );

			if ( s.bind.key != 0 || badge_listening )
			{
				const auto badge_text = badge_listening ? "..." : vk_name( s.bind.key );
				const auto [kw, kh] = xdraw::measure_text( badge_text );

				const auto badge_pad_x{ 4.0f };
				const auto badge_pad_y{ 1.0f };
				const auto badge_w = kw + badge_pad_x * 2.0f;
				const auto badge_h = kh + badge_pad_y * 2.0f;

				const auto [displayed_w, displayed_h] = xdraw::measure_text( label_text );
				const auto badge_x = tx + displayed_w + 4.0f;
				const auto badge_y = ty + ( lh - badge_h ) * 0.5f;
				const auto badge_rect = rect{ badge_x, badge_y, badge_w, badge_h };

				if ( badge_x + badge_w < win->bounds.right( ) - st.window_pad_x )
				{
					const auto badge_hovered = can_interact && input.in_rect( badge_rect );
					if ( badge_hovered && input.mouse_clicked && !badge_listening && !c.overlay_blocking( ) )
					{
						reg.listening_setting = badge_id;
					}
					else if ( badge_listening && input.mouse_clicked && !badge_hovered )
					{
						reg.listening_setting = 0;
					}

					const auto bind_active_anim = anim::lerp( id + 50, s.value ? 1.0f : 0.0f, 8.0f );
					const auto badge_hover_anim = anim::lerp( id + 51, ( badge_hovered || badge_listening ) ? 1.0f : 0.0f, 12.0f );

					auto badge_bg = st.keybind_bg;
					badge_bg.a = static_cast< std::uint8_t >( std::max( badge_bg.a, static_cast< std::uint8_t >( 40 ) ) );
					badge_bg = lighten( badge_bg, 1.0f + badge_hover_anim * 0.3f );

					auto badge_border = lerp( st.keybind_border, st.accent, std::max( bind_active_anim * 0.5f, badge_hover_anim * 0.8f ) );
					badge_border.a = static_cast< std::uint8_t >( std::max( badge_border.a, static_cast< std::uint8_t >( 30 ) ) );

					if ( badge_listening )
					{
						badge_border = lerp( badge_border, st.keybind_waiting, 0.6f );
					}

					const auto badge_r = st.keybind_rounding;

					dl.rect_filled( badge_x, badge_y, badge_w, badge_h, badge_bg, xdraw::corner_radius{ badge_r } );
					dl.rect( badge_x, badge_y, badge_w, badge_h, badge_border, xdraw::corner_radius{ badge_r } );

					auto key_col = lerp( st.text_dim, st.accent, bind_active_anim );
					key_col = lerp( key_col, st.text, badge_hover_anim );

					if ( badge_listening )
					{
						key_col = st.keybind_waiting;
					}

					dl.text( badge_x + badge_pad_x, badge_y + badge_pad_y, badge_text, key_col );
				}
			}
		}

		return changed;
	}

    void section_header(std::string_view label)
    {
        const auto* win = layout::current_window_const();
        if (!win) return;
        const auto& st = get_ctx().style;
        const auto abs = layout::item(layout::item_width(), 18.0f);
        auto& dl = draw::current();
        const auto text_h = xdraw::measure_text(label).second;
        dl.text(abs.x, abs.y + (abs.h - text_h) * 0.5f, label, st.text);
    }

    bool toggle(std::string_view label, setting& s, std::string_view description)
    {
        auto* win = layout::current_window();
        if (!win) return false;
        binds::register_setting(&s);
        const auto [display, full] = parse_label(label);
        if (s.name.empty()) s.name = std::string(display);
        auto& c = get_ctx();
        const auto id = make_id(label);
        const auto& st = c.style;
        const auto& input = c.input;

        auto& reg = binds::get_bind_registry();
        const auto badge_id = id + 300;
        const auto badge_listening = (reg.listening_setting == badge_id);

        if (badge_listening)
        {
            for (const auto vk : input.key_presses())
            {
                if (vk == VK_ESCAPE)
                {
                    s.bind.key = 0;
                    s.bind.active = false;
                }
                else
                {
                    s.bind.key = vk;
                }
                reg.listening_setting = 0;
                break;
            }

            if (badge_listening && input.rmb_clicked)
            {
                s.bind.key = VK_RBUTTON;
                reg.listening_setting = 0;
            }
        }

        const auto [avail_w, avail_h] = layout::avail();
        constexpr auto row_h = 30.0f;
        constexpr float toggle_w = 36.0f, toggle_h = 18.0f, thumb_r = 6.0f;
        const auto abs = layout::item(avail_w, row_h);

        const auto px = abs.right() - toggle_w;
        const auto py = abs.y + (row_h - toggle_h) * 0.5f;

        win->last_item_is_toggle = true;
        win->last_toggle_x = px;

        const auto ctx_id = id + 200;
        const auto ctx_is_open = overlays::is_open(ctx_id);
        if (ctx_is_open)
        {
            overlays::touch(ctx_id);
        }

        constexpr float dot_area_w = 16.0f;
        const auto dot_rect = rect{ px - dot_area_w - 6.0f, abs.y, dot_area_w + 6.0f, row_h };
        const auto dot_hovered = input.in_rect(dot_rect);

        const bool has_badge = (s.bind.key != 0 || badge_listening);
        rect badge_rect{};
        bool badge_hovered = false;
        std::string badge_text{};

        const auto [label_w, label_h] = xdraw::measure_text(display);
        const auto label_y = abs.y + (row_h - label_h) * 0.5f;

        if (has_badge)
        {
            badge_text = badge_listening ? "..." : vk_name(s.bind.key);
            const auto [kw, kh] = xdraw::measure_text(badge_text);
            constexpr float badge_pad_x = 5.0f;
            constexpr float badge_pad_y = 1.0f;
            const float badge_w = kw + badge_pad_x * 2.0f;
            const float badge_h = kh + badge_pad_y * 2.0f;
            float badge_x = abs.x + label_w + 8.0f;
            const float max_badge_x = px - dot_area_w - 12.0f - badge_w;
            if (badge_x > max_badge_x) badge_x = max_badge_x;
            const float badge_y = label_y + (label_h - badge_h) * 0.5f;
            badge_rect = rect{ badge_x, badge_y, badge_w, badge_h };
            badge_hovered = !c.overlay_blocking() && input.in_rect(win->bounds) && input.in_rect(badge_rect);

            if (badge_hovered && input.mouse_clicked && !badge_listening && !c.overlay_blocking())
            {
                reg.listening_setting = badge_id;
            }
            else if (badge_listening && input.mouse_clicked && !badge_hovered)
            {
                reg.listening_setting = 0;
            }
        }

        const auto can_interact = (!c.overlay_blocking() || ctx_is_open) && input.in_rect(win->bounds);
        const auto hovered = can_interact && input.in_rect(abs) && !badge_listening && !badge_hovered && !dot_hovered;

        if (hovered)
        {
            set_hovered_tooltip(label, description);
        }

        bool changed = false;

        // Right-click handling: open keybind context overlay
        if (hovered && input.rmb_clicked && (!c.overlay_blocking() || ctx_is_open))
        {
            if (ctx_is_open)
            {
                overlays::close(ctx_id);
            }
            else if (!c.overlay_blocking())
            {
                const auto mouse_anchor = rect{ input.mouse_x, input.mouse_y, 0.0f, 0.0f };
                overlays::add(std::make_unique<checkbox_bind_overlay>(ctx_id, mouse_anchor, &s));
            }
        }

        // Left-click handling: toggle value
        if (hovered && input.mouse_clicked)
        {
            s.value = !s.value;
            s.bind.active = s.value;
            if (s.value && s.bind.excludes)
            {
                s.bind.excludes->bind.active = false;
                s.bind.excludes->value = false;
            }
            c.active_window = null_id;
            changed = true;
        }

        const auto t = ease::smoothstep(anim::lerp(id, s.value ? 1.0f : 0.0f, 14.0f));
        const auto hover = anim::lerp(id + 1, hovered ? 1.0f : 0.0f, 14.0f);
        auto& dl = draw::current();

        const auto reserved_right = toggle_w + dot_area_w + 14.0f;
        dl.text(abs.x, label_y, truncate(display, abs.w - reserved_right), st.text);

        // Draw keybind badge if active/listening
        if (has_badge && badge_rect.w > 0.0f)
        {
            const auto bind_active_anim = anim::lerp(id + 50, s.value ? 1.0f : 0.0f, 8.0f);
            const auto badge_hover_anim = anim::lerp(id + 51, (badge_hovered || badge_listening) ? 1.0f : 0.0f, 12.0f);

            auto badge_bg = st.keybind_bg;
            badge_bg.a = static_cast<std::uint8_t>(std::max(badge_bg.a, static_cast<std::uint8_t>(40)));
            badge_bg = lighten(badge_bg, 1.0f + badge_hover_anim * 0.3f);

            auto badge_border = lerp(st.keybind_border, st.accent, std::max(bind_active_anim * 0.5f, badge_hover_anim * 0.8f));
            badge_border.a = static_cast<std::uint8_t>(std::max(badge_border.a, static_cast<std::uint8_t>(30)));

            if (badge_listening)
            {
                badge_border = lerp(badge_border, st.keybind_waiting, 0.6f);
            }

            const auto badge_r = st.keybind_rounding;
            dl.rect_filled(badge_rect.x, badge_rect.y, badge_rect.w, badge_rect.h, badge_bg, xdraw::corner_radius{ badge_r });
            dl.rect(badge_rect.x, badge_rect.y, badge_rect.w, badge_rect.h, badge_border, xdraw::corner_radius{ badge_r });

            auto key_col = lerp(st.text_dim, st.accent, bind_active_anim);
            key_col = lerp(key_col, st.text, badge_hover_anim);
            if (badge_listening) key_col = st.keybind_waiting;

            dl.text(badge_rect.x + 5.0f, badge_rect.y + 1.0f, badge_text, key_col);
        }

        // Draw toggle pill
        const auto radius = xdraw::corner_radius{toggle_h * 0.5f};
        if (t > 0.01f)
        {
            for (int i = 3; i > 0; --i)
                dl.rect(px - i, py - i, toggle_w + i * 2.0f, toggle_h + i * 2.0f,
                    st.accent.alpha(static_cast<std::uint8_t>((18 - i * 4) * t)), xdraw::corner_radius{9.0f + i});
        }
        dl.rect_filled(px, py, toggle_w, toggle_h, lerp(st.checkbox_bg, st.accent, 0.10f * t), radius);
        dl.rect(px, py, toggle_w, toggle_h,
            lerp(st.checkbox_border, st.accent.alpha(170), std::max(t, hover * 0.5f)), radius);
        const auto cx = std::lerp(px + 9.0f, px + toggle_w - 9.0f, t);
        const auto cy = py + 9.0f;
        if (t > 0.01f) dl.circle_filled(cx, cy, thumb_r + 2.0f, st.accent.alpha(static_cast<std::uint8_t>(42.0f * t)));
        dl.circle_filled(cx, cy, thumb_r, lerp(st.text_dim, st.accent, t));
        return changed;
    }

	bool button( std::string_view label, setting& s, std::string_view button_text )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return false;
		}

		binds::register_setting( &s );
		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto [display, full] = parse_label( label );
		if ( s.name.empty( ) ) s.name = std::string( display );
		const auto& st = c.style;
		const auto& input = c.input;

		auto& reg = binds::get_bind_registry( );
		const auto badge_id = id + 300;
		const auto badge_listening = ( reg.listening_setting == badge_id );

		if ( badge_listening )
		{
			for ( const auto vk : input.key_presses( ) )
			{
				if ( vk == VK_ESCAPE )
				{
					s.bind.key = 0;
					s.bind.active = false;
				}
				else
				{
					s.bind.key = vk;
				}
				reg.listening_setting = 0;
				break;
			}

			if ( badge_listening && input.rmb_clicked )
			{
				s.bind.key = VK_RBUTTON;
				reg.listening_setting = 0;
			}
		}

		const auto [avail_w, avail_h] = layout::avail( );
		constexpr auto row_h = 30.0f;
		const auto abs = layout::item( avail_w, row_h );

		const auto btn_text = button_text.empty( ) ? "kick" : button_text;
		const auto [btw, bth] = xdraw::measure_text( btn_text );
		const float btn_w = std::clamp( btw + 18.0f, 38.0f, 64.0f );
		const float btn_h = 20.0f;

		const auto px = abs.right( ) - btn_w;
		const auto py = abs.y + ( row_h - btn_h ) * 0.5f;
		const auto btn_rect = rect{ px, py, btn_w, btn_h };

		win->last_item_is_toggle = false;
		win->last_toggle_x = px;

		const auto ctx_id = id + 200;
		const auto ctx_is_open = overlays::is_open( ctx_id );
		if ( ctx_is_open )
		{
			overlays::touch( ctx_id );
		}

		const bool has_badge = ( s.bind.key != 0 || badge_listening );
		rect badge_rect{};
		bool badge_hovered = false;
		std::string badge_text{};

		const auto [label_w, label_h] = xdraw::measure_text( display );
		const auto label_y = abs.y + ( row_h - label_h ) * 0.5f;

		if ( has_badge )
		{
			badge_text = badge_listening ? "..." : vk_name( s.bind.key );
			const auto [kw, kh] = xdraw::measure_text( badge_text );
			constexpr float badge_pad_x = 5.0f;
			constexpr float badge_pad_y = 1.0f;
			const float badge_w = kw + badge_pad_x * 2.0f;
			const float badge_h = kh + badge_pad_y * 2.0f;
			float badge_x = abs.x + label_w + 8.0f;
			const float max_badge_x = px - 8.0f - badge_w;
			if ( badge_x > max_badge_x ) badge_x = max_badge_x;
			const float badge_y = label_y + ( label_h - badge_h ) * 0.5f;
			badge_rect = rect{ badge_x, badge_y, badge_w, badge_h };
			badge_hovered = !c.overlay_blocking( ) && input.in_rect( win->bounds ) && input.in_rect( badge_rect );

			if ( badge_hovered && input.mouse_clicked && !badge_listening && !c.overlay_blocking( ) )
			{
				reg.listening_setting = badge_id;
			}
			else if ( badge_listening && input.mouse_clicked && !badge_hovered )
			{
				reg.listening_setting = 0;
			}
		}

		const auto can_interact = ( !c.overlay_blocking( ) || ctx_is_open ) && input.in_rect( win->bounds );
		const auto btn_hovered = can_interact && input.in_rect( btn_rect );
		const auto row_hovered = can_interact && input.in_rect( abs ) && !badge_listening && !badge_hovered;
		const auto hovered = btn_hovered || row_hovered;
		const auto held = ( btn_hovered || row_hovered ) && input.mouse_down;
		const auto clicked = ( btn_hovered || row_hovered ) && input.mouse_clicked;

		if ( hovered )
		{
			set_hovered_tooltip( label );
		}

		// Right-click handling: open keybind context overlay
		if ( hovered && input.rmb_clicked && ( !c.overlay_blocking( ) || ctx_is_open ) )
		{
			if ( ctx_is_open )
			{
				overlays::close( ctx_id );
			}
			else if ( !c.overlay_blocking( ) )
			{
				const auto mouse_anchor = rect{ input.mouse_x, input.mouse_y, 0.0f, 0.0f };
				overlays::add( std::make_unique<checkbox_bind_overlay>( ctx_id, mouse_anchor, &s ) );
			}
		}

		const auto hover_anim = anim::lerp( id + 1, hovered ? 1.0f : 0.0f, 12.0f );
		const auto btn_hover_anim = anim::lerp( id + 2, btn_hovered ? 1.0f : 0.0f, 14.0f );
		const auto active_anim = anim::lerp( id + 3, held ? 1.0f : 0.0f, 16.0f );
		const auto click_flash = anim::lerp( id + 4, clicked ? 1.0f : 0.0f, 8.0f );

		auto& dl = draw::current( );

		// Draw row label text on left
		const auto reserved_right = btn_w + 10.0f + ( has_badge ? ( badge_rect.w + 10.0f ) : 0.0f );
		const auto label_col = lerp( st.text, lighten( st.text, 1.15f ), hover_anim );
		dl.text( abs.x, label_y, truncate( display, abs.w - reserved_right ), label_col );

		// Draw keybind badge if active/listening
		if ( has_badge && badge_rect.w > 0.0f )
		{
			const auto badge_hover_anim = anim::lerp( id + 51, ( badge_hovered || badge_listening ) ? 1.0f : 0.0f, 12.0f );
			auto badge_bg = st.keybind_bg;
			badge_bg.a = static_cast< std::uint8_t >( std::max( badge_bg.a, static_cast< std::uint8_t >( 40 ) ) );
			badge_bg = lighten( badge_bg, 1.0f + badge_hover_anim * 0.3f );

			auto badge_border = lerp( st.keybind_border, st.accent, badge_hover_anim * 0.8f );
			badge_border.a = static_cast< std::uint8_t >( std::max( badge_border.a, static_cast< std::uint8_t >( 30 ) ) );
			if ( badge_listening )
			{
				badge_border = lerp( badge_border, st.keybind_waiting, 0.6f );
			}

			const auto badge_r = st.keybind_rounding;
			dl.rect_filled( badge_rect.x, badge_rect.y, badge_rect.w, badge_rect.h, badge_bg, xdraw::corner_radius{ badge_r } );
			dl.rect( badge_rect.x, badge_rect.y, badge_rect.w, badge_rect.h, badge_border, xdraw::corner_radius{ badge_r } );

			auto key_col = lerp( st.text_dim, st.text, badge_hover_anim );
			if ( badge_listening ) key_col = st.keybind_waiting;
			dl.text( badge_rect.x + 5.0f, badge_rect.y + 1.0f, badge_text, key_col );
		}

		// Draw small button on right instead of toggle
		auto btn_bg = lerp( st.button_bg, st.button_hovered, std::max( btn_hover_anim, hover_anim * 0.6f ) );
		btn_bg = lerp( btn_bg, st.button_active, std::max( active_anim * 0.8f, click_flash ) );

		auto btn_border = lerp( st.button_border, st.accent.alpha( 170 ), std::max( btn_hover_anim, hover_anim * 0.5f ) );
		btn_border = lerp( btn_border, st.accent, std::max( active_anim, click_flash ) );

		const auto btn_r = xdraw::corner_radius{ st.button_rounding > 0.0f ? st.button_rounding : 4.0f };
		dl.rect_filled( px, py, btn_w, btn_h, btn_bg, btn_r );
		dl.rect( px, py, btn_w, btn_h, btn_border, btn_r, 1.0f );

		const auto tx = px + ( btn_w - btw ) * 0.5f;
		const auto ty = py + ( btn_h - bth ) * 0.5f;
		const auto btn_text_col = lerp( st.text_dim, st.text, std::max( btn_hover_anim, hover_anim ) );
		dl.text( tx, ty, btn_text, btn_text_col );

		bool triggered = clicked;
		if ( s.value )
		{
			s.value = false;
			triggered = true;
		}
		if ( s.bind.active )
		{
			s.bind.active = false;
			triggered = true;
		}

		return triggered;
	}


	namespace slider_binds {

		struct storage_t
		{
			std::unordered_map<std::uintptr_t, std::unique_ptr<slider_bind_entry>> by_id{};
			std::unordered_map<void*, slider_bind_entry*> by_ptr{};
			bool prev_key_state[ 256 ]{};
		};

		static storage_t& get_storage( )
		{
			static storage_t s{};
			return s;
		}

		slider_bind_entry* get_or_create( void* ptr, std::uintptr_t id, std::string_view label, float v_min, float v_max, bool is_integral, std::string_view fmt )
		{
			auto& store = get_storage( );

			if ( ptr )
			{
				auto it_p = store.by_ptr.find( ptr );
				if ( it_p != store.by_ptr.end( ) && it_p->second )
				{
					auto* e = it_p->second;
					e->id = id;
					if ( !label.empty( ) ) e->label = label;
					e->v_min = v_min;
					e->v_max = v_max;
					e->is_integral = is_integral;
					e->fmt = fmt;
					if ( !e->has_base_value )
					{
						e->base_value = is_integral ? static_cast< float >( *static_cast< int* >( ptr ) ) : *static_cast< float* >( ptr );
					}
					return e;
				}
			}

			auto it_id = store.by_id.find( id );
			if ( it_id != store.by_id.end( ) && it_id->second )
			{
				auto* e = it_id->second.get( );
				if ( ptr )
				{
					e->ptr = ptr;
					store.by_ptr[ ptr ] = e;
					if ( !e->has_base_value )
					{
						e->base_value = is_integral ? static_cast< float >( *static_cast< int* >( ptr ) ) : *static_cast< float* >( ptr );
					}
				}
				if ( !label.empty( ) ) e->label = label;
				e->v_min = v_min;
				e->v_max = v_max;
				e->is_integral = is_integral;
				e->fmt = fmt;
				return e;
			}

			auto new_entry = std::make_unique<slider_bind_entry>( );
			auto* p = new_entry.get( );
			p->ptr = ptr;
			p->id = id;
			p->label = label;
			p->fmt = fmt;
			p->v_min = v_min;
			p->v_max = v_max;
			p->is_integral = is_integral;
			p->count = 0;
			p->has_base_value = false;
			if ( ptr )
			{
				p->base_value = is_integral ? static_cast< float >( *static_cast< int* >( ptr ) ) : *static_cast< float* >( ptr );
				store.by_ptr[ ptr ] = p;
			}
			else
			{
				p->base_value = v_min;
			}

			store.by_id[ id ] = std::move( new_entry );
			return p;
		}

		slider_bind_entry* find_by_ptr( void* ptr )
		{
			if ( !ptr ) return nullptr;
			auto& store = get_storage( );
			auto it = store.by_ptr.find( ptr );
			return it != store.by_ptr.end( ) ? it->second : nullptr;
		}

		slider_bind_entry* find_by_id( std::uintptr_t id )
		{
			auto& store = get_storage( );
			auto it = store.by_id.find( id );
			return it != store.by_id.end( ) ? it->second.get( ) : nullptr;
		}

		std::vector<slider_bind_entry*> all( )
		{
			auto& store = get_storage( );
			std::vector<slider_bind_entry*> res;
			res.reserve( store.by_id.size( ) );
			for ( auto& [id, ptr] : store.by_id )
			{
				if ( ptr ) res.push_back( ptr.get( ) );
			}
			return res;
		}

		void process( const input_state& input )
		{
			auto& store = get_storage( );
			for ( auto& [id, entry_ptr] : store.by_id )
			{
				auto* entry = entry_ptr.get( );
				if ( !entry || !entry->ptr || entry->count == 0 )
				{
					continue;
				}

				for ( std::size_t i = 0; i < entry->count; ++i )
				{
					auto& b = entry->binds[ i ];
					if ( b.key == 0 )
					{
						b.active = false;
						continue;
					}

					const auto vk = b.key;
					const auto held = input.key_down( vk );
					const auto was_held = store.prev_key_state[ vk ];
					const auto just_pressed = held && !was_held;

					switch ( b.mode )
					{
					case bind_mode::toggle:
						if ( just_pressed )
						{
							b.active = !b.active;
						}
						break;
					case bind_mode::hold_on:
						b.active = held;
						break;
					case bind_mode::hold_off:
						b.active = !held;
						break;
					}
				}

				int active_idx = -1;
				for ( int i = static_cast< int >( entry->count ) - 1; i >= 0; --i )
				{
					if ( entry->binds[ i ].key != 0 && entry->binds[ i ].active )
					{
						active_idx = i;
						break;
					}
				}

				if ( active_idx != -1 )
				{
					if ( !entry->has_base_value )
					{
						entry->base_value = entry->is_integral
							? static_cast< float >( *static_cast< int* >( entry->ptr ) )
							: *static_cast< float* >( entry->ptr );
						entry->has_base_value = true;
					}

					const auto target_val = entry->binds[ active_idx ].value;
					if ( entry->is_integral )
					{
						*static_cast< int* >( entry->ptr ) = static_cast< int >( std::roundf( target_val ) );
					}
					else
					{
						*static_cast< float* >( entry->ptr ) = target_val;
					}
				}
				else if ( entry->has_base_value )
				{
					if ( entry->is_integral )
					{
						*static_cast< int* >( entry->ptr ) = static_cast< int >( std::roundf( entry->base_value ) );
					}
					else
					{
						*static_cast< float* >( entry->ptr ) = entry->base_value;
					}
					entry->has_base_value = false;
				}
			}

			for ( int k = 0; k < 256; ++k )
			{
				store.prev_key_state[ k ] = input.key_down( k );
			}
		}

		std::string serialize( )
		{
			auto& store = get_storage( );
			auto arr = nlohmann::json::array( );
			for ( auto& [id, entry_ptr] : store.by_id )
			{
				auto* entry = entry_ptr.get( );
				if ( !entry || entry->count == 0 ) continue;

				nlohmann::json item;
				item[ "id" ] = entry->id;
				item[ "lbl" ] = entry->label;
				auto b_arr = nlohmann::json::array( );
				for ( std::size_t i = 0; i < entry->count; ++i )
				{
					const auto& b = entry->binds[ i ];
					if ( b.key != 0 )
					{
						b_arr.push_back( {
							{ "k", b.key },
							{ "m", static_cast< int >( b.mode ) },
							{ "v", b.value }
						} );
					}
				}
				if ( !b_arr.empty( ) )
				{
					item[ "b" ] = std::move( b_arr );
					arr.push_back( std::move( item ) );
				}
			}
			return arr.empty( ) ? std::string{} : arr.dump( );
		}

		void deserialize( std::string_view s )
		{
			if ( s.empty( ) ) return;
			try
			{
				auto j = nlohmann::json::parse( s );
				if ( !j.is_array( ) ) return;
				for ( const auto& item : j )
				{
					if ( !item.is_object( ) || !item.contains( "id" ) || !item.contains( "b" ) ) continue;
					const auto id = item[ "id" ].get< std::uintptr_t >( );
					const auto label = item.value( "lbl", "" );
					auto* entry = find_by_id( id );
					if ( !entry )
					{
						entry = get_or_create( nullptr, id, label, 0.0f, 100.0f, true, "%d" );
					}
					if ( !entry ) continue;

					entry->count = 0;
					const auto& b_arr = item[ "b" ];
					if ( b_arr.is_array( ) )
					{
						for ( const auto& b_item : b_arr )
						{
							if ( entry->count >= slider_bind_entry::k_max_binds ) break;
							auto& b = entry->binds[ entry->count++ ];
							b.key = b_item.value( "k", 0 );
							b.mode = static_cast< bind_mode >( b_item.value( "m", 1 ) );
							b.value = b_item.value( "v", 0.0f );
							b.active = false;
						}
					}
				}
			}
			catch ( ... ) {}
		}

		void reset( )
		{
			auto& store = get_storage( );
			for ( auto& [id, entry_ptr] : store.by_id )
			{
				auto* entry = entry_ptr.get( );
				if ( !entry ) continue;
				if ( entry->has_base_value && entry->ptr )
				{
					if ( entry->is_integral )
						*static_cast< int* >( entry->ptr ) = static_cast< int >( std::roundf( entry->base_value ) );
					else
						*static_cast< float* >( entry->ptr ) = entry->base_value;
					entry->has_base_value = false;
				}
				entry->count = 0;
			}
		}

	} // namespace slider_binds

	namespace {

		class slider_bind_overlay : public overlay
		{
		public:
			slider_bind_overlay( std::uintptr_t id, const rect& anchor, slider_bind_entry* entry )
				: overlay{ id, anchor }, m_entry{ entry }
			{
			}

			[[nodiscard]] bool hit_test( float x, float y ) const override
			{
				return this->get_popup( ).contains( x, y );
			}

			bool process_input( const input_state& input ) override
			{
				if ( this->m_closing || !this->m_entry )
				{
					return false;
				}

				const auto popup = this->get_popup( );

				if ( this->m_listening_bind != -1 && this->m_listening_bind < static_cast< int >( this->m_entry->count ) )
				{
					auto& b = this->m_entry->binds[ this->m_listening_bind ];
					for ( const auto vk : input.key_presses( ) )
					{
						if ( vk == VK_ESCAPE )
						{
							b.key = 0;
							b.active = false;
						}
						else
						{
							b.key = vk;
						}
						this->m_listening_bind = -1;
						return true;
					}

					if ( input.rmb_clicked )
					{
						b.key = VK_RBUTTON;
						this->m_listening_bind = -1;
						return true;
					}

					if ( input.mouse_clicked && !popup.contains( input.mouse_x, input.mouse_y ) )
					{
						this->m_listening_bind = -1;
						return true;
					}

					return true;
				}

				if ( this->m_dragging_bind != -1 && this->m_dragging_bind < static_cast< int >( this->m_entry->count ) )
				{
					if ( !input.mouse_down )
					{
						this->m_dragging_bind = -1;
					}
					else
					{
						auto& b = this->m_entry->binds[ this->m_dragging_bind ];
						const auto card_x = popup.x + 6.0f;
						const auto card_w = popup.w - 12.0f;
						const auto track_x = card_x + 32.0f;
						const auto track_w = card_w - 82.0f;
						const auto norm = std::clamp( ( input.mouse_x - track_x ) / track_w, 0.0f, 1.0f );
						const auto new_val = this->m_entry->v_min + norm * ( this->m_entry->v_max - this->m_entry->v_min );
						b.value = this->m_entry->is_integral ? std::roundf( new_val ) : new_val;
						return true;
					}
				}

				if ( ( input.mouse_clicked || input.rmb_clicked ) && !popup.contains( input.mouse_x, input.mouse_y ) )
				{
					this->m_closing = true;
					return true;
				}

				if ( input.mouse_clicked && popup.contains( input.mouse_x, input.mouse_y ) )
				{
					const auto card_x = popup.x + 6.0f;
					const auto card_w = popup.w - 12.0f;

					for ( std::size_t i = 0; i < this->m_entry->count; ++i )
					{
						const auto card_y = popup.y + 28.0f + static_cast< float >( i ) * 50.0f;
						const auto key_btn = rect{ card_x + 4.0f, card_y + 4.0f, 68.0f, 18.0f };
						const auto mode_btn = rect{ card_x + 76.0f, card_y + 4.0f, 62.0f, 18.0f };
						const auto del_btn = rect{ card_x + card_w - 52.0f, card_y + 4.0f, 48.0f, 18.0f };
						const auto track_rect = rect{ card_x + 32.0f, card_y + 24.0f, card_w - 82.0f, 18.0f };

						if ( key_btn.contains( input.mouse_x, input.mouse_y ) )
						{
							this->m_listening_bind = static_cast< int >( i );
							return true;
						}

						if ( mode_btn.contains( input.mouse_x, input.mouse_y ) )
						{
							auto& b = this->m_entry->binds[ i ];
							auto m = static_cast< int >( b.mode );
							m = ( m + 1 ) % 3;
							b.mode = static_cast< bind_mode >( m );
							return true;
						}

						if ( del_btn.contains( input.mouse_x, input.mouse_y ) )
						{
							for ( std::size_t j = i; j + 1 < this->m_entry->count; ++j )
							{
								this->m_entry->binds[ j ] = this->m_entry->binds[ j + 1 ];
							}
							this->m_entry->binds[ this->m_entry->count - 1 ] = slider_bind{};
							this->m_entry->count--;
							return true;
						}

						if ( track_rect.contains( input.mouse_x, input.mouse_y ) )
						{
							this->m_dragging_bind = static_cast< int >( i );
							auto& b = this->m_entry->binds[ i ];
							const auto track_x = card_x + 32.0f;
							const auto track_w = card_w - 82.0f;
							const auto norm = std::clamp( ( input.mouse_x - track_x ) / track_w, 0.0f, 1.0f );
							const auto new_val = this->m_entry->v_min + norm * ( this->m_entry->v_max - this->m_entry->v_min );
							b.value = this->m_entry->is_integral ? std::roundf( new_val ) : new_val;
							return true;
						}
					}

					if ( this->m_entry->count < slider_bind_entry::k_max_binds )
					{
						const auto add_btn = rect{ card_x, popup.y + 28.0f + static_cast< float >( this->m_entry->count ) * 50.0f, card_w, 22.0f };
						if ( add_btn.contains( input.mouse_x, input.mouse_y ) )
						{
							auto& nb = this->m_entry->binds[ this->m_entry->count ];
							nb.key = 0;
							nb.mode = bind_mode::hold_on;
							nb.value = this->m_entry->base_value;
							nb.active = false;
							this->m_entry->count++;
							return true;
						}
					}
				}

				return false;
			}

			void render( const style& style, const input_state& input ) override
			{
				if ( !this->m_entry )
				{
					return;
				}

				const auto dt = xdraw::delta_time( );
				const auto speed = this->m_closing ? 16.0f : 14.0f;
				const auto target = this->m_closing ? 0.0f : 1.0f;

				this->m_open_anim += ( target - this->m_open_anim ) * std::min( speed * dt, 1.0f );
				if ( this->m_open_anim < 0.01f && this->m_closing )
				{
					this->m_closed = true;
					return;
				}

				const auto alpha_mult = this->m_open_anim;
				const auto popup = this->get_popup( );
				auto& dl = xdraw::get( xdraw::layer::top );

				dl.push_clip( popup.x - 4.0f, popup.y - 4.0f, popup.w + 8.0f, popup.h + 8.0f );

				auto bg = style.popup_bg;
				bg.a = static_cast< std::uint8_t >( 245.0f * alpha_mult );
				auto border = style.popup_border;
				border.a = static_cast< std::uint8_t >( 180.0f * alpha_mult );

				dl.rect_filled( popup.x, popup.y, popup.w, popup.h, bg, xdraw::corner_radius{ 6.0f } );
				dl.rect( popup.x, popup.y, popup.w, popup.h, border, xdraw::corner_radius{ 6.0f } );

				// Header
				auto title_col = style.text;
				title_col.a = static_cast< std::uint8_t >( title_col.a * alpha_mult );
				dl.text( popup.x + 8.0f, popup.y + 6.0f, truncate( this->m_entry->label, popup.w - 80.0f ), title_col );

				const auto binds_sub = "(max 5)";
				const auto [sw, sh] = xdraw::measure_text( binds_sub );
				auto sub_col = style.text_dim;
				sub_col.a = static_cast< std::uint8_t >( sub_col.a * alpha_mult );
				dl.text( popup.right( ) - sw - 8.0f, popup.y + 7.0f, binds_sub, sub_col );

				// Header separator line
				auto sep_col = style.popup_border;
				sep_col.a = static_cast< std::uint8_t >( sep_col.a * alpha_mult );
				dl.line( popup.x + 6.0f, popup.y + 24.0f, popup.right( ) - 6.0f, popup.y + 24.0f, sep_col, 1.0f );

				const auto card_x = popup.x + 6.0f;
				const auto card_w = popup.w - 12.0f;

				for ( std::size_t i = 0; i < this->m_entry->count; ++i )
				{
					const auto& b = this->m_entry->binds[ i ];
					const auto card_y = popup.y + 28.0f + static_cast< float >( i ) * 50.0f;
					const auto card_rect = rect{ card_x, card_y, card_w, 46.0f };

					auto card_bg = style.button_bg;
					card_bg.a = static_cast< std::uint8_t >( 120.0f * alpha_mult );
					auto card_border = b.active ? style.accent : style.button_border;
					card_border.a = static_cast< std::uint8_t >( ( b.active ? 220.0f : 100.0f ) * alpha_mult );

					dl.rect_filled( card_rect.x, card_rect.y, card_rect.w, card_rect.h, card_bg, xdraw::corner_radius{ 4.0f } );
					dl.rect( card_rect.x, card_rect.y, card_rect.w, card_rect.h, card_border, xdraw::corner_radius{ 4.0f } );

					// Line 1: Key button, Mode button, Active dot, Delete button
					const auto key_btn = rect{ card_x + 4.0f, card_y + 4.0f, 68.0f, 18.0f };
					const auto mode_btn = rect{ card_x + 76.0f, card_y + 4.0f, 62.0f, 18.0f };
					const auto del_btn = rect{ card_x + card_w - 52.0f, card_y + 4.0f, 48.0f, 18.0f };

					// Key button
					const auto key_hovered = key_btn.contains( input.mouse_x, input.mouse_y );
					auto key_bg = key_hovered ? style.button_hovered : style.button_bg;
					key_bg.a = static_cast< std::uint8_t >( key_bg.a * alpha_mult );
					dl.rect_filled( key_btn.x, key_btn.y, key_btn.w, key_btn.h, key_bg, xdraw::corner_radius{ 3.0f } );
					dl.rect( key_btn.x, key_btn.y, key_btn.w, key_btn.h, card_border, xdraw::corner_radius{ 3.0f } );

					const auto is_listening = ( this->m_listening_bind == static_cast< int >( i ) );
					if ( is_listening )
					{
						this->m_listen_pulse += dt * 3.0f;
						if ( this->m_listen_pulse > 6.28318f ) this->m_listen_pulse -= 6.28318f;
						const auto pulse = std::sin( this->m_listen_pulse ) * 0.5f + 0.5f;
						auto pcol = style.keybind_waiting;
						pcol.a = static_cast< std::uint8_t >( 60.0f * alpha_mult * ( 0.5f + pulse * 0.5f ) );
						dl.rect_filled( key_btn.x, key_btn.y, key_btn.w, key_btn.h, pcol, xdraw::corner_radius{ 3.0f } );
					}

					const auto key_str = is_listening ? "..." : ( b.key != 0 ? vk_name( b.key ) : "none" );
					const auto [kw, kh] = xdraw::measure_text( key_str );
					auto key_text_col = is_listening ? style.keybind_waiting : ( b.key != 0 ? style.text : style.text_dim );
					key_text_col.a = static_cast< std::uint8_t >( key_text_col.a * alpha_mult );
					dl.text( key_btn.x + ( key_btn.w - kw ) * 0.5f, key_btn.y + ( key_btn.h - kh ) * 0.5f, key_str, key_text_col );

					// Mode button
					const auto mode_hovered = mode_btn.contains( input.mouse_x, input.mouse_y );
					auto mode_bg = mode_hovered ? style.button_hovered : style.button_bg;
					mode_bg.a = static_cast< std::uint8_t >( mode_bg.a * alpha_mult );
					dl.rect_filled( mode_btn.x, mode_btn.y, mode_btn.w, mode_btn.h, mode_bg, xdraw::corner_radius{ 3.0f } );
					dl.rect( mode_btn.x, mode_btn.y, mode_btn.w, mode_btn.h, card_border, xdraw::corner_radius{ 3.0f } );

					const auto mode_str = binds::mode_name( b.mode );
					const auto [mw, mh] = xdraw::measure_text( mode_str );
					auto mode_text_col = style.text_dim;
					mode_text_col.a = static_cast< std::uint8_t >( mode_text_col.a * alpha_mult );
					dl.text( mode_btn.x + ( mode_btn.w - mw ) * 0.5f, mode_btn.y + ( mode_btn.h - mh ) * 0.5f, mode_str, mode_text_col );

					// Active indicator dot
					if ( b.active )
					{
						auto dot_col = style.accent;
						dot_col.a = static_cast< std::uint8_t >( 255.0f * alpha_mult );
						dl.circle_filled( card_x + 148.0f, card_y + 13.0f, 3.5f, dot_col, 8 );
					}

					// Delete button
					const auto del_hovered = del_btn.contains( input.mouse_x, input.mouse_y );
					auto del_bg = del_hovered ? xdraw::color{ 140, 32, 32, static_cast< std::uint8_t >( 120.0f * alpha_mult ) }
					                          : style.button_bg;
					del_bg.a = static_cast< std::uint8_t >( del_bg.a * alpha_mult );

					auto del_border = del_hovered ? xdraw::color{ 230, 60, 60, static_cast< std::uint8_t >( 200.0f * alpha_mult ) }
					                              : style.button_border;
					del_border.a = static_cast< std::uint8_t >( del_border.a * alpha_mult );

					auto del_col = del_hovered ? xdraw::color{ 255, 90, 90, static_cast< std::uint8_t >( 255.0f * alpha_mult ) }
					                           : xdraw::color{ 200, 130, 130, static_cast< std::uint8_t >( 170.0f * alpha_mult ) };

					dl.rect_filled( del_btn.x, del_btn.y, del_btn.w, del_btn.h, del_bg, xdraw::corner_radius{ 3.0f } );
					dl.rect( del_btn.x, del_btn.y, del_btn.w, del_btn.h, del_border, xdraw::corner_radius{ 3.0f } );

					const auto [dw, dh] = xdraw::measure_text( "delete" );
					dl.text( del_btn.x + ( del_btn.w - dw ) * 0.5f, del_btn.y + ( del_btn.h - dh ) * 0.5f, "delete", del_col );

					// Line 2: Mini slider
					const auto track_rect = rect{ card_x + 32.0f, card_y + 26.0f, card_w - 82.0f, 14.0f };
					auto val_label_col = style.text_dim;
					val_label_col.a = static_cast< std::uint8_t >( val_label_col.a * alpha_mult );
					const auto [vlw, vlh] = xdraw::measure_text( "val" );
					dl.text( card_x + 6.0f, card_y + 26.0f + ( track_rect.h - vlh ) * 0.5f, "val", val_label_col );

					const auto range = std::max( 0.001f, this->m_entry->v_max - this->m_entry->v_min );
					const auto norm = std::clamp( ( b.value - this->m_entry->v_min ) / range, 0.0f, 1.0f );
					const auto track_y = track_rect.y + 5.0f;
					const auto track_h = 4.0f;

					auto track_bg = style.slider_track;
					track_bg.a = static_cast< std::uint8_t >( track_bg.a * alpha_mult );
					dl.rect_filled( track_rect.x, track_y, track_rect.w, track_h, track_bg, xdraw::corner_radius{ 2.0f } );

					if ( norm > 0.0f )
					{
						auto prog_col = style.slider_fill;
						prog_col.a = static_cast< std::uint8_t >( prog_col.a * alpha_mult );
						dl.rect_filled( track_rect.x, track_y, track_rect.w * norm, track_h, prog_col, xdraw::corner_radius{ 2.0f } );
					}

					const auto thumb_x = track_rect.x + norm * track_rect.w;
					auto thumb_col = ( this->m_dragging_bind == static_cast< int >( i ) ) ? style.accent : style.slider_fill;
					thumb_col.a = static_cast< std::uint8_t >( thumb_col.a * alpha_mult );
					dl.circle_filled( thumb_x, track_y + track_h * 0.5f, 5.0f, thumb_col, 10 );

					// Value text
					char v_buf[ 32 ];
					if ( this->m_entry->is_integral )
					{
						std::snprintf( v_buf, sizeof( v_buf ), "%d", static_cast< int >( std::roundf( b.value ) ) );
					}
					else
					{
						std::snprintf( v_buf, sizeof( v_buf ), "%.1f", b.value );
					}
					const auto [vw, vh] = xdraw::measure_text( v_buf );
					auto v_col = style.text;
					v_col.a = static_cast< std::uint8_t >( v_col.a * alpha_mult );
					dl.text( card_x + card_w - vw - 4.0f, card_y + 26.0f + ( track_rect.h - vh ) * 0.5f, v_buf, v_col );
				}

				// Add button
				if ( this->m_entry->count < slider_bind_entry::k_max_binds )
				{
					const auto add_btn = rect{ card_x, popup.y + 28.0f + static_cast< float >( this->m_entry->count ) * 50.0f, card_w, 22.0f };
					const auto add_hovered = add_btn.contains( input.mouse_x, input.mouse_y );
					auto add_bg = add_hovered ? style.button_hovered : style.button_bg;
					add_bg.a = static_cast< std::uint8_t >( add_bg.a * alpha_mult );
					dl.rect_filled( add_btn.x, add_btn.y, add_btn.w, add_btn.h, add_bg, xdraw::corner_radius{ 4.0f } );
					dl.rect( add_btn.x, add_btn.y, add_btn.w, add_btn.h, style.button_border, xdraw::corner_radius{ 4.0f } );

					std::string add_str = "+ add bind (" + std::to_string( this->m_entry->count ) + "/5)";
					const auto [aw, ah] = xdraw::measure_text( add_str );
					auto add_col = add_hovered ? style.accent : style.text_dim;
					add_col.a = static_cast< std::uint8_t >( add_col.a * alpha_mult );
					dl.text( add_btn.x + ( add_btn.w - aw ) * 0.5f, add_btn.y + ( add_btn.h - ah ) * 0.5f, add_str, add_col );
				}

				dl.pop_clip( );
			}

		private:
			static constexpr auto k_popup_w{ 252.0f };

			[[nodiscard]] rect get_popup( ) const
			{
				const auto count = this->m_entry ? this->m_entry->count : 0;
				const auto h = 32.0f + static_cast< float >( count ) * 50.0f + ( count < slider_bind_entry::k_max_binds ? 30.0f : 8.0f );
				const auto [sw, sh] = xdraw::viewport_size( );
				float px = this->m_anchor.x;
				float py = this->m_anchor.y;
				if ( px + k_popup_w > sw - 10.0f ) px = sw - 10.0f - k_popup_w;
				if ( py + h > sh - 10.0f ) py = sh - 10.0f - h;
				if ( px < 10.0f ) px = 10.0f;
				if ( py < 10.0f ) py = 10.0f;
				return rect{ px, py, k_popup_w, h };
			}

			slider_bind_entry* m_entry{ nullptr };
			float m_open_anim{ 0.0f };
			int m_listening_bind{ -1 };
			int m_dragging_bind{ -1 };
			float m_listen_pulse{ 0.0f };
		};

		template<typename T>
		inline bool slider( std::uintptr_t id, std::string_view label, T& v, T v_min, T v_max, std::string_view fmt )
		{
			auto win = layout::current_window( );
			if ( !win )
			{
				return false;
			}

			auto& c = get_ctx( );
			const auto [display, full] = parse_label( label );
			const auto& s = c.style;
			const auto& input = c.input;
			auto changed{ false };

			const auto [avail_w, avail_h] = layout::avail( );
			const auto slider_width = avail_w;

			char value_buf[ 64 ]{};
			if constexpr ( std::is_floating_point_v<T> )
			{
				std::snprintf( value_buf, sizeof( value_buf ), fmt.data( ), v );
			}
			else
			{
				std::snprintf( value_buf, sizeof( value_buf ), fmt.data( ), static_cast< int >( v ) );
			}

			const auto [label_w, label_h] = xdraw::measure_text( display );
			const auto [value_w, value_h] = xdraw::measure_text( value_buf );

			const auto text_height = std::max( label_h, value_h );
			const auto track_height = s.slider_h;
			constexpr auto thumb_r{ 6.0f };
			const auto thumb_d = thumb_r * 2.0f;
			const auto slider_area_h = std::max( track_height, thumb_d );
			const auto spacing = 10.0f;
			const auto total_height = text_height + spacing + slider_area_h;

			const auto abs = layout::item( slider_width, total_height, text_height );
			const auto track_y = abs.y + text_height + spacing + ( slider_area_h - track_height ) * 0.5f;
			const auto track_rect = rect{ abs.x, track_y, slider_width, track_height };
			const auto slider_hit_rect = rect{ abs.x, abs.y + text_height + spacing, slider_width, slider_area_h };

			const auto can_interact = !c.overlay_blocking( );

			const auto is_editing = c.active_slider_edit == id;
			const auto value_text_x = abs.x + slider_width - value_w - 12.0f;
			const auto value_text_rect = rect{ value_text_x, abs.y - 2.0f, value_w + 12.0f, text_height + 4.0f };

			if ( is_editing )
			{
				auto& buf = c.slider_edit_buf;
				auto& cursor = c.slider_edit_cursor;

				const auto [edit_w, edit_h] = xdraw::measure_text( buf.empty( ) ? "0" : buf );
				const auto edit_box_w = std::max( value_w + 16.0f, edit_w + 12.0f );
				const auto edit_box_x = std::floorf( abs.x + slider_width - edit_box_w );
				const auto edit_box_rect = rect{ edit_box_x, abs.y, edit_box_w, text_height };

				if ( input.mouse_clicked && !input.in_rect( edit_box_rect ) )
				{
					if ( !buf.empty( ) )
					{
						try
						{
							if constexpr ( std::is_floating_point_v<T> )
							{
								v = std::clamp( static_cast< T >( std::stod( buf ) ), v_min, v_max );
							}
							else
							{
								v = std::clamp( static_cast< T >( std::stoi( buf ) ), v_min, v_max );
							}

							changed = true;
						}
						catch ( ... ) {}
					}

					c.active_slider_edit = null_id;
				}
				else
				{
					for ( const auto vk : input.key_presses( ) )
					{
						if ( vk == VK_RETURN )
						{
							if ( !buf.empty( ) )
							{
								try
								{
									if constexpr ( std::is_floating_point_v<T> )
									{
										v = std::clamp( static_cast< T >( std::stod( buf ) ), v_min, v_max );
									}
									else
									{
										v = std::clamp( static_cast< T >( std::stoi( buf ) ), v_min, v_max );
									}

									changed = true;
								}
								catch ( ... ) {}
							}

							c.active_slider_edit = null_id;
							break;
						}
						else if ( vk == VK_ESCAPE )
						{
							c.active_slider_edit = null_id;
							break;
						}
						else if ( vk == VK_BACK && cursor > 0 )
						{
							buf.erase( cursor - 1, 1 );
							cursor--;
						}
						else if ( vk == VK_DELETE && cursor < buf.size( ) )
						{
							buf.erase( cursor, 1 );
						}
						else if ( vk == VK_LEFT && cursor > 0 )
						{
							cursor--;
						}
						else if ( vk == VK_RIGHT && cursor < buf.size( ) )
						{
							cursor++;
						}
						else if ( vk == VK_HOME )
						{
							cursor = 0;
						}
						else if ( vk == VK_END )
						{
							cursor = buf.size( );
						}
					}

					if ( c.active_slider_edit == id )
					{
						for ( const auto ch : input.chars( ) )
						{
							if ( ( ch >= '0' && ch <= '9' ) || ch == '.' || ch == '-' )
							{
								buf.insert( buf.begin( ) + static_cast< std::ptrdiff_t >( cursor ), static_cast< char >( ch ) );
								cursor++;
							}
						}
					}
				}

				if ( c.active_slider_edit == id )
				{
					const auto dt = xdraw::delta_time( );
					const auto edit_anim = anim::lerp( id + 2000000, 1.0f, 12.0f );
					const auto tr = s.checkbox_rounding;

					auto border_col = lerp( s.text_input_border, s.accent, edit_anim );
					auto bg_col = lerp( s.text_input_bg, lighten( s.text_input_bg, 1.08f ), edit_anim );

					auto& dl = draw::current( );
					dl.rect_filled( edit_box_rect.x, edit_box_rect.y, edit_box_rect.w, edit_box_rect.h, bg_col, xdraw::corner_radius{ tr } );
					dl.rect( edit_box_rect.x, edit_box_rect.y, edit_box_rect.w, edit_box_rect.h, border_col, xdraw::corner_radius{ tr } );

					const auto text_pad{ 4.0f };
					const auto [buf_w, buf_h] = xdraw::measure_text( buf.empty( ) ? "0" : buf );
					const auto buf_y = std::floorf( edit_box_rect.y + ( edit_box_rect.h - buf_h ) * 0.5f );

					if ( !buf.empty( ) )
					{
						dl.text( edit_box_rect.x + text_pad, buf_y, buf, s.text );
					}

					const auto cursor_text = buf.substr( 0, cursor );
					const auto [cw, ch] = xdraw::measure_text( cursor_text.empty( ) ? "" : cursor_text );
					const auto cursor_x = std::floorf( edit_box_rect.x + text_pad + cw );
					const auto cursor_h = std::floorf( ( buf_h > 0.0f ? buf_h : text_height ) * 0.7f );
					const auto cursor_y = std::floorf( edit_box_rect.y + ( edit_box_rect.h - cursor_h ) * 0.5f );

					c.slider_edit_blink += dt;

					if ( c.slider_edit_blink > 1.0f )
					{
						c.slider_edit_blink -= 1.0f;
					}

					const auto blink_a = std::sin( c.slider_edit_blink * 6.28318f ) * 0.5f + 0.5f;
					auto cursor_col = s.text;
					cursor_col.a = static_cast< std::uint8_t >( 255.0f * ( 0.4f + 0.6f * blink_a ) );
					dl.rect_filled( cursor_x, cursor_y, 1.0f, cursor_h, cursor_col );
				}
			}
			else
			{
				const auto hovered = can_interact && input.in_rect( slider_hit_rect );
				const auto value_hovered = can_interact && input.in_rect( value_text_rect );

				if ( hovered || value_hovered || ( can_interact && input.in_rect( abs ) ) )
				{
					set_hovered_tooltip( label );
				}

				auto bind_entry = slider_binds::get_or_create( &v, id, display, static_cast< float >( v_min ), static_cast< float >( v_max ), std::is_integral_v<T>, fmt );

				const auto ctx_id = id + 500000;
				const auto ctx_is_open = overlays::is_open( ctx_id );
				if ( ctx_is_open )
				{
					overlays::touch( ctx_id );
				}

				// Right-click handling: open slider binds context overlay
				if ( ( hovered || value_hovered || ( can_interact && input.in_rect( abs ) ) ) && input.rmb_clicked && ( !c.overlay_blocking( ) || ctx_is_open ) )
				{
					if ( ctx_is_open )
					{
						overlays::close( ctx_id );
					}
					else if ( !c.overlay_blocking( ) )
					{
						const auto mouse_anchor = rect{ input.mouse_x, input.mouse_y, 0.0f, 0.0f };
						overlays::add( std::make_unique<slider_bind_overlay>( ctx_id, mouse_anchor, bind_entry ) );
					}
				}

				if ( value_hovered && ( input.mouse_clicked || input.mouse_double_clicked ) && c.active_slider == null_id )
				{
					c.active_slider_edit = id;
					c.slider_edit_buf = value_buf;
					c.slider_edit_cursor = c.slider_edit_buf.size( );
					c.slider_edit_blink = 0.0f;
				}
				else if ( hovered && input.mouse_clicked && c.active_slider == null_id )
				{
					c.active_slider = id;
				}

				if ( c.active_slider == id && input.mouse_down && can_interact )
				{
					const auto norm = std::clamp( ( input.mouse_x - track_rect.x ) / track_rect.w, 0.0f, 1.0f );

					if constexpr ( std::is_integral_v<T> )
					{
						v = static_cast< T >( v_min + norm * ( v_max - v_min ) );
					}
					else
					{
						v = v_min + norm * ( v_max - v_min );
					}

					changed = true;
				}

				if ( ( hovered || value_hovered || input.in_rect( abs ) ) && input.scroll_delta != 0.0f && can_interact && c.active_slider_edit == null_id )
				{
					if constexpr ( std::is_integral_v<T> )
					{
						T step = static_cast< T >( 1 );
						if ( input.key_down( VK_SHIFT ) )
						{
							step = std::max( static_cast< T >( 5 ), static_cast< T >( ( v_max - v_min ) * 0.05f ) );
						}
						const auto delta = static_cast< int >( input.scroll_delta > 0.0f ? std::ceil( input.scroll_delta * step ) : std::floor( input.scroll_delta * step ) );
						v = std::clamp( static_cast< T >( v + delta ), v_min, v_max );
					}
					else
					{
						float step = 0.01f;
						const auto dot = fmt.find( '.' );
						if ( dot != std::string_view::npos && dot + 1 < fmt.size( ) && std::isdigit( fmt[ dot + 1 ] ) )
						{
							const int decimals = fmt[ dot + 1 ] - '0';
							if ( decimals == 0 )
							{
								const float r = static_cast< float >( v_max - v_min );
								if ( r > 500.0f ) step = 10.0f;
								else if ( r > 100.0f ) step = 5.0f;
								else step = 1.0f;
							}
							else if ( decimals == 1 ) step = 0.1f;
							else if ( decimals == 2 ) step = 0.01f;
							else if ( decimals == 3 ) step = 0.001f;
							else step = 0.0001f;
						}
						else
						{
							step = std::max( 0.01f, static_cast< float >( v_max - v_min ) * 0.01f );
						}

						if ( input.key_down( VK_SHIFT ) )
						{
							step *= 5.0f;
						}
						else if ( input.key_down( VK_CONTROL ) )
						{
							step *= 0.1f;
						}

						v = std::clamp( static_cast< T >( v + static_cast< T >( input.scroll_delta * step ) ), v_min, v_max );
					}

					changed = true;
					c.input.scroll_delta = 0.0f;
				}

				if ( hovered && can_interact )
				{
					for ( const auto vk : input.key_presses( ) )
					{
						if ( vk == VK_LEFT )
						{
							if constexpr ( std::is_integral_v<T> )
							{
								v = std::max( v_min, v - 1 );
							}
							else
							{
								v = std::max( v_min, v - ( v_max - v_min ) * 0.01f );
							}

							changed = true;
						}
						else if ( vk == VK_RIGHT )
						{
							if constexpr ( std::is_integral_v<T> )
							{
								v = std::min( v_max, v + 1 );
							}
							else
							{
								v = std::min( v_max, v + ( v_max - v_min ) * 0.01f );
							}

							changed = true;
						}
					}
				}

				if ( changed && bind_entry && !bind_entry->has_base_value )
				{
					bind_entry->base_value = static_cast< float >( v );
				}

				bool bind_active = false;
				if ( bind_entry )
				{
					for ( std::size_t bi = 0; bi < bind_entry->count; ++bi )
					{
						if ( bind_entry->binds[ bi ].key != 0 && bind_entry->binds[ bi ].active )
						{
							bind_active = true;
							break;
						}
					}
				}

				const auto badge_x = abs.right() - value_w - 12.0f;
				const auto badge_bg = bind_active ? s.accent.alpha( 50 ) : s.combo_bg;
				const auto badge_border = bind_active ? s.accent : s.combo_border;
				const auto badge_text_col = bind_active ? s.accent : s.text;

				draw::current().rect_filled(badge_x, abs.y - 2.0f, value_w + 12.0f, text_height + 4.0f,
					badge_bg, xdraw::corner_radius{3.0f});
				draw::current().rect(badge_x, abs.y - 2.0f, value_w + 12.0f, text_height + 4.0f,
					badge_border, xdraw::corner_radius{3.0f});
				draw::current().text(badge_x + 6.0f, abs.y, value_buf, badge_text_col);

				if ( bind_entry && bind_entry->count > 0 )
				{
					std::string b_txt;
					if ( bind_entry->count == 1 && bind_entry->binds[ 0 ].key != 0 )
					{
						b_txt = std::string( "[" ) + vk_name( bind_entry->binds[ 0 ].key ) + "]";
					}
					else
					{
						b_txt = std::string( "[" ) + std::to_string( bind_entry->count ) + " binds]";
					}
					const auto [bw, bh] = xdraw::measure_text( b_txt );
					const auto bx = badge_x - bw - 8.0f;
					if ( bx > abs.x + 40.0f )
					{
						const auto b_col = bind_active ? s.accent : s.text_dim;
						draw::current().text( bx, abs.y, b_txt, b_col );
					}
				}
			}

			auto& value_anim = get_anim_states( )[ id ];
			value_anim = value_anim + ( static_cast< float >( v ) - value_anim ) * std::min( 20.0f * xdraw::delta_time( ), 1.0f );

			const auto hovered_or_active = ( can_interact && input.in_rect( slider_hit_rect ) ) || c.active_slider == id;
			auto& hover_anim_val = get_anim_states( )[ id + 1000000 ];
			hover_anim_val = hover_anim_val + ( ( hovered_or_active ? 1.0f : 0.0f ) - hover_anim_val ) * std::min( 12.0f * xdraw::delta_time( ), 1.0f );

			const auto range = static_cast< float >( v_max - v_min );
			const auto norm_pos = ( value_anim - static_cast< float >( v_min ) ) / range;

			auto& dl = draw::current( );

			if ( !display.empty( ) )
			{
				const auto [edit_w, edit_h] = is_editing ? xdraw::measure_text( c.slider_edit_buf.empty( ) ? "0" : c.slider_edit_buf ) : std::pair{ 0.0f, 0.0f };
				const auto cur_box_w = is_editing ? std::max( value_w + 16.0f, edit_w + 12.0f ) : ( value_w + 12.0f );
				const auto available_label_w = std::max( 0.0f, slider_width - cur_box_w - s.item_spacing_x );
				const auto label_text = truncate( display, available_label_w );
				const auto label_col = s.text;
				dl.text( abs.x, abs.y, label_text, label_col );
			}

			draw_minimal_slider( dl, track_rect.x, track_rect.y, track_rect.w, track_rect.h, norm_pos, s );

			return changed;
		}

	} // the slider namespace

	bool slider_float( std::string_view label, float& v, float v_min, float v_max, std::string_view fmt )
	{
		return slider( make_id( label ), label, v, v_min, v_max, fmt );
	}

	bool slider_int( std::string_view label, int& v, int v_min, int v_max, std::string_view fmt )
	{
		return slider( make_id( label ), label, v, v_min, v_max, fmt );
	}

	bool keybind( std::string_view label, int& key )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return false;
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto [display, full] = parse_label( label );
		const auto& s = c.style;
		const auto& input = c.input;

		const auto is_waiting = ( c.active_keybind == id );
		auto changed = false;

		const auto button_text = is_waiting ? "..." : vk_name( key );
		const auto [btw, bth] = xdraw::measure_text( button_text );
		const auto [lw, lh] = xdraw::measure_text( display );

		const auto button_width = s.keybind_w;
		const auto button_height = s.keybind_h;
		const auto total_w = !display.empty( ) ? ( button_width + s.item_spacing_x + lw ) : button_width;
		const auto total_h = std::max( button_height, lh );

		const auto abs = layout::item( total_w, total_h );
		const auto button_rect = rect{ abs.x, abs.y, button_width, button_height };

		const auto can_interact = !c.overlay_blocking( );
		const auto hovered = can_interact && ( input.in_rect( button_rect ) || input.in_rect( abs ) );

		if ( hovered )
		{
			set_hovered_tooltip( label );
		}

		if ( hovered && input.mouse_clicked )
		{
			c.active_keybind = id;
		}

		const auto dt = xdraw::delta_time( );
		const auto hover_anim = anim::lerp( id, hovered ? 1.0f : 0.0f, 12.0f );
		const auto wait_anim = anim::lerp( id + 1, is_waiting ? 1.0f : 0.0f, 12.0f );
		auto& pulse_anim = get_anim_states( )[ id + 2 ];

		if ( is_waiting )
		{
			pulse_anim += dt * 3.0f;

			if ( pulse_anim > 6.28318f )
			{
				pulse_anim -= 6.28318f;
			}
		}

		const auto r = s.keybind_rounding;
		auto bg = lerp( s.keybind_bg, lighten( s.keybind_bg, 1.05f ), hover_anim );
		auto border = lerp( s.keybind_border, lighten( s.keybind_border, 1.3f ), hover_anim );

		auto& dl = draw::current( );
		dl.rect_filled( button_rect.x, button_rect.y, button_rect.w, button_rect.h, bg, xdraw::corner_radius{ r } );

		if ( wait_anim > 0.01f )
		{
			constexpr auto pad{ 2.0f };
			const auto fx = button_rect.x + pad;
			const auto fy = button_rect.y + pad;
			const auto fw = button_rect.w - pad * 2.0f;
			const auto fh = button_rect.h - pad * 2.0f;

			const auto pulse_i = ( std::sin( pulse_anim ) * 0.5f + 0.5f ) * 0.4f + 0.6f;
			const auto shift = std::sin( pulse_anim * 0.5f ) * 0.5f + 0.5f;

			auto col_l = lighten( s.keybind_waiting, 1.0f + pulse_i * 0.3f );
			auto col_r = darken( s.keybind_waiting, 0.7f + pulse_i * 0.2f );
			col_l.a = static_cast< std::uint8_t >( col_l.a * wait_anim * 0.4f );
			col_r.a = static_cast< std::uint8_t >( col_r.a * wait_anim * 0.4f );

			const auto ikr = std::max( 0.0f, r - 2.0f );
			if ( shift > 0.5f )
			{
				dl.rect_filled_gradient( fx, fy, fw, fh, col_r, col_l, col_l, col_r, xdraw::corner_radius{ ikr } );
			}
			else
			{
				dl.rect_filled_gradient( fx, fy, fw, fh, col_l, col_r, col_r, col_l, xdraw::corner_radius{ ikr } );
			}

			const auto wb = lighten( s.keybind_waiting, 1.0f + pulse_i * 0.2f );
			border = lerp( border, wb, wait_anim );
		}

		dl.rect( button_rect.x, button_rect.y, button_rect.w, button_rect.h, border, xdraw::corner_radius{ r } );

		const auto kb_text_col = lerp( s.text_dim, s.text, std::max( hover_anim, wait_anim ) );
		const auto tx = button_rect.x + ( button_rect.w - btw ) * 0.5f;
		const auto ty = button_rect.y + ( button_rect.h - bth ) * 0.5f;
		dl.text( tx, ty, button_text, kb_text_col );

		if ( !display.empty( ) )
		{
			const auto lx = button_rect.x + button_width + s.item_spacing_x;
			const auto ly = abs.y + ( total_h - lh ) * 0.5f;
			const auto available_w = win->bounds.right( ) - lx - s.window_pad_x;
			const auto label_text = truncate( display, available_w );
			dl.text( lx, ly, label_text, kb_text_col );
		}

		if ( is_waiting )
		{
			if ( input.mouse_clicked && !hovered )
			{
				key = VK_LBUTTON;
				c.active_keybind = null_id;
				return true;
			}

			if ( input.rmb_clicked )
			{
				key = VK_RBUTTON;
				c.active_keybind = null_id;
				return true;
			}

			for ( const auto vk : input.key_presses( ) )
			{
				if ( vk == VK_ESCAPE )
				{
					key = 0;
				}
				else
				{
					key = vk;
				}

				c.active_keybind = null_id;
				return true;
			}
		}

		return changed;
	}

	namespace {

		class combo_overlay : public overlay
		{
		public:
			combo_overlay( std::uintptr_t id, const rect& anchor, float width, const std::vector<std::string>& items, int initial_val, float item_h, float item_pad, std::function<void( )> on_change = nullptr ) : overlay{ id, anchor }, m_width{ width }, m_items{ items }, m_selected_item{ initial_val }, m_current_val{ initial_val }, m_item_h{ item_h }, m_item_pad{ item_pad }, m_on_change{ std::move( on_change ) }
			{
				this->m_hover_anims.resize( items.size( ), 0.0f );
				this->m_selected_anims.resize( items.size( ), 0.0f );
				this->m_item_anims.resize( items.size( ), 0.0f );

				if ( this->m_current_val >= 0 && this->m_current_val < static_cast< int >( items.size( ) ) )
				{
					this->m_selected_anims[ this->m_current_val ] = 1.0f;
				}
			}

			bool hit_test( float x, float y ) const override
			{
				return this->get_dropdown( ).contains( x, y ) || this->m_anchor.contains( x, y );
			}

			bool process_input( const input_state& input ) override
			{
				if ( this->m_closing )
				{
					return false;
				}

				const auto dd = this->get_dropdown( );

				if ( input.mouse_clicked && !dd.contains( input.mouse_x, input.mouse_y ) && !this->m_anchor.contains( input.mouse_x, input.mouse_y ) )
				{
					this->m_closing = true;
					return true;
				}

				const auto ms = this->max_scroll( );
				if ( ms > 0.0f )
				{
					const auto track = this->get_scrollbar_track( dd );
					const auto thumb = this->get_scrollbar_thumb( track );

					if ( input.mouse_clicked && thumb.contains( input.mouse_x, input.mouse_y ) )
					{
						this->m_scrollbar_dragging = true;
						this->m_scrollbar_drag_offset = input.mouse_y - thumb.y;
						return true;
					}

					if ( input.mouse_clicked && track.contains( input.mouse_x, input.mouse_y ) )
					{
						const auto target_y = input.mouse_y - thumb.h * 0.5f;
						const auto rel = std::clamp( ( target_y - track.y ) / ( track.h - thumb.h ), 0.0f, 1.0f );
						this->m_scroll_target = rel * ms;
						this->m_scrollbar_dragging = true;
						this->m_scrollbar_drag_offset = thumb.h * 0.5f;
						return true;
					}

					if ( this->m_scrollbar_dragging )
					{
						if ( !input.mouse_down )
						{
							this->m_scrollbar_dragging = false;
						}
						else
						{
							const auto rel = std::clamp( ( input.mouse_y - this->m_scrollbar_drag_offset - track.y ) / ( track.h - thumb.h ), 0.0f, 1.0f );
							this->m_scroll_target = rel * ms;
							this->m_scroll = this->m_scroll_target;
							return true;
						}
					}
				}

				if ( dd.contains( input.mouse_x, input.mouse_y ) && input.scroll_delta != 0.0f )
				{
					this->m_scroll_target -= input.scroll_delta * 30.0f;
					this->m_scroll_target = std::clamp( this->m_scroll_target, 0.0f, this->max_scroll( ) );
					return true;
				}

				if ( input.mouse_clicked && dd.contains( input.mouse_x, input.mouse_y ) )
				{
					for ( int i = 0; i < static_cast< int >( this->m_items.size( ) ); ++i )
					{
						const auto iy = dd.y + this->m_item_pad + i * this->m_item_h - this->m_scroll;
						const auto ir = rect{ dd.x + this->m_item_pad, iy, dd.w - this->m_item_pad * 2.0f, this->m_item_h };

						if ( ir.contains( input.mouse_x, input.mouse_y ) )
						{
							this->m_selected_item = i;
							this->m_current_val = i;

							if ( this->m_on_change )
							{
								this->m_on_change( );
							}

							this->m_changed = true;
							this->m_closing = true;
							return true;
						}
					}
				}

				return dd.contains( input.mouse_x, input.mouse_y );
			}

			void render( const style& style, const input_state& input ) override
			{
				const auto dt = xdraw::delta_time( );
				const auto dd = get_dropdown( );
				auto& dl = xdraw::get( xdraw::layer::top );

				const auto speed = this->m_closing ? 16.0f : 14.0f;
				const auto target = this->m_closing ? 0.0f : 1.0f;
				this->m_open_anim += ( target - this->m_open_anim ) * std::min( speed * dt, 1.0f );

				if ( this->m_open_anim < 0.01f && this->m_closing )
				{
					this->m_closed = true;
					return;
				}

				const auto ease_t = ease::out_cubic( this->m_open_anim );
				const auto animated_h = dd.h * ease_t;
				const auto alpha_mult = ease_t;

				auto bg = style.combo_popup_bg;
				bg.a = static_cast< std::uint8_t >( bg.a * alpha_mult );
				auto border = lighten( style.combo_popup_border, 1.1f );
				border.a = static_cast< std::uint8_t >( border.a * alpha_mult );

				const auto pr = style.combo_popup_rounding;

				if ( animated_h > 1.0f )
				{
					dl.rect_filled_blurred( dd.x, dd.y, dd.w, animated_h, xdraw::corner_radius{ pr }, xdraw::color{ 255, 255, 255, static_cast< std::uint8_t >( 210.0f * alpha_mult ) } );
				}
				dl.rect_filled( dd.x, dd.y, dd.w, animated_h, bg, xdraw::corner_radius{ pr } );
				dl.rect( dd.x, dd.y, dd.w, animated_h, border, xdraw::corner_radius{ pr } );

				const auto ms = this->max_scroll( );
				const auto popup_hovered = !this->m_closing && dd.contains( input.mouse_x, input.mouse_y );
				const auto sb_target = ( popup_hovered || this->m_scrollbar_dragging ) && ms > 0.0f ? 1.0f : 0.0f;
				const auto sb_speed = sb_target > this->m_scrollbar_anim ? 7.0f : 12.0f;
				this->m_scrollbar_anim += ( sb_target - this->m_scrollbar_anim ) * std::min( sb_speed * dt, 1.0f );

				const auto shrink_phase = std::clamp( this->m_scrollbar_anim / 0.5f, 0.0f, 1.0f );
				const auto shrink_eased = ease::out_cubic( shrink_phase );
				const auto sb_alpha_phase = std::clamp( ( this->m_scrollbar_anim - 0.3f ) / 0.7f, 0.0f, 1.0f );
				const auto sb_alpha = ease::out_cubic( sb_alpha_phase );
				const auto sb_inset = ( k_scrollbar_w + k_scrollbar_pad ) * shrink_eased;

				this->m_scroll_target = std::clamp( this->m_scroll_target, 0.0f, ms );
				this->m_scroll += ( this->m_scroll_target - this->m_scroll ) * std::min( 18.0f * dt, 1.0f );
				this->m_scroll = std::clamp( this->m_scroll, 0.0f, ms );

				dl.push_clip( dd.x - 2.0f, dd.y, dd.w + 4.0f, animated_h );

				const auto item_count = static_cast< int >( this->m_items.size( ) );
				for ( int i = 0; i < item_count; ++i )
				{
					const auto iy = dd.y + this->m_item_pad + i * this->m_item_h - this->m_scroll;

					if ( iy + this->m_item_h <= dd.y || iy >= dd.y + animated_h )
					{
						continue;
					}

					const auto ir = rect
					{
						dd.x + this->m_item_pad,
						iy,
						dd.w - this->m_item_pad * 2.0f - sb_inset,
						this->m_item_h
					};

					const auto is_first = ( i == 0 );
					const auto is_last = ( i == item_count - 1 );
					const auto ir_tl = is_first ? pr : 0.0f;
					const auto ir_tr = is_first ? pr : 0.0f;
					const auto ir_bl = is_last ? pr : 0.0f;
					const auto ir_br = is_last ? pr : 0.0f;

					constexpr auto max_delay{ 0.5f };
					const auto item_count_f = static_cast< float >( item_count );
					const auto item_delay = ( item_count_f > 1.0f ) ? ( max_delay * static_cast< float >( i ) / ( item_count_f - 1.0f ) ) : 0.0f;
					const auto item_progress = std::clamp( ( this->m_open_anim - item_delay ) / ( 1.0f - max_delay ), 0.0f, 1.0f );
					auto& ia = this->m_item_anims[ i ];
					ia = std::min( ia + 18.0f * dt, item_progress );

					const auto item_ease = ease::out_cubic( ia );
					const auto item_alpha = item_ease * alpha_mult;
					const auto slide = ( 1.0f - item_ease ) * 8.0f;

					const auto is_selected = ( i == this->m_current_val );
					const auto is_hovered = ir.contains( input.mouse_x, input.mouse_y );

					auto& ha = this->m_hover_anims[ i ];
					ha += ( ( is_hovered && !this->m_closing ? 1.0f : 0.0f ) - ha ) * std::min( 15.0f * dt, 1.0f );

					auto& sa = this->m_selected_anims[ i ];
					sa += ( ( is_selected ? 1.0f : 0.0f ) - sa ) * std::min( 12.0f * dt, 1.0f );

					const auto se = ease::out_quad( sa );
					if ( se > 0.01f )
					{
						auto sel = style.combo_popup_item_selected;
						sel.a = static_cast< std::uint8_t >( sel.a * item_alpha * se );
						dl.rect_filled( ir.x, ir.y + slide, ir.w, ir.h, sel, xdraw::corner_radius{ ir_tl, ir_tr, ir_br, ir_bl } );
					}

					if ( ha > 0.01f )
					{
						auto hov = style.combo_popup_item_hovered;
						hov.a = static_cast< std::uint8_t >( hov.a * item_alpha * ha );
						dl.rect_filled( ir.x, ir.y + slide, ir.w, ir.h, hov, xdraw::corner_radius{ ir_tl, ir_tr, ir_br, ir_bl } );
					}

					const auto [tw, th] = xdraw::measure_text( this->m_items[ i ] );
					auto text_col = style.text;
					auto sel_text = lerp( style.text, style.accent, 0.4f );
					text_col = lerp( text_col, sel_text, se );
					text_col = lerp( text_col, lighten( text_col, 1.3f ), ha );
					text_col.a = static_cast< std::uint8_t >( text_col.a * item_alpha );

					dl.text( ir.x + 10.0f, ir.y + ( this->m_item_h - th ) * 0.5f + slide, this->m_items[ i ], text_col );
				}

				if ( ms > 0.0f )
				{
					constexpr auto fade_h{ 16.0f };
					const auto fcr = std::min( pr, fade_h );

					auto fade_solid = style.combo_popup_bg;
					fade_solid.a = static_cast< std::uint8_t >( fade_solid.a * alpha_mult );
					auto fade_clear = fade_solid;
					fade_clear.a = 0;

					const auto top_t = std::clamp( this->m_scroll / fade_h, 0.0f, 1.0f );
					if ( top_t > 0.01f && animated_h >= fade_h )
					{
						auto top = fade_solid;
						top.a = static_cast< std::uint8_t >( fade_solid.a * top_t );
						dl.rect_filled_gradient( dd.x, dd.y, dd.w, fade_h, top, top, fade_clear, fade_clear, xdraw::corner_radius{ fcr, fcr, 0.0f, 0.0f } );
					}

					const auto remaining = ms - this->m_scroll;
					const auto bot_t = std::clamp( remaining / fade_h, 0.0f, 1.0f );

					if ( bot_t > 0.01f && animated_h >= fade_h )
					{
						auto bot = fade_solid;
						bot.a = static_cast< std::uint8_t >( fade_solid.a * bot_t );
						dl.rect_filled_gradient( dd.x, dd.y + animated_h - fade_h, dd.w, fade_h, fade_clear, fade_clear, bot, bot, xdraw::corner_radius{ 0.0f, 0.0f, fcr, fcr } );
					}
				}

				if ( ms > 0.0f && sb_alpha > 0.01f )
				{
					const auto track = this->get_scrollbar_track( dd );
					const auto thumb = this->get_scrollbar_thumb( track );

					const auto thumb_hovered = thumb.contains( input.mouse_x, input.mouse_y );
					const auto thumb_active = thumb_hovered || this->m_scrollbar_dragging;

					auto track_col = xdraw::color{ 255, 255, 255, 30 };
					track_col.a = static_cast< std::uint8_t >( track_col.a * sb_alpha * alpha_mult );

					auto thumb_col = thumb_active ? xdraw::color{ 255, 255, 255, 150 } : xdraw::color{ 255, 255, 255, 100 };
					thumb_col.a = static_cast< std::uint8_t >( thumb_col.a * sb_alpha * alpha_mult );

					const auto track_r = k_scrollbar_w * 0.5f;
					dl.rect_filled( track.x, track.y, track.w, track.h, track_col, xdraw::corner_radius{ track_r } );
					dl.rect_filled( thumb.x, thumb.y, thumb.w, thumb.h, thumb_col, xdraw::corner_radius{ track_r } );
				}

				dl.pop_clip( );
			}

			[[nodiscard]] bool was_changed( ) const { return this->m_changed; }
			void clear_changed( ) { this->m_changed = false; }
			[[nodiscard]] int get_selected_item( ) const { return this->m_selected_item; }
			void update_current_val( int val ) { this->m_current_val = val; }

		private:
			static constexpr auto k_max_h{ 255.0f };
			static constexpr auto k_scrollbar_w{ 6.0f };
			static constexpr auto k_scrollbar_pad{ 4.0f };

			rect get_dropdown( ) const
			{
				const auto full_h = static_cast< float >( this->m_items.size( ) ) * this->m_item_h + this->m_item_pad * 2.0f;
				return { this->m_anchor.x, this->m_anchor.bottom( ) + 4.0f, this->m_width, std::min( full_h, this->k_max_h ) };
			}

			float max_scroll( ) const
			{
				const auto full_h = static_cast< float >( this->m_items.size( ) ) * this->m_item_h + this->m_item_pad * 2.0f;
				return std::max( 0.0f, full_h - this->k_max_h );
			}

			rect get_scrollbar_track( const rect& dd ) const
			{
				return rect
				{
					dd.right( ) - k_scrollbar_w - k_scrollbar_pad,
					dd.y + k_scrollbar_pad,
					k_scrollbar_w,
					dd.h - k_scrollbar_pad * 2.0f
				};
			}

			rect get_scrollbar_thumb( const rect& track ) const
			{
				const auto full_h = static_cast< float >( this->m_items.size( ) ) * this->m_item_h + this->m_item_pad * 2.0f;
				const auto thumb_h = std::max( 20.0f, track.h * ( this->k_max_h / full_h ) );
				const auto ms = this->max_scroll( );
				const auto rel = ms > 0.0f ? ( this->m_scroll / ms ) : 0.0f;
				const auto thumb_y = track.y + rel * ( track.h - thumb_h );
				return rect{ track.x, thumb_y, track.w, thumb_h };
			}

			float m_width{};
			std::vector<std::string> m_items{};
			int m_selected_item{ -1 };
			int m_current_val{ 0 };
			float m_item_h{};
			float m_item_pad{};
			std::function<void( )> m_on_change{};
			float m_open_anim{};
			float m_scroll{};
			float m_scroll_target{};
			std::vector<float> m_item_anims{};
			std::vector<float> m_hover_anims{};
			std::vector<float> m_selected_anims{};
			bool m_changed{};
			float m_scrollbar_anim{};
			bool m_scrollbar_dragging{};
			float m_scrollbar_drag_offset{};
		};

	} // the combo namespace

	bool combo( std::string_view label, int& current, const char* const items[ ], int count, float width )
	{
		auto win = layout::current_window( );
		if ( !win || count <= 0 )
		{
			return false;
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto [display, full] = parse_label( label );
		const auto& s = c.style;
		const auto& input = c.input;

		const auto is_open = overlays::is_open( id );
		auto changed{ false };

		if ( auto popup = dynamic_cast< combo_overlay* >( overlays::find( id ) ) )
		{
			if ( popup->was_changed( ) )
			{
				const auto sel = popup->get_selected_item( );
				if ( sel >= 0 && sel < count )
				{
					current = sel;
				}
				changed = true;
				popup->clear_changed( );
			}
		}

		if ( width <= 0.0f )
		{
			width = layout::item_width( );
		}

		const auto [lw, lh] = xdraw::measure_text( display );
		const auto combo_h_val = s.combo_h;
		const auto sp = s.item_spacing_y * 0.25f;
		const auto total_h = lh + sp + combo_h_val;

		const auto abs = layout::item( width, total_h, lh );
		const auto button_y = abs.y + lh + sp;
		const auto button_rect = rect{ abs.x, button_y, width, combo_h_val };

		if ( is_open )
		{
			overlays::touch( id );

			if ( auto popup = dynamic_cast< combo_overlay* >( overlays::find( id ) ) )
			{
				popup->update_anchor( button_rect );
				popup->update_current_val( current );
			}
		}

		const auto can_interact = !c.overlay_blocking( ) || is_open;
		const auto hovered = can_interact && ( input.in_rect( button_rect ) || input.in_rect( abs ) );

		if ( hovered && !is_open && !c.overlay_blocking( ) )
		{
			set_hovered_tooltip( label );
		}

		if ( hovered && input.mouse_clicked )
		{
			if ( is_open )
			{
				overlays::close( id );
			}
			else if ( !c.overlay_blocking( ) )
			{
				std::vector<std::string> items_vec;
				items_vec.reserve( count );

				for ( int i = 0; i < count; ++i )
				{
					items_vec.emplace_back( items[ i ] );
				}

				overlays::add( std::make_unique<combo_overlay>( id, button_rect, width, items_vec, current, s.combo_item_h, s.window_pad_y * 0.5f ) );
			}
		}

		const auto r = s.combo_rounding;
		const auto hover_anim = anim::lerp( id, ( hovered || is_open ) ? 1.0f : 0.0f, 15.0f );
		const auto bg = lerp( s.combo_bg, s.combo_hovered, hover_anim );
		const auto border = is_open ? lighten( s.combo_border, 1.3f ) : lerp( s.combo_border, lighten( s.combo_border, 1.15f ), hover_anim );

		auto& dl = draw::current( );

		if ( !display.empty( ) )
		{
			const auto label_text = truncate( display, width );
			const auto label_col = lerp( s.text_dim, s.text, hover_anim );
			dl.text( abs.x, abs.y, label_text, label_col );
		}

		dl.rect_filled( button_rect.x, button_rect.y, button_rect.w, button_rect.h, bg, xdraw::corner_radius{ r } );
		dl.rect( button_rect.x, button_rect.y, button_rect.w, button_rect.h, border, xdraw::corner_radius{ r } );

		const auto current_text = ( current >= 0 && current < count ) ? items[ current ] : "";
		const auto [tw, th] = xdraw::measure_text( current_text );
		const auto combo_text_col = s.text;
		dl.text( button_rect.x + s.frame_pad_x, button_rect.y + ( combo_h_val - th ) * 0.5f, current_text, combo_text_col );

		constexpr auto arrow_size{ 6.0f };
		constexpr auto arrow_h_val{ 3.5f };

		const auto ax = button_rect.right( ) - arrow_size - s.frame_pad_x - 4.0f;
		const auto ay = button_rect.y + ( combo_h_val - arrow_h_val ) * 0.5f;
		const auto arrow_col = lerp( s.combo_arrow, lighten( s.combo_arrow, 1.3f ), hover_anim );

		if ( is_open )
		{
			const float pts[ ]{ ax, ay + arrow_h_val, ax + arrow_size * 0.5f, ay, ax + arrow_size, ay + arrow_h_val };
			dl.polyline( pts, arrow_col, false, 1.5f );
		}
		else
		{
			const float pts[ ]{ ax, ay, ax + arrow_size * 0.5f, ay + arrow_h_val, ax + arrow_size, ay };
			dl.polyline( pts, arrow_col, false, 1.5f );
		}

		return changed;
	}

	namespace {

		class multicombo_overlay : public overlay
		{
		public:
			multicombo_overlay( std::uintptr_t id, const rect& anchor, float width, const char* const* items, int count, bool* selected, float item_h, float item_pad ) : overlay{ id, anchor }, m_width{ width }, m_count{ count }, m_selected{ selected }, m_item_h{ item_h }, m_item_pad{ item_pad }
			{
				this->m_items.reserve( count );

				for ( int i = 0; i < count; ++i )
				{
					this->m_items.emplace_back( items[ i ] );
				}

				this->m_hover_anims.resize( count, 0.0f );
				this->m_check_anims.resize( count, 0.0f );
				this->m_item_anims.resize( count, 0.0f );

				for ( int i = 0; i < count; ++i )
				{
					this->m_check_anims[ i ] = selected[ i ] ? 1.0f : 0.0f;
				}
			}

			bool hit_test( float x, float y ) const override
			{
				return this->get_dropdown( ).contains( x, y ) || this->m_anchor.contains( x, y );
			}

			bool process_input( const input_state& input ) override
			{
				if ( this->m_closing )
				{
					return false;
				}

				const auto dd = this->get_dropdown( );

				if ( input.mouse_clicked && !dd.contains( input.mouse_x, input.mouse_y ) && !this->m_anchor.contains( input.mouse_x, input.mouse_y ) )
				{
					this->m_closing = true;
					return true;
				}

				if ( dd.contains( input.mouse_x, input.mouse_y ) && input.scroll_delta != 0.0f )
				{
					this->m_scroll -= input.scroll_delta * 30.0f;
					this->m_scroll = std::clamp( this->m_scroll, 0.0f, max_scroll( ) );
					return true;
				}

				if ( input.mouse_clicked && dd.contains( input.mouse_x, input.mouse_y ) )
				{
					for ( int i = 0; i < this->m_count; ++i )
					{
						const auto iy = dd.y + this->m_item_pad + i * this->m_item_h - this->m_scroll;
						const auto ir = rect{ dd.x + this->m_item_pad, iy, dd.w - this->m_item_pad * 2.0f, this->m_item_h };

						if ( ir.contains( input.mouse_x, input.mouse_y ) && this->m_selected )
						{
							this->m_selected[ i ] = !this->m_selected[ i ];
							this->m_changed = true;
							this->m_display_dirty = true;
							return true;
						}
					}
				}

				return dd.contains( input.mouse_x, input.mouse_y );
			}

			void render( const style& style, const input_state& input ) override
			{
				const auto dt = xdraw::delta_time( );
				const auto dd = get_dropdown( );
				auto& dl = xdraw::get( xdraw::layer::top );

				const auto speed = this->m_closing ? 16.0f : 14.0f;
				const auto target = this->m_closing ? 0.0f : 1.0f;
				this->m_open_anim += ( target - this->m_open_anim ) * std::min( speed * dt, 1.0f );

				if ( this->m_open_anim < 0.01f && this->m_closing )
				{
					this->m_closed = true;
					return;
				}

				const auto ease_t = ease::out_cubic( this->m_open_anim );
				const auto animated_h = dd.h * ease_t;
				const auto alpha_mult = ease_t;

				auto bg = style.combo_popup_bg;
				bg.a = static_cast< std::uint8_t >( bg.a * alpha_mult );
				auto border = lighten( style.combo_popup_border, 1.1f );
				border.a = static_cast< std::uint8_t >( border.a * alpha_mult );

				const auto pr = style.combo_popup_rounding;

				if ( animated_h > 1.0f )
				{
					dl.rect_filled_blurred( dd.x, dd.y, dd.w, animated_h, xdraw::corner_radius{ pr }, xdraw::color{ 255, 255, 255, static_cast< std::uint8_t >( 210.0f * alpha_mult ) } );
				}
				dl.rect_filled( dd.x, dd.y, dd.w, animated_h, bg, xdraw::corner_radius{ pr } );
				dl.rect( dd.x, dd.y, dd.w, animated_h, border, xdraw::corner_radius{ pr } );

				dl.push_clip( dd.x - 2.0f, dd.y, dd.w + 4.0f, animated_h );

				constexpr auto max_delay{ 0.5f };
				const auto count_f = static_cast< float >( this->m_count );

				for ( int i = 0; i < this->m_count; ++i )
				{
					const auto iy = dd.y + this->m_item_pad + i * this->m_item_h - this->m_scroll;
					if ( iy + this->m_item_h <= dd.y || iy >= dd.y + animated_h )
					{
						continue;
					}

					const auto ir = rect{ dd.x + this->m_item_pad, iy, dd.w - this->m_item_pad * 2.0f, this->m_item_h };

					const auto item_delay = ( count_f > 1.0f ) ? ( max_delay * static_cast< float >( i ) / ( count_f - 1.0f ) ) : 0.0f;
					const auto item_progress = std::clamp( ( this->m_open_anim - item_delay ) / ( 1.0f - max_delay ), 0.0f, 1.0f );
					auto& ia = this->m_item_anims[ i ];

					ia = std::min( ia + 18.0f * dt, item_progress );

					const auto item_ease = ease::out_cubic( ia );
					const auto item_alpha = item_ease * alpha_mult;
					const auto slide = ( 1.0f - item_ease ) * 8.0f;

					const auto is_selected = this->m_selected && this->m_selected[ i ];
					const auto is_hovered = ir.contains( input.mouse_x, input.mouse_y ) && !m_closing;

					auto& ca = this->m_check_anims[ i ];
					ca += ( ( is_selected ? 1.0f : 0.0f ) - ca ) * std::min( 12.0f * dt, 1.0f );
					const auto ce = ease::smoothstep( ca );

					auto& ha = this->m_hover_anims[ i ];
					ha += ( ( is_hovered ? 1.0f : 0.0f ) - ha ) * std::min( 18.0f * dt, 1.0f );
					const auto he = ease::out_quad( ha );

					const auto is_first = ( i == 0 );
					const auto is_last = ( i == this->m_count - 1 );
					const auto ir_tl = is_first ? pr : 0.0f;
					const auto ir_tr = is_first ? pr : 0.0f;
					const auto ir_bl = is_last ? pr : 0.0f;
					const auto ir_br = is_last ? pr : 0.0f;

					if ( he > 0.01f )
					{
						auto hov = style.combo_popup_item_hovered;
						hov.a = static_cast< std::uint8_t >( hov.a * item_alpha * he );
						dl.rect_filled( ir.x, ir.y + slide, ir.w, ir.h, hov, xdraw::corner_radius{ ir_tl, ir_tr, ir_br, ir_bl } );
					}

					constexpr auto check_size{ 12.0f };
					const auto cx = ir.x + 4.0f;
					const auto cy = ir.y + ( this->m_item_h - check_size ) * 0.5f + slide;

					draw_minimal_checkbox( dl, cx, cy, check_size, ce, style, item_alpha );

					auto text_col = style.text;
					if ( ce > 0.5f )
					{
						text_col = lerp( text_col, style.checkbox_mark, ( ce - 0.5f ) * 0.6f );
					}

					text_col = lerp( text_col, lighten( text_col, 1.2f ), he );
					text_col.a = static_cast< std::uint8_t >( text_col.a * item_alpha );

					const auto [tw, th] = xdraw::measure_text( this->m_items[ i ] );
					dl.text( ir.x + check_size + 10.0f, ir.y + ( this->m_item_h - th ) * 0.5f + slide, this->m_items[ i ], text_col );
				}

				const auto ms = this->max_scroll( );
				if ( ms > 0.0f )
				{
					constexpr auto fade_h{ 14.0f };
					const auto fcr = std::min( pr, fade_h );

					auto fade_solid = style.combo_popup_bg;
					fade_solid.a = static_cast< std::uint8_t >( fade_solid.a * alpha_mult );
					auto fade_clear = fade_solid;
					fade_clear.a = 0;

					const auto top_t = std::clamp( this->m_scroll / fade_h, 0.0f, 1.0f );
					if ( top_t > 0.01f && animated_h >= fade_h )
					{
						auto top = fade_solid;
						top.a = static_cast< std::uint8_t >( fade_solid.a * top_t );
						dl.rect_filled_gradient( dd.x, dd.y, dd.w, fade_h, top, top, fade_clear, fade_clear, xdraw::corner_radius{ fcr, fcr, 0.0f, 0.0f } );
					}

					const auto remaining = ms - this->m_scroll;
					const auto bot_t = std::clamp( remaining / fade_h, 0.0f, 1.0f );
					if ( bot_t > 0.01f && animated_h >= fade_h )
					{
						auto bot = fade_solid;
						bot.a = static_cast< std::uint8_t >( fade_solid.a * bot_t );
						dl.rect_filled_gradient( dd.x, dd.y + animated_h - fade_h, dd.w, fade_h, fade_clear, fade_clear, bot, bot, xdraw::corner_radius{ 0.0f, 0.0f, fcr, fcr } );
					}
				}

				dl.pop_clip( );
			}

			[[nodiscard]] bool was_changed( ) const { return this->m_changed; }
			void clear_changed( ) { this->m_changed = false; }

			[[nodiscard]] const std::string& get_display_text( ) const
			{
				if ( this->m_display_dirty )
				{
					this->m_cached_display.clear( );

					for ( int i = 0; i < this->m_count; ++i )
					{
						if ( this->m_selected && this->m_selected[ i ] )
						{
							if ( !this->m_cached_display.empty( ) )
							{
								this->m_cached_display += ", ";
							}

							this->m_cached_display += m_items[ i ];
						}
					}

					if ( this->m_cached_display.empty( ) )
					{
						this->m_cached_display = "none";
					}

					this->m_display_dirty = false;
				}

				return this->m_cached_display;
			}

		private:
			static constexpr auto k_max_h{ 255.0f };

			rect get_dropdown( ) const
			{
				const auto full_h = static_cast< float >( this->m_count ) * this->m_item_h + this->m_item_pad * 2.0f;
				return { this->m_anchor.x, this->m_anchor.bottom( ) + 4.0f, this->m_width, std::min( full_h, this->k_max_h ) };
			}

			float max_scroll( ) const
			{
				const auto full_h = static_cast< float >( this->m_count ) * this->m_item_h + this->m_item_pad * 2.0f;
				return std::max( 0.0f, full_h - this->k_max_h );
			}

			float m_width{};
			std::vector<std::string> m_items{};
			int m_count{};
			bool* m_selected{};
			float m_item_h{};
			float m_item_pad{};
			float m_open_anim{};
			float m_scroll{};
			std::vector<float> m_item_anims{};
			std::vector<float> m_check_anims{};
			std::vector<float> m_hover_anims{};
			bool m_changed{};
			mutable std::string m_cached_display{};
			mutable bool m_display_dirty{ true };
		};

	} // the multicombo namespace

	bool multicombo( std::string_view label, bool* selected, const char* const items[ ], int count, float width )
	{
		auto win = layout::current_window( );
		if ( !win || count <= 0 || !selected )
		{
			return false;
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto [display, full] = parse_label( label );
		const auto& s = c.style;
		const auto& input = c.input;

		const auto is_open = overlays::is_open( id );
		auto changed{ false };

		if ( auto popup = dynamic_cast< multicombo_overlay* >( overlays::find( id ) ) )
		{
			if ( popup->was_changed( ) )
			{
				changed = true;
				popup->clear_changed( );
			}
		}

		if ( width <= 0.0f )
		{
			width = layout::item_width( );
		}

		const auto [lw, lh] = xdraw::measure_text( display );
		const auto combo_h_val = s.combo_h;
		const auto sp = s.item_spacing_y * 0.25f;
		const auto total_h = lh + sp + combo_h_val;

		const auto abs = layout::item( width, total_h, lh );
		const auto button_y = abs.y + lh + sp;
		const auto button_rect = rect{ abs.x, button_y, width, combo_h_val };

		if ( is_open )
		{
			overlays::touch( id );

			if ( auto popup = dynamic_cast< multicombo_overlay* >( overlays::find( id ) ) )
			{
				popup->update_anchor( button_rect );
			}
		}

		const auto can_interact = !c.overlay_blocking( ) || is_open;
		const auto hovered = can_interact && ( input.in_rect( button_rect ) || input.in_rect( abs ) );

		if ( hovered && !is_open && !c.overlay_blocking( ) )
		{
			set_hovered_tooltip( label );
		}

		if ( hovered && input.mouse_clicked )
		{
			if ( is_open )
			{
				overlays::close( id );
			}
			else if ( !c.overlay_blocking( ) )
			{
				overlays::add( std::make_unique<multicombo_overlay>( id, button_rect, width, items, count, selected, s.combo_item_h, s.window_pad_y * 0.5f ) );
			}
		}

		const auto r = s.combo_rounding;
		const auto hover_anim = anim::lerp( id, ( hovered || is_open ) ? 1.0f : 0.0f, 15.0f );
		const auto bg = lerp( s.combo_bg, s.combo_hovered, hover_anim );
		const auto border = is_open ? lighten( s.combo_border, 1.3f ) : lerp( s.combo_border, lighten( s.combo_border, 1.15f ), hover_anim );
		const auto mc_text_col = lerp( s.text_dim, s.text, hover_anim );

		auto& dl = draw::current( );

		if ( !display.empty( ) )
		{
			dl.text( abs.x, abs.y, truncate( display, width ), mc_text_col );
		}

		dl.rect_filled( button_rect.x, button_rect.y, button_rect.w, button_rect.h, bg, xdraw::corner_radius{ r } );
		dl.rect( button_rect.x, button_rect.y, button_rect.w, button_rect.h, border, xdraw::corner_radius{ r } );

		std::string_view display_text{ "none" };
		std::string local_display;

		if ( auto popup = dynamic_cast< multicombo_overlay* >( overlays::find( id ) ) )
		{
			display_text = popup->get_display_text( );
		}
		else
		{
			for ( int i = 0; i < count; ++i )
			{
				if ( selected[ i ] )
				{
					if ( !local_display.empty( ) )
					{
						local_display += ", ";
					}

					local_display += items[ i ];
				}
			}

			display_text = local_display.empty( ) ? std::string_view{ "none" } : std::string_view{ local_display };
		}

		constexpr auto arrow_size{ 6.0f };
		const auto arrow_pad = s.frame_pad_x + 4.0f + arrow_size + 8.0f;
		const auto max_text_w = width - s.frame_pad_x - arrow_pad;
		const auto text_trunc = truncate( display_text, max_text_w );
		const auto [dtw, dth] = xdraw::measure_text( text_trunc );

		dl.text( button_rect.x + s.frame_pad_x, button_rect.y + ( combo_h_val - dth ) * 0.5f, text_trunc, mc_text_col );

		constexpr auto arrow_h_val{ 3.5f };
		const auto ax = button_rect.right( ) - arrow_size - s.frame_pad_x - 4.0f;
		const auto ay = button_rect.y + ( combo_h_val - arrow_h_val ) * 0.5f;
		const auto arrow_col = lerp( s.combo_arrow, lighten( s.combo_arrow, 1.3f ), hover_anim );

		if ( is_open )
		{
			const float pts[ ]{ ax, ay + arrow_h_val, ax + arrow_size * 0.5f, ay, ax + arrow_size, ay + arrow_h_val };
			dl.polyline( pts, arrow_col, false, 1.5f );
		}
		else
		{
			const float pts[ ]{ ax, ay, ax + arrow_size * 0.5f, ay + arrow_h_val, ax + arrow_size, ay };
			dl.polyline( pts, arrow_col, false, 1.5f );
		}

		return changed;
	}

	namespace {

		class color_picker_overlay : public overlay
		{
		public:
			color_picker_overlay( std::uintptr_t id, const rect& anchor, xdraw::color* col, bool show_alpha, bool* filled = nullptr ) : overlay{ id, anchor }, m_col{ col }, m_show_alpha{ show_alpha }, m_filled{ filled }
			{
				if ( col )
				{
					const auto h = rgb_to_hsv( *col );
					this->m_hue = h.h / 360.0f;
					this->m_sat = h.s;
					this->m_val = h.v;
				}
			}

			void update_filled( bool* filled ) { this->m_filled = filled; }

			[[nodiscard]] bool hit_test( float x, float y ) const override
			{
				return this->get_popup( ).contains( x, y ) || this->m_anchor.contains( x, y );
			}

			bool process_input( const input_state& input ) override
			{
				if ( this->m_closing )
				{
					return false;
				}

				const auto popup = this->get_popup( );

				if ( input.mouse_clicked && !popup.contains( input.mouse_x, input.mouse_y ) && !this->m_anchor.contains( input.mouse_x, input.mouse_y ) )
				{
					this->m_closing = true;
					return true;
				}

				const auto pad{ 8.0f };
				const auto bar_w{ 14.0f };
				const auto bar_spacing{ 8.0f };
				const auto hue_bar_h{ 14.0f };
				const auto sv_size = this->m_show_alpha ? ( popup.w - pad * 3.0f - bar_w ) : ( popup.w - pad * 2.0f );

				const auto sv = rect{ popup.x + pad, popup.y + pad, sv_size, sv_size };
				const auto hue = rect{ popup.x + pad, sv.bottom( ) + bar_spacing, sv_size, hue_bar_h };
				const auto alpha_r = rect{ sv.right( ) + bar_spacing, popup.y + pad, bar_w, sv_size + bar_spacing + hue_bar_h };

				if ( this->m_filled )
				{
					const auto cb_y = hue.bottom( ) + bar_spacing;
					const auto cb_rect = rect{ popup.x + pad, cb_y, popup.w - pad * 2.0f, 18.0f };

					if ( input.mouse_clicked && cb_rect.contains( input.mouse_x, input.mouse_y ) )
					{
						*this->m_filled = !*this->m_filled;
						this->m_changed = true;
						return true;
					}
				}

				if ( input.mouse_clicked )
				{
					if ( sv.contains( input.mouse_x, input.mouse_y ) )
					{
						this->m_active = 1;
					}
					else if ( hue.contains( input.mouse_x, input.mouse_y ) )
					{
						this->m_active = 2;
					}
					else if ( this->m_show_alpha && alpha_r.contains( input.mouse_x, input.mouse_y ) )
					{
						this->m_active = 3;
					}
				}

				if ( input.mouse_released )
				{
					this->m_active = 0;
				}

				if ( input.mouse_down && this->m_active != 0 )
				{
					if ( this->m_active == 1 )
					{
						this->m_sat = std::clamp( ( input.mouse_x - sv.x ) / sv.w, 0.0f, 1.0f );
						this->m_val = 1.0f - std::clamp( ( input.mouse_y - sv.y ) / sv.h, 0.0f, 1.0f );
					}
					else if ( this->m_active == 2 )
					{
						this->m_hue = std::clamp( ( input.mouse_x - hue.x ) / hue.w, 0.0f, 1.0f );
					}
					else if ( this->m_active == 3 && this->m_col )
					{
						this->m_col->a = static_cast< std::uint8_t >( ( 1.0f - std::clamp( ( input.mouse_y - alpha_r.y ) / alpha_r.h, 0.0f, 1.0f ) ) * 255.0f );
					}

					if ( this->m_col && this->m_active != 3 )
					{
						const auto nc = hsv_to_rgb( this->m_hue * 360.0f, this->m_sat, this->m_val );
						this->m_col->r = nc.r;
						this->m_col->g = nc.g;
						this->m_col->b = nc.b;
					}

					this->m_changed = true;
				}

				return popup.contains( input.mouse_x, input.mouse_y );
			}

			void render( const style& style, const input_state& ) override
			{
				const auto dt = xdraw::delta_time( );
				const auto popup = this->get_popup( );
				auto& dl = xdraw::get( xdraw::layer::top );

				const auto speed = this->m_closing ? 18.0f : 16.0f;
				const auto target = this->m_closing ? 0.0f : 1.0f;
				this->m_open_anim += ( target - this->m_open_anim ) * std::min( speed * dt, 1.0f );

				if ( this->m_open_anim < 0.01f && this->m_closing )
				{
					this->m_closed = true;
					return;
				}

				const auto ease_t = ease::out_cubic( this->m_open_anim );
				const auto alpha_mult = ease_t;
				const auto scale = 0.95f + ease_t * 0.05f;

				const auto sw = popup.w * scale;
				const auto sh = popup.h * scale;
				const auto sx = popup.x + ( popup.w - sw ) * 0.5f;
				const auto sy = popup.y + ( popup.h - sh ) * 0.5f;

				const auto pr = style.picker_popup_rounding;
				auto tint = style.picker_popup_bg;
				tint.a = static_cast< std::uint8_t >( tint.a * alpha_mult );
				auto border = style.picker_popup_border;
				border.a = static_cast< std::uint8_t >( border.a * alpha_mult );

				dl.rect_filled( sx, sy, sw, sh, tint, xdraw::corner_radius{ pr } );
				dl.rect( sx, sy, sw, sh, border, xdraw::corner_radius{ pr } );

				if ( ease_t < 0.15f )
				{
					return;
				}

				const auto ca = std::clamp( ( ease_t - 0.15f ) / 0.85f, 0.0f, 1.0f );
				const auto a = static_cast< std::uint8_t >( 255 * ca );

				dl.push_clip( sx, sy, sw, sh );

				const auto pad{ 8.0f };
				const auto bar_w{ 14.0f };
				const auto bar_spacing{ 8.0f };
				const auto cr{ 4.0f };

				const auto has_alpha = this->m_show_alpha;
				const auto sv_size = has_alpha ? ( sw - pad * 3.0f - bar_w ) : ( sw - pad * 2.0f );
				const auto hue_bar_h{ 14.0f };

				const auto sv_rect = rect{ sx + pad, sy + pad, sv_size, sv_size };
				const auto hue_rect = rect{ sx + pad, sv_rect.bottom( ) + bar_spacing, sv_size, hue_bar_h };
				const auto alpha_rect = rect{ sv_rect.right( ) + bar_spacing, sy + pad, bar_w, sv_size + bar_spacing + hue_bar_h };

				const auto sv_corners = xdraw::corner_radius
				{
					cr,
					has_alpha ? 0.0f : cr,
					0.0f,
					0.0f
				};

				const auto hue_corners = xdraw::corner_radius
				{
					0.0f,
					0.0f,
					has_alpha ? 0.0f : cr,
					cr
				};

				const auto alpha_corners = xdraw::corner_radius
				{
					0.0f,
					cr,
					cr,
					0.0f
				};

				{
					const auto hue_col = hsv_to_rgb( this->m_hue * 360.0f, 1.0f, 1.0f );
					const auto hue_a = xdraw::color{ hue_col.r, hue_col.g, hue_col.b, a };
					const auto white_a = xdraw::color{ 255, 255, 255, a };
					const auto black_a = xdraw::color{ 0, 0, 0, a };
					const auto clear = xdraw::color{ 0, 0, 0, 0 };

					dl.rect_filled_gradient( sv_rect.x, sv_rect.y, sv_rect.w, sv_rect.h, white_a, hue_a, hue_a, white_a, sv_corners );
					dl.rect_filled_gradient( sv_rect.x, sv_rect.y, sv_rect.w, sv_rect.h, clear, clear, black_a, black_a, sv_corners );
				}

				{
					constexpr auto hue_segments{ 6 };
					const auto seg_w = hue_rect.w / static_cast< float >( hue_segments );

					for ( int i = 0; i < hue_segments; ++i )
					{
						const auto h0 = static_cast< float >( i ) / static_cast< float >( hue_segments ) * 360.0f;
						const auto h1 = static_cast< float >( i + 1 ) / static_cast< float >( hue_segments ) * 360.0f;

						auto c0 = hsv_to_rgb( h0, 1.0f, 1.0f );
						auto c1 = hsv_to_rgb( h1, 1.0f, 1.0f );
						c0.a = a;
						c1.a = a;

						const auto seg_x = hue_rect.x + seg_w * static_cast< float >( i );
						const auto is_first = ( i == 0 );
						const auto is_last = ( i == hue_segments - 1 );

						const auto seg_r = xdraw::corner_radius
						{
							0.0f,
							0.0f,
							is_last ? hue_corners.br : 0.0f,
							is_first ? hue_corners.bl : 0.0f
						};

						dl.rect_filled_gradient( seg_x, hue_rect.y, seg_w + ( is_last ? 0.0f : 1.0f ), hue_rect.h, c0, c1, c1, c0, seg_r );
					}
				}

				if ( has_alpha && this->m_col )
				{
					auto top_col = xdraw::color{ this->m_col->r, this->m_col->g, this->m_col->b, a };
					auto bot_col = xdraw::color{ this->m_col->r, this->m_col->g, this->m_col->b, 0 };

					dl.rect_filled_gradient( alpha_rect.x, alpha_rect.y, alpha_rect.w, alpha_rect.h, top_col, top_col, bot_col, bot_col, alpha_corners );
				}

				auto white = xdraw::color{ 255, 255, 255, a };
				auto dark = xdraw::color{ 0, 0, 0, static_cast< std::uint8_t >( 120 * ca ) };

				{
					const auto sv_cx = sv_rect.x + this->m_sat * sv_rect.w;
					const auto sv_cy = sv_rect.y + ( 1.0f - this->m_val ) * sv_rect.h;
					const auto selected = hsv_to_rgb( this->m_hue * 360.0f, this->m_sat, this->m_val );
					const auto fill = xdraw::color{ selected.r, selected.g, selected.b, a };

					dl.circle_filled( sv_cx, sv_cy, 6.0f, fill );
					dl.circle( sv_cx, sv_cy, 6.0f, white, 2.0f );
					dl.circle( sv_cx, sv_cy, 7.5f, dark, 1.0f );
				}

				{
					const auto hue_cx = hue_rect.x + this->m_hue * hue_rect.w;
					const auto pill_w = 4.0f;
					const auto pill_h = hue_rect.h + 4.0f;
					const auto pill_r = pill_w * 0.5f;
					const auto pill_x = hue_cx - pill_w * 0.5f;
					const auto pill_y = hue_rect.y - 2.0f;

					dl.rect_filled( pill_x, pill_y, pill_w, pill_h, white, xdraw::corner_radius{ pill_r } );
					dl.rect( pill_x, pill_y, pill_w, pill_h, dark, xdraw::corner_radius{ pill_r } );
				}

				if ( has_alpha && this->m_col )
				{
					const auto alpha_cy = alpha_rect.y + ( 1.0f - this->m_col->a / 255.0f ) * alpha_rect.h;
					const auto pill_w = alpha_rect.w + 4.0f;
					const auto pill_h = 4.0f;
					const auto pill_r = pill_h * 0.5f;
					const auto pill_x = alpha_rect.x - 2.0f;
					const auto pill_y = alpha_cy - pill_h * 0.5f;

					dl.rect_filled( pill_x, pill_y, pill_w, pill_h, white, xdraw::corner_radius{ pill_r } );
					dl.rect( pill_x, pill_y, pill_w, pill_h, dark, xdraw::corner_radius{ pill_r } );
				}

				if ( this->m_filled )
				{
					const auto cb_y = hue_rect.bottom( ) + bar_spacing;
					const auto cb_size = 14.0f;
					const auto cb_anim = anim::lerp( this->m_id + 88, *this->m_filled ? 1.0f : 0.0f, 12.0f );
					const auto ease_cb = ease::smoothstep( cb_anim );

					draw_minimal_checkbox( dl, sx + pad, cb_y + 2.0f, cb_size, ease_cb, style, ca );

					const auto [lw, lh] = xdraw::measure_text( "filled" );
					auto text_col = lerp( style.text_dim, style.text, cb_anim );
					text_col.a = static_cast< std::uint8_t >( text_col.a * ca );
					dl.text( sx + pad + cb_size + 6.0f, cb_y + ( 18.0f - lh ) * 0.5f, "filled", text_col );
				}

				dl.pop_clip( );
			}

			[[nodiscard]] bool was_changed( ) const { return this->m_changed; }
			void clear_changed( ) { this->m_changed = false; }

		private:
			[[nodiscard]] rect get_popup( ) const
			{
				const auto pad{ 8.0f };
				const auto bar_w{ 14.0f };
				const auto bar_spacing{ 8.0f };
				const auto hue_bar_h{ 14.0f };
				const auto sv_size{ 170.0f };
				const auto cb_row_h = this->m_filled ? ( bar_spacing + 18.0f ) : 0.0f;
				const auto w = this->m_show_alpha ? ( pad + sv_size + bar_spacing + bar_w + pad ) : ( pad + sv_size + pad );
				const auto h = pad + sv_size + bar_spacing + hue_bar_h + cb_row_h + pad;
				const auto [vw, vh] = xdraw::viewport_size( );
				auto px = this->m_anchor.x;
				if ( vw > 0 && px + w > static_cast< float >( vw ) - 10.0f )
				{
					px = static_cast< float >( vw ) - 10.0f - w;
				}
				if ( px < 10.0f ) px = 10.0f;
				auto py = this->m_anchor.bottom( ) + 2.0f;
				if ( vh > 0 && py + h > static_cast< float >( vh ) - 10.0f )
				{
					py = this->m_anchor.y - h - 2.0f;
				}
				if ( py < 10.0f ) py = 10.0f;
				return { px, py, w, h };
			}

			xdraw::color* m_col{};
			float m_hue{};
			float m_sat{};
			float m_val{};
			int m_active{};
			bool m_show_alpha{};
			bool* m_filled{};
			float m_open_anim{};
			bool m_changed{};
		};

		class color_context_overlay : public overlay
		{
		public:
			color_context_overlay( std::uintptr_t id, const rect& anchor, xdraw::color* col, bool show_alpha ) : overlay{ id, anchor }, m_col{ col }, m_show_alpha{ show_alpha }
			{
				this->m_hover_anims.fill( 0.0f );
				this->m_item_anims.fill( 0.0f );

				const auto clip = clipboard_paste( get_hwnd( ) );
				const auto parsed = hex_to_color( clip );
				this->m_can_paste = parsed.has_value( );

				if ( this->m_can_paste )
				{
					this->m_paste_color = *parsed;
					this->m_paste_hex = clip;
				}
			}

			[[nodiscard]] bool hit_test( float x, float y ) const override
			{
				return this->get_popup( ).contains( x, y );
			}

			bool process_input( const input_state& input ) override
			{
				if ( this->m_closing )
				{
					return false;
				}

				const auto popup = this->get_popup( );

				if ( ( input.mouse_clicked || input.rmb_clicked ) && !popup.contains( input.mouse_x, input.mouse_y ) )
				{
					this->m_closing = true;
					return true;
				}

				if ( input.mouse_clicked && popup.contains( input.mouse_x, input.mouse_y ) )
				{
					for ( int i = 0; i < k_item_count; ++i )
					{
						if ( i == 1 && !this->m_can_paste )
						{
							continue;
						}

						const auto ir = this->get_item_rect( popup, i );

						if ( ir.contains( input.mouse_x, input.mouse_y ) )
						{
							if ( i == 0 && this->m_col )
							{
								const auto hex = color_to_hex( *this->m_col, this->m_show_alpha );
								clipboard_copy( get_hwnd( ), hex );
							}
							else if ( i == 1 && this->m_col )
							{
								*this->m_col = this->m_paste_color;
								this->m_changed = true;
							}

							this->m_closing = true;
							return true;
						}
					}
				}

				return popup.contains( input.mouse_x, input.mouse_y );
			}

			void render( const style& style, const input_state& input ) override
			{
				const auto dt = xdraw::delta_time( );
				const auto popup = this->get_popup( );
				auto& dl = xdraw::get( xdraw::layer::top );

				const auto speed = this->m_closing ? 18.0f : 16.0f;
				const auto target = this->m_closing ? 0.0f : 1.0f;
				this->m_open_anim += ( target - this->m_open_anim ) * std::min( speed * dt, 1.0f );

				if ( this->m_open_anim < 0.01f && this->m_closing )
				{
					this->m_closed = true;
					return;
				}

				const auto ease_t = ease::out_cubic( this->m_open_anim );
				const auto alpha_mult = ease_t;
				const auto animated_h = popup.h * ease_t;
				const auto pr = style.popup_rounding;

				auto bg = style.popup_bg;
				bg.a = static_cast< std::uint8_t >( bg.a * alpha_mult );
				auto border = lighten( style.popup_border, 1.1f );
				border.a = static_cast< std::uint8_t >( border.a * alpha_mult );

				dl.rect_filled( popup.x, popup.y, popup.w, animated_h, bg, xdraw::corner_radius{ pr } );

				if ( border.a > 0 )
				{
					dl.rect( popup.x, popup.y, popup.w, animated_h, border, xdraw::corner_radius{ pr } );
				}

				dl.push_clip( popup.x, popup.y, popup.w, animated_h );

				static constexpr const char* labels[ k_item_count ]{ "copy", "paste" };

				for ( int i = 0; i < k_item_count; ++i )
				{
					const auto disabled = ( i == 1 && !this->m_can_paste );
					const auto ir = this->get_item_rect( popup, i );

					const auto item_delay = i * 0.06f;
					const auto item_progress = std::clamp( this->m_open_anim - item_delay, 0.0f, 1.0f ) / ( 1.0f - std::min( item_delay, 0.3f ) );
					auto& ia = this->m_item_anims[ i ];
					ia = std::min( ia + 20.0f * dt, item_progress );

					const auto item_ease = ease::out_cubic( ia );
					const auto item_alpha = item_ease * alpha_mult;
					const auto slide = ( 1.0f - item_ease ) * 6.0f;

					const auto is_hovered = !disabled && !this->m_closing && ir.contains( input.mouse_x, input.mouse_y );
					auto& ha = this->m_hover_anims[ i ];
					ha += ( ( is_hovered ? 1.0f : 0.0f ) - ha ) * std::min( 18.0f * dt, 1.0f );

					const auto is_first = ( i == 0 );
					const auto is_last = ( i == k_item_count - 1 );

					if ( ha > 0.01f )
					{
						auto hov = style.combo_popup_item_hovered;
						hov.a = static_cast< std::uint8_t >( hov.a * item_alpha * ha );
						dl.rect_filled( ir.x, ir.y + slide, ir.w, ir.h, hov, xdraw::corner_radius{ is_first ? pr : 0.0f, is_first ? pr : 0.0f, is_last ? pr : 0.0f, is_last ? pr : 0.0f } );
					}

					const auto [tw, th] = xdraw::measure_text( labels[ i ] );
					auto text_col = disabled ? style.text_dim : style.text;
					text_col = lerp( text_col, lighten( text_col, 1.3f ), ha );
					text_col.a = static_cast< std::uint8_t >( text_col.a * item_alpha );

					dl.text( ir.x + 8.0f, ir.y + ( k_item_h - th ) * 0.5f + slide, labels[ i ], text_col );

					if ( i == 0 && this->m_col )
					{
						const auto hex = color_to_hex( *this->m_col, this->m_show_alpha );
						const auto [hw, hh] = xdraw::measure_text( hex );
						auto hex_col = style.text_dim;
						hex_col.a = static_cast< std::uint8_t >( hex_col.a * item_alpha );
						dl.text( ir.right( ) - hw - 8.0f, ir.y + ( k_item_h - hh ) * 0.5f + slide, hex, hex_col );
					}
					else if ( i == 1 && this->m_can_paste )
					{
						const auto swatch_size = k_item_h - 8.0f;
						const auto sx = ir.right( ) - swatch_size - 8.0f;
						const auto sy = ir.y + ( k_item_h - swatch_size ) * 0.5f + slide;

						auto swatch_col = this->m_paste_color;
						swatch_col.a = static_cast< std::uint8_t >( std::min( 255.0f, swatch_col.a * item_alpha ) );
						dl.rect_filled( sx, sy, swatch_size, swatch_size, swatch_col, xdraw::corner_radius{ 3.0f } );

						const auto [hw, hh] = xdraw::measure_text( this->m_paste_hex );
						auto hex_col = style.text_dim;
						hex_col.a = static_cast< std::uint8_t >( hex_col.a * item_alpha );
						dl.text( sx - hw - 4.0f, ir.y + ( k_item_h - hh ) * 0.5f + slide, this->m_paste_hex, hex_col );
					}
				}

				dl.pop_clip( );
			}

			[[nodiscard]] bool was_changed( ) const { return this->m_changed; }

		private:
			static constexpr auto k_item_count{ 2 };
			static constexpr auto k_item_h{ 24.0f };
			static constexpr auto k_pad{ 4.0f };
			static constexpr auto k_popup_w{ 160.0f };

			[[nodiscard]] rect get_popup( ) const
			{
				const auto h = k_pad * 2.0f + k_item_h * static_cast< float >( k_item_count );
				return { this->m_anchor.x, this->m_anchor.y, k_popup_w, h };
			}

			[[nodiscard]] rect get_item_rect( const rect& popup, int index ) const
			{
				return { popup.x + k_pad, popup.y + k_pad + static_cast< float >( index ) * k_item_h, popup.w - k_pad * 2.0f, k_item_h };
			}

			xdraw::color* m_col{};
			bool m_show_alpha{};
			float m_open_anim{};
			bool m_changed{};
			bool m_can_paste{};
			xdraw::color m_paste_color{};
			std::string m_paste_hex{};
			std::array<float, k_item_count> m_hover_anims{};
			std::array<float, k_item_count> m_item_anims{};
		};

	} // the color_picker namespace

	bool color_picker( std::string_view label, xdraw::color& col, float width, bool show_alpha, bool* filled )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return false;
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto [display, full] = parse_label( label );
		const auto& s = c.style;
		const auto& input = c.input;

		const auto is_open = overlays::is_open( id );
		auto changed{ false };

		if ( auto popup = dynamic_cast< color_picker_overlay* >( overlays::find( id ) ) )
		{
			if ( popup->was_changed( ) )
			{
				changed = true;
			}

			popup->clear_changed( );
		}

		const auto ctx_id = id + 100;
		const auto ctx_is_open = overlays::is_open( ctx_id );

		if ( auto ctx_popup = dynamic_cast< color_context_overlay* >( overlays::find( ctx_id ) ) )
		{
			if ( ctx_popup->was_changed( ) )
			{
				changed = true;
			}
		}

		const auto sw = s.swatch_w;
		const auto sh = s.swatch_h;
		const auto has_label = !display.empty( );

		auto label_w{ 0.0f };
		auto label_h{ 0.0f };

		if ( has_label )
		{
			auto [w, h] = xdraw::measure_text( display );
			label_w = w;
			label_h = h;
		}

		const auto total_w = has_label ? ( sw + s.item_spacing_x + label_w ) : sw;
		const auto total_h = has_label ? std::max( sh, label_h ) : sh;

		const auto abs = layout::item( total_w, total_h );
		auto x_offset{ 0.0f };

		if ( width > 0.0f )
		{
			x_offset = width - total_w;
		}

		const auto swatch_y = has_label ? ( abs.y + ( total_h - sh ) * 0.5f ) : abs.y;
		const auto swatch_rect = rect{ abs.x + x_offset, swatch_y, sw, sh };

		const auto can_interact = !c.overlay_blocking( ) || is_open;
		const auto hovered = can_interact && ( input.in_rect( swatch_rect ) || ( has_label && input.in_rect( abs ) ) );

		if ( hovered && !is_open && !ctx_is_open )
		{
			set_hovered_tooltip( label );
		}

		if ( is_open )
		{
			overlays::touch( id );

			if ( auto popup = dynamic_cast< color_picker_overlay* >( overlays::find( id ) ) )
			{
				popup->update_anchor( swatch_rect );
				popup->update_filled( filled );
			}
		}

		if ( ctx_is_open )
		{
			overlays::touch( ctx_id );
		}

		if ( can_interact && input.in_rect( swatch_rect ) && input.rmb_clicked )
		{
			if ( ctx_is_open )
			{
				overlays::close( ctx_id );
			}
			else if ( !c.overlay_blocking( ) || ctx_is_open )
			{
				const auto mouse_anchor = rect{ input.mouse_x, input.mouse_y, 0.0f, 0.0f };
				get_overlays( ).list.push_back( std::make_unique<color_context_overlay>( ctx_id, mouse_anchor, &col, show_alpha ) );
			}
		}

		if ( hovered && input.mouse_clicked )
		{
			if ( is_open )
			{
				overlays::close( id );
			}
			else if ( !c.overlay_blocking( ) )
			{
				get_overlays( ).list.push_back( std::make_unique<color_picker_overlay>( id, swatch_rect, &col, show_alpha, filled ) );
			}
		}

		const auto hover_anim = anim::lerp( id + 2, hovered ? 1.0f : 0.0f, 12.0f );
		const auto open_anim = anim::lerp( id + 3, is_open ? 1.0f : 0.0f, 12.0f );
		const auto r = s.color_swatch_rounding;

		auto& dl = draw::current( );

		if ( col.a < 255 )
		{
			constexpr auto checker_size{ 4.0f };
			const auto dark_checker = xdraw::color{ 180, 180, 180, 255 };
			const auto light_checker = xdraw::color{ 220, 220, 220, 255 };

			dl.rect_filled( swatch_rect.x, swatch_rect.y, swatch_rect.w, swatch_rect.h, dark_checker, xdraw::corner_radius{ r } );

			for ( float cy = swatch_rect.y; cy < swatch_rect.bottom( ); cy += checker_size )
			{
				for ( float cx = swatch_rect.x; cx < swatch_rect.right( ); cx += checker_size )
				{
					const auto ix = static_cast< int >( ( cx - swatch_rect.x ) / checker_size );
					const auto iy = static_cast< int >( ( cy - swatch_rect.y ) / checker_size );

					if ( ( ix + iy ) % 2 != 0 )
					{
						const auto cw = std::min( checker_size, swatch_rect.right( ) - cx );
						const auto ch = std::min( checker_size, swatch_rect.bottom( ) - cy );

						const auto touches_tl = ( cx < swatch_rect.x + r && cy < swatch_rect.y + r );
						const auto touches_tr = ( cx + cw > swatch_rect.right( ) - r && cy < swatch_rect.y + r );
						const auto touches_bl = ( cx < swatch_rect.x + r && cy + ch > swatch_rect.bottom( ) - r );
						const auto touches_br = ( cx + cw > swatch_rect.right( ) - r && cy + ch > swatch_rect.bottom( ) - r );

						if ( !touches_tl && !touches_tr && !touches_bl && !touches_br )
						{
							dl.rect_filled( cx, cy, cw, ch, light_checker );
						}
					}
				}
			}
		}

		dl.rect_filled( swatch_rect.x, swatch_rect.y, swatch_rect.w, swatch_rect.h, col, xdraw::corner_radius{ r } );

		if ( has_label )
		{
			const auto lx = swatch_rect.right( ) + s.item_spacing_x;
			const auto ly = abs.y + ( total_h - label_h ) * 0.5f;
			const auto available_w = win->bounds.right( ) - lx - s.window_pad_x;
			const auto label_text = truncate( display, available_w );
			const auto label_col = lerp( s.text_dim, s.text, std::max( hover_anim, open_anim ) );
			dl.text( lx, ly, label_text, label_col );
		}

		return changed;
	}

	namespace {

		struct text_input_state
		{
			std::size_t cursor{};
			std::size_t sel_start{};
			std::size_t sel_end{};
			float blink_timer{};
			float scroll_offset{};
			std::unordered_map<int, float> key_repeat_timers{};
			std::unordered_map<int, bool> key_was_down{};
		};

		std::unordered_map<std::uintptr_t, text_input_state>& get_text_input_states( )
		{
			static std::unordered_map<std::uintptr_t, text_input_state> s{};
			return s;
		}

	} // the text_input namespace

	bool text_input( std::string_view label, std::string& buf, std::size_t max_len, std::string_view hint )
	{
		auto win = layout::current_window( );
		if ( !win )
		{
			return false;
		}

		auto& c = get_ctx( );
		const auto id = make_id( label );
		const auto& s = c.style;
		const auto& input = c.input;
		auto changed = false;

		auto& states = get_text_input_states( );
		auto& st = states[ id ];

		const auto is_active = ( c.active_text_input == id );
		const auto [avail_w, avail_h] = layout::avail( );
		const auto input_h = s.text_input_h;

		const auto abs = layout::item( avail_w, input_h );
		const auto frame = rect{ abs.x, abs.y, avail_w, input_h };

		const auto can_interact = !c.overlay_blocking( );
		const auto hovered = can_interact && input.in_rect( frame );
		const auto clicked = hovered && input.mouse_clicked;

		if ( hovered && !is_active )
		{
			set_hovered_tooltip( label );
		}

		if ( clicked )
		{
			c.active_text_input = id;
			st.key_was_down.clear( );
			st.key_repeat_timers.clear( );

			const auto text_start_x = frame.x + s.frame_pad_x - st.scroll_offset;
			std::size_t best_pos{ 0 };
			auto best_dist = std::abs( input.mouse_x - text_start_x );

			for ( std::size_t i = 1; i <= buf.size( ); ++i )
			{
				if ( i < buf.size( ) && ( static_cast< unsigned char >( buf[ i ] ) & 0xC0 ) == 0x80 )
				{
					continue;
				}
				const auto [tw, th] = xdraw::measure_text( std::string_view{ buf.data( ), i } );
				const auto dist = std::abs( input.mouse_x - ( text_start_x + tw ) );

				if ( dist < best_dist )
				{
					best_dist = dist;
					best_pos = i;
				}
			}

			st.cursor = best_pos;
			st.sel_start = best_pos;
			st.sel_end = best_pos;
			st.blink_timer = 0.0f;
		}

		if ( is_active && input.mouse_clicked && !hovered )
		{
			c.active_text_input = null_id;
		}

		if ( is_active && hovered && input.mouse_down )
		{
			const auto text_start_x = frame.x + s.frame_pad_x - st.scroll_offset;
			std::size_t best_pos{ 0 };
			auto best_dist = std::abs( input.mouse_x - text_start_x );

			for ( std::size_t i = 1; i <= buf.size( ); ++i )
			{
				if ( i < buf.size( ) && ( static_cast< unsigned char >( buf[ i ] ) & 0xC0 ) == 0x80 )
				{
					continue;
				}
				const auto [tw, th] = xdraw::measure_text( std::string_view{ buf.data( ), i } );
				const auto dist = std::abs( input.mouse_x - ( text_start_x + tw ) );

				if ( dist < best_dist )
				{
					best_dist = dist;
					best_pos = i;
				}
			}

			st.sel_end = best_pos;
			st.cursor = best_pos;
			st.blink_timer = 0.0f;
		}

		if ( is_active )
		{
			const auto dt = xdraw::delta_time( );
			const auto shift = input.shift_held( );
			const auto ctrl = input.ctrl_held( );

			const auto has_sel = st.sel_start != st.sel_end;
			const auto sel_min = std::min( st.sel_start, st.sel_end );
			const auto sel_max = std::max( st.sel_start, st.sel_end );

			auto process_key = [ & ]( int vk ) -> bool
				{
					for ( const auto pk : input.key_presses( ) )
					{
						if ( pk == vk )
						{
							return true;
						}
					}

					const auto is_down = input.key_down( vk );
					st.key_was_down[ vk ] = is_down;

					if ( !is_down )
					{
						st.key_repeat_timers[ vk ] = 0.0f;
						return false;
					}

					st.key_repeat_timers[ vk ] += dt;
					constexpr auto delay = 0.4f;
					constexpr auto rate = 0.03f;

					if ( st.key_repeat_timers[ vk ] >= delay )
					{
						const auto excess = st.key_repeat_timers[ vk ] - delay;
						if ( static_cast< int >( excess / rate ) > static_cast< int >( ( excess - dt ) / rate ) )
						{
							return true;
						}
					}

					return false;
				};

			auto utf8_encode = []( wchar_t wch ) -> std::string
				{
					std::string out;
					const auto cp = static_cast< std::uint32_t >( wch );
					if ( cp < 0x80 )
					{
						out.push_back( static_cast< char >( cp ) );
					}
					else if ( cp < 0x800 )
					{
						out.push_back( static_cast< char >( 0xC0 | ( ( cp >> 6 ) & 0x1F ) ) );
						out.push_back( static_cast< char >( 0x80 | ( cp & 0x3F ) ) );
					}
					else if ( cp < 0x10000 )
					{
						out.push_back( static_cast< char >( 0xE0 | ( ( cp >> 12 ) & 0x0F ) ) );
						out.push_back( static_cast< char >( 0x80 | ( ( cp >> 6 ) & 0x3F ) ) );
						out.push_back( static_cast< char >( 0x80 | ( cp & 0x3F ) ) );
					}
					else
					{
						out.push_back( static_cast< char >( 0xF0 | ( ( cp >> 18 ) & 0x07 ) ) );
						out.push_back( static_cast< char >( 0x80 | ( ( cp >> 12 ) & 0x3F ) ) );
						out.push_back( static_cast< char >( 0x80 | ( ( cp >> 6 ) & 0x3F ) ) );
						out.push_back( static_cast< char >( 0x80 | ( cp & 0x3F ) ) );
					}
					return out;
				};

			if ( process_key( VK_LEFT ) )
			{
				st.blink_timer = 0.0f;

				if ( ctrl )
				{
					while ( st.cursor > 0 && buf[ st.cursor - 1 ] == ' ' ) { st.cursor--; }
					while ( st.cursor > 0 && buf[ st.cursor - 1 ] != ' ' ) { st.cursor--; }
				}
				else if ( has_sel && !shift )
				{
					st.cursor = sel_min;
				}
				else if ( st.cursor > 0 )
				{
					st.cursor--;
					while ( st.cursor > 0 && ( static_cast< unsigned char >( buf[ st.cursor ] ) & 0xC0 ) == 0x80 )
					{
						st.cursor--;
					}
				}

				if ( shift )
				{
					st.sel_end = st.cursor;
				}
				else
				{
					st.sel_start = st.cursor;
					st.sel_end = st.cursor;
				}
			}

			if ( process_key( VK_RIGHT ) )
			{
				st.blink_timer = 0.0f;

				if ( ctrl )
				{
					while ( st.cursor < buf.size( ) && buf[ st.cursor ] != ' ' ) { st.cursor++; }
					while ( st.cursor < buf.size( ) && buf[ st.cursor ] == ' ' ) { st.cursor++; }
				}
				else if ( has_sel && !shift )
				{
					st.cursor = sel_max;
				}
				else if ( st.cursor < buf.size( ) )
				{
					st.cursor++;
					while ( st.cursor < buf.size( ) && ( static_cast< unsigned char >( buf[ st.cursor ] ) & 0xC0 ) == 0x80 )
					{
						st.cursor++;
					}
				}

				if ( shift )
				{
					st.sel_end = st.cursor;
				}
				else
				{
					st.sel_start = st.cursor;
					st.sel_end = st.cursor;
				}
			}

			if ( process_key( VK_HOME ) )
			{
				st.blink_timer = 0.0f;
				st.cursor = 0;

				if ( shift )
				{
					st.sel_end = 0;
				}
				else
				{
					st.sel_start = 0;
					st.sel_end = 0;
				}
			}

			if ( process_key( VK_END ) )
			{
				st.blink_timer = 0.0f;
				st.cursor = buf.size( );

				if ( shift )
				{
					st.sel_end = buf.size( );
				}
				else
				{
					st.sel_start = buf.size( );
					st.sel_end = buf.size( );
				}
			}

			if ( ctrl && process_key( 'A' ) )
			{
				st.sel_start = 0;
				st.sel_end = buf.size( );
				st.cursor = buf.size( );
			}

			if ( ctrl && process_key( 'C' ) && has_sel )
			{
				const auto sel_str = buf.substr( sel_min, sel_max - sel_min );
				const auto needed = MultiByteToWideChar( CP_UTF8, 0, sel_str.c_str( ), -1, nullptr, 0 );
				if ( needed > 0 && OpenClipboard( nullptr ) )
				{
					EmptyClipboard( );
					auto h_mem = GlobalAlloc( GMEM_MOVEABLE, needed * sizeof( wchar_t ) );
					if ( h_mem )
					{
						auto* p = static_cast< wchar_t* >( GlobalLock( h_mem ) );
						if ( p )
						{
							MultiByteToWideChar( CP_UTF8, 0, sel_str.c_str( ), -1, p, needed );
							GlobalUnlock( h_mem );
							SetClipboardData( CF_UNICODETEXT, h_mem );
						}
					}
					CloseClipboard( );
				}
			}

			if ( ctrl && process_key( 'V' ) )
			{
				if ( OpenClipboard( nullptr ) )
				{
					auto h_data = GetClipboardData( CF_UNICODETEXT );
					if ( h_data )
					{
						const auto* wstr = static_cast< const wchar_t* >( GlobalLock( h_data ) );
						if ( wstr )
						{
							const auto wlen = wcslen( wstr );
							const auto needed = WideCharToMultiByte( CP_UTF8, 0, wstr, static_cast< int >( wlen ), nullptr, 0, nullptr, nullptr );
							if ( needed > 0 )
							{
								std::string paste_utf8( needed, '\0' );
								WideCharToMultiByte( CP_UTF8, 0, wstr, static_cast< int >( wlen ), paste_utf8.data( ), needed, nullptr, nullptr );
								if ( has_sel )
								{
									buf.erase( sel_min, sel_max - sel_min );
									st.cursor = sel_min;
								}
								const auto room = ( max_len > buf.size( ) ) ? ( max_len - buf.size( ) ) : 0;
								if ( room > 0 )
								{
									if ( paste_utf8.size( ) > room ) paste_utf8.resize( room );
									buf.insert( st.cursor, paste_utf8 );
									st.cursor += paste_utf8.size( );
									st.sel_start = st.cursor;
									st.sel_end = st.cursor;
									changed = true;
								}
							}
							GlobalUnlock( h_data );
						}
					}
					CloseClipboard( );
				}
			}

			if ( process_key( VK_BACK ) )
			{
				st.blink_timer = 0.0f;

				if ( has_sel )
				{
					buf.erase( sel_min, sel_max - sel_min );
					st.cursor = sel_min;
					changed = true;
				}
				else if ( st.cursor > 0 )
				{
					if ( ctrl )
					{
						auto es = st.cursor;
						while ( es > 0 && buf[ es - 1 ] == ' ' ) { es--; }
						while ( es > 0 && buf[ es - 1 ] != ' ' ) { es--; }
						buf.erase( es, st.cursor - es );
						st.cursor = es;
					}
					else
					{
						auto prev = st.cursor - 1;
						while ( prev > 0 && ( static_cast< unsigned char >( buf[ prev ] ) & 0xC0 ) == 0x80 )
						{
							prev--;
						}
						buf.erase( prev, st.cursor - prev );
						st.cursor = prev;
					}

					changed = true;
				}

				st.sel_start = st.cursor;
				st.sel_end = st.cursor;
			}

			if ( process_key( VK_DELETE ) )
			{
				st.blink_timer = 0.0f;

				if ( has_sel )
				{
					buf.erase( sel_min, sel_max - sel_min );
					st.cursor = sel_min;
					changed = true;
				}
				else if ( st.cursor < buf.size( ) )
				{
					if ( ctrl )
					{
						auto ee = st.cursor;
						while ( ee < buf.size( ) && buf[ ee ] != ' ' ) { ee++; }
						while ( ee < buf.size( ) && buf[ ee ] == ' ' ) { ee++; }
						buf.erase( st.cursor, ee - st.cursor );
					}
					else
					{
						auto next = st.cursor + 1;
						while ( next < buf.size( ) && ( static_cast< unsigned char >( buf[ next ] ) & 0xC0 ) == 0x80 )
						{
							next++;
						}
						buf.erase( st.cursor, next - st.cursor );
					}

					changed = true;
				}

				st.sel_start = st.cursor;
				st.sel_end = st.cursor;
			}

			if ( process_key( VK_ESCAPE ) || process_key( VK_RETURN ) )
			{
				c.active_text_input = null_id;
			}

			for ( const auto wch : input.chars( ) )
			{
				if ( wch < 32 || wch == 127 )
				{
					continue;
				}

				const auto u8 = utf8_encode( wch );
				if ( buf.size( ) + u8.size( ) <= max_len )
				{
					st.blink_timer = 0.0f;

					if ( has_sel )
					{
						buf.erase( sel_min, sel_max - sel_min );
						st.cursor = sel_min;
					}

					buf.insert( st.cursor, u8 );
					st.cursor += u8.size( );
					st.sel_start = st.cursor;
					st.sel_end = st.cursor;
					changed = true;
				}
			}

			st.cursor = std::min( st.cursor, buf.size( ) );
			st.sel_start = std::min( st.sel_start, buf.size( ) );
			st.sel_end = std::min( st.sel_end, buf.size( ) );
		}

		const auto dt = xdraw::delta_time( );
		const auto hover_anim = anim::lerp( id, hovered ? 1.0f : 0.0f, 12.0f );
		const auto active_anim = anim::lerp( id + 1, is_active ? 1.0f : 0.0f, 12.0f );

		if ( is_active )
		{
			st.blink_timer += dt;

			if ( st.blink_timer > 1.0f )
			{
				st.blink_timer -= 1.0f;
			}
		}

		const auto r = s.text_input_rounding;
		auto border = lerp( s.text_input_border, lighten( s.text_input_border, 1.3f ), hover_anim );
		border = lerp( border, s.accent, active_anim );
		auto bg = lerp( s.text_input_bg, lighten( s.text_input_bg, 1.05f ), hover_anim );
		bg = lerp( bg, lighten( s.text_input_bg, 1.08f ), active_anim );

		auto& dl = draw::current( );
		dl.rect_filled( frame.x, frame.y, frame.w, frame.h, bg, xdraw::corner_radius{ r } );
		dl.rect( frame.x, frame.y, frame.w, frame.h, border, xdraw::corner_radius{ r } );

		const auto text_pad = s.frame_pad_x;
		const auto text_area_w = frame.w - text_pad * 2.0f;
		auto [tw, th] = buf.empty( ) ? xdraw::measure_text( "A" ) : xdraw::measure_text( buf );

		if ( buf.empty( ) )
		{
			tw = 0.0f;
		}

		if ( is_active )
		{
			const auto [co, coh] = st.cursor == 0 ? std::pair{ 0.0f, 0.0f } : xdraw::measure_text( std::string_view{ buf.data( ), st.cursor } );

			if ( co < st.scroll_offset )
			{
				st.scroll_offset = co;
			}
			else if ( co > st.scroll_offset + text_area_w - 2.0f )
			{
				st.scroll_offset = co - text_area_w + 2.0f;
			}

			st.scroll_offset = std::max( 0.0f, st.scroll_offset );
		}

		dl.push_clip( frame.x + text_pad, frame.y, text_area_w, frame.h );

		const auto text_x = frame.x + text_pad - st.scroll_offset;
		const auto text_y = frame.y + ( frame.h - th ) * 0.5f;

		if ( is_active && st.sel_start != st.sel_end )
		{
			const auto sm = std::min( st.sel_start, st.sel_end );
			const auto sx_val = std::max( st.sel_start, st.sel_end );
			const auto [sw_start, sh_start] = sm == 0 ? std::pair{ 0.0f, 0.0f } : xdraw::measure_text( std::string_view{ buf.data( ), sm } );
			const auto [sw_end, sh_end] = xdraw::measure_text( std::string_view{ buf.data( ), sx_val } );
			auto sel_col = s.accent;
			sel_col.a = 100;
			dl.rect_filled( text_x + sw_start, text_y - 1.0f, sw_end - sw_start, th + 2.0f, sel_col );
		}

		const auto ti_text = lerp( s.text_dim, s.text, std::max( hover_anim, active_anim ) );

		if ( buf.empty( ) && !is_active && !hint.empty( ) )
		{
			auto hint_col = ti_text;
			hint_col.a = 100;
			dl.text( frame.x + text_pad, text_y, hint, hint_col );
		}
		else if ( !buf.empty( ) )
		{
			dl.text( text_x, text_y, buf, ti_text );
		}

		if ( is_active )
		{
			const auto [co, coh] = st.cursor == 0 ? std::pair{ 0.0f, 0.0f } : xdraw::measure_text( std::string_view{ buf.data( ), st.cursor } );
			const auto cursor_x = text_x + co;
			const auto cursor_h = th;
			const auto ba = std::sin( st.blink_timer * 6.28318f ) * 0.5f + 0.5f;
			auto cursor_col = s.text;
			cursor_col.a = static_cast< std::uint8_t >( 255.0f * ( 0.4f + 0.6f * ba ) );
			dl.rect_filled( cursor_x, text_y, 1.0f, cursor_h, cursor_col );
		}

		dl.pop_clip( );

		return changed;
	}

} // namespace xui
