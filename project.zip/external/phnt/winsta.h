/*
 * Window Station Support functions
 *
 * This file is part of System Informer.
 */

#ifndef _WINSTA_H
#define _WINSTA_H

//
// Sessions
//

// Specifies the current server.
#define WINSTATION_CURRENT_SERVER         ((HANDLE)NULL)
#define WINSTATION_CURRENT_SERVER_HANDLE  ((HANDLE)NULL)
#define WINSTATION_CURRENT_SERVER_NAME    (NULL)
#define SERVERNAME_CURRENT ((PWSTR)NULL)

// Specifies the current session (SessionId)
#define WINSTATION_CURRENT_SESSION ((ULONG)-1)
#define LOGONID_CURRENT (-1)

// Specifies any-session (SessionId)
#define WINSTATION_ANY_SESSION ((ULONG)-2)

//
// Access rights
//

#define WINSTATION_QUERY 0x00000001 // WinStationQueryInformation
#define WINSTATION_SET 0x00000002 // WinStationSetInformation
#define WINSTATION_RESET 0x00000004 // WinStationReset
#define WINSTATION_VIRTUAL 0x00000008 //read/write direct data
#define WINSTATION_SHADOW 0x00000010 // WinStationShadow
#define WINSTATION_LOGON 0x00000020 // logon to WinStation
#define WINSTATION_LOGOFF 0x00000040 // WinStationLogoff
#define WINSTATION_MSG 0x00000080 // WinStationMsg
#define WINSTATION_CONNECT 0x00000100 // WinStationConnect
#define WINSTATION_DISCONNECT 0x00000200 // WinStationDisconnect
#define WINSTATION_GUEST_ACCESS WINSTATION_LOGON

#define WINSTATION_CURRENT_GUEST_ACCESS (WINSTATION_VIRTUAL | WINSTATION_LOGOFF)
#define WINSTATION_USER_ACCESS (WINSTATION_GUEST_ACCESS | WINSTATION_QUERY | WINSTATION_CONNECT)
#define WINSTATION_CURRENT_USER_ACCESS \
    (WINSTATION_SET | WINSTATION_RESET | WINSTATION_VIRTUAL | \
    WINSTATION_LOGOFF | WINSTATION_DISCONNECT)
#define WINSTATION_ALL_ACCESS (STANDARD_RIGHTS_REQUIRED | WINSTATION_QUERY | \
    WINSTATION_SET | WINSTATION_RESET | WINSTATION_VIRTUAL | \
    WINSTATION_SHADOW | WINSTATION_LOGON | WINSTATION_MSG | \
    WINSTATION_CONNECT | WINSTATION_DISCONNECT)

#define WDPREFIX_LENGTH 12
#define CALLBACK_LENGTH 50
#define DLLNAME_LENGTH 32
#define CDNAME_LENGTH 32
#define WDNAME_LENGTH 32
#define PDNAME_LENGTH 32
#define DEVICENAME_LENGTH 128
#define MODEMNAME_LENGTH DEVICENAME_LENGTH
#define STACK_ADDRESS_LENGTH 128
#define MAX_BR_NAME 65
#define DIRECTORY_LENGTH 256
#define INITIALPROGRAM_LENGTH 256
#define USERNAME_LENGTH 20
#define DOMAIN_LENGTH 17
#define PASSWORD_LENGTH 14
#define NASISPECIFICNAME_LENGTH 14
#define NASIUSERNAME_LENGTH 47
#define NASIPASSWORD_LENGTH 24
#define NASISESSIONNAME_LENGTH 16
#define NASIFILESERVER_LENGTH 47

#define CLIENTDATANAME_LENGTH 7
#define CLIENTNAME_LENGTH 20
#define CLIENTADDRESS_LENGTH 30
#define IMEFILENAME_LENGTH 32
#define CLIENTLICENSE_LENGTH 32
#define CLIENTMODEM_LENGTH 40
#define CLIENT_PRODUCT_ID_LENGTH 32
#define MAX_COUNTER_EXTENSIONS 2
#define WINSTATIONNAME_LENGTH 32

#define TERMSRV_TOTAL_SESSIONS 1
#define TERMSRV_DISC_SESSIONS 2
#define TERMSRV_RECON_SESSIONS 3
#define TERMSRV_CURRENT_ACTIVE_SESSIONS 4
#define TERMSRV_CURRENT_DISC_SESSIONS 5
#define TERMSRV_PENDING_SESSIONS 6
#define TERMSRV_SUCC_TOTAL_LOGONS 7
#define TERMSRV_SUCC_LOCAL_LOGONS 8
#define TERMSRV_SUCC_REMOTE_LOGONS 9
#define TERMSRV_SUCC_SESSION0_LOGONS 10
#define TERMSRV_CURRENT_TERMINATING_SESSIONS 11
#define TERMSRV_CURRENT_LOGGEDON_SESSIONS 12

typedef RTL_TIME_ZONE_INFORMATION TS_TIME_ZONE_INFORMATION, *PTS_TIME_ZONE_INFORMATION;

typedef WCHAR WINSTATIONNAME[WINSTATIONNAME_LENGTH + 1];

// Variable length data descriptor (not needed)
typedef struct _VARDATA_WIRE
{
    USHORT Size;
    USHORT Offset;
} VARDATA_WIRE, *PVARDATA_WIRE;

typedef enum _WINSTATIONSTATECLASS
{
    State_Active = 0,
    State_Connected = 1,
    State_ConnectQuery = 2,
    State_Shadow = 3,
    State_Disconnected = 4,
    State_Idle = 5,
    State_Listen = 6,
    State_Reset = 7,
    State_Down = 8,
    State_Init = 9
} WINSTATIONSTATECLASS;

typedef struct _SESSIONIDW
{
    union
    {
        ULONG SessionId;
        ULONG LogonId;
    };
    WINSTATIONNAME WinStationName;
    WINSTATIONSTATECLASS State;
} SESSIONIDW, *PSESSIONIDW;

/**
 * The WINSTATIONINFOCLASS enumeration indicates the class of data for which to either query or set on the server. 
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/f333c223-de8a-46e1-a83e-79cbdab92371
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/1bba9ff2-71d3-49a3-bb26-2e5f6fcab3ee
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/2a5ee131-a1dd-44c7-9880-98df708061ea
 */
typedef enum _WINSTATIONINFOCLASS
{
    WinStationCreateData,                   // q: WINSTATIONCREATE
    WinStationConfiguration,                // qs: WINSTACONFIGWIRE + USERCONFIG
    WinStationPdParams,                     // qs: PDPARAMSWIRE + PDPARAMS
    WinStationWd,                           // q: WDCONFIG
    WinStationPd,                           // q: PDCONFIG2 + PDPARAMS
    WinStationPrinter,                      // qs: Not supported.
    WinStationClient,                       // q: VARDATA_WIRE + WINSTATIONCLIENT
    WinStationModules,                      // q:
    WinStationInformation,                  // q: WINSTATIONINFORMATION
    WinStationTrace,                        // s: TS_TRACE
    WinStationBeep,                         // s: BEEPINPUT // 10
    WinStationEncryptionOff,                // s:
    WinStationEncryptionPerm,               // s:
    WinStationNtSecurity,                   // s: (open secure desktop ctrl+alt+del)
    WinStationUserToken,                    // q: WINSTATIONUSERTOKEN
    WinStationUnused1,                      // qs: Not supported.
    WinStationVideoData,                    // q: WINSTATIONVIDEODATA
    WinStationInitialProgram,               // s: (set current process as initial program)
    WinStationCd,                           // q: CDCONFIG
    WinStationSystemTrace,                  // s: TS_TRACE
    WinStationVirtualData,                  // q: PVOID // 20
    WinStationClientData,                   // s: VARDATA_WIRE + WINSTATIONCLIENTDATA
    WinStationSecureDesktopEnter,           // qs:
    WinStationSecureDesktopExit,            // qs:
    WinStationLoadBalanceSessionTarget,     // q: ULONG
    WinStationLoadIndicator,                // q: WINSTATIONLOADINDICATORDATA
    WinStationShadowInfo,                   // qs: WINSTATIONSHADOW
    WinStationDigProductId,                 // q: WINSTATIONPRODID
    WinStationLockedState,                  // qs: BOOL
    WinStationRemoteAddress,                // q: WINSTATIONREMOTEADDRESS
    WinStationIdleTime,                     // q: ULONG // 30
    WinStationLastReconnectType,            // q: ULONG
    WinStationDisallowAutoReconnect,        // qs: BOOLEAN
    WinStationMprNotifyInfo,                // q:
    WinStationExecSrvSystemPipe,            // q: WCHAR[48]
    WinStationSmartCardAutoLogon,           // q: BOOLEAN
    WinStationIsAdminLoggedOn,              // q: BOOLEAN
    WinStationReconnectedFromId,            // q: ULONG
    WinStationEffectsPolicy,                // q: ULONG
    WinStationType,                         // q: ULONG
    WinStationInformationEx,                // q: VARDATA_WIRE + WINSTATIONINFORMATIONEX // 40
    WinStationValidationInfo,               // q:
    WinStationActivityId,                   // q: GUID
    MaxWinStationInfoClass
} WINSTATIONINFOCLASS;

/**
 * Retrieves general information used to create the terminal server session (protocol) to which the station belongs.
 */
typedef struct _WINSTATIONCREATE
{
    ULONG fEnableWinStation : 1;
    ULONG MaxInstanceCount;
} WINSTATIONCREATE, *PWINSTATIONCREATE;

typedef struct _WINSTACONFIGWIRE
{
    WCHAR Comment[61]; // The WinStation descriptive comment.
    CHAR OEMId[4]; // Value identifying the OEM implementer of the TermService Listener to which this session (WinStation) belongs. This can be any value defined by the implementer (OEM) of the listener.
    VARDATA_WIRE UserConfig; // VARDATA_WIRE structure defining the size and offset of the variable-length user configuration data succeeding it.
    VARDATA_WIRE NewFields; // VARDATA_WIRE structure defining the size and offset of the variable-length new data succeeding it. This field is not used and is a placeholder for any new data, if and when added.
} WINSTACONFIGWIRE, *PWINSTACONFIGWIRE;

typedef enum _CALLBACKCLASS
{
    Callback_Disable,
    Callback_Roving,
    Callback_Fixed
} CALLBACKCLASS;

/**
 * The SHADOWCLASS enumeration is used to indicate the shadow-related settings for a session running on a terminal server.
 */
typedef enum _SHADOWCLASS
{
    Shadow_Disable, // Shadowing is disabled.
    Shadow_EnableInputNotify, // Permission is asked first from the session being shadowed. The shadower is also permitted keyboard and mouse input.
    Shadow_EnableInputNoNotify, // Permission is not asked first from the session being shadowed. The shadower is also permitted keyboard and mouse input.
    Shadow_EnableNoInputNotify, // Permission is asked first from the session being shadowed. The shadower is not permitted keyboard and mouse input and MUST observe the shadowed session.
    Shadow_EnableNoInputNoNotify // Permission is not asked first from the session being shadowed. The shadower is not permitted keyboard and mouse input and MUST observe the shadowed session.
} SHADOWCLASS;

/**
 * The USERCONFIG structure indicates the user and session configuration for a specific terminal server session.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/dba750b8-cb35-4e88-9811-e2a1f8a10701
 */
typedef struct _USERCONFIG
{
    ULONG fInheritAutoLogon : 1;
    ULONG fInheritResetBroken : 1;
    ULONG fInheritReconnectSame : 1;
    ULONG fInheritInitialProgram : 1;
    ULONG fInheritCallback : 1;
    ULONG fInheritCallbackNumber : 1;
    ULONG fInheritShadow : 1;
    ULONG fInheritMaxSessionTime : 1;
    ULONG fInheritMaxDisconnectionTime : 1;
    ULONG fInheritMaxIdleTime : 1;
    ULONG fInheritAutoClient : 1;
    ULONG fInheritSecurity : 1;
    ULONG fPromptForPassword : 1;
    ULONG fResetBroken : 1;
    ULONG fReconnectSame : 1;
    ULONG fLogonDisabled : 1;
    ULONG fWallPaperDisabled : 1;
    ULONG fAutoClientDrives : 1;
    ULONG fAutoClientLpts : 1;
    ULONG fForceClientLptDef : 1;
    ULONG fRequireEncryption : 1;
    ULONG fDisableEncryption : 1;
    ULONG fUnused1 : 1;
    ULONG fHomeDirectoryMapRoot : 1;
    ULONG fUseDefaultGina : 1;
    ULONG fCursorBlinkDisabled : 1;
    ULONG fPublishedApp : 1;
    ULONG fHideTitleBar : 1;
    ULONG fMaximize : 1;
    ULONG fDisableCpm : 1;
    ULONG fDisableCdm : 1;
    ULONG fDisableCcm : 1;
    ULONG fDisableLPT : 1;
    ULONG fDisableClip : 1;
    ULONG fDisableExe : 1;
    ULONG fDisableCam : 1;
    ULONG fDisableAutoReconnect : 1;
    ULONG ColorDepth : 3;
    ULONG fInheritColorDepth : 1;
    ULONG fErrorInvalidProfile : 1;
    ULONG fPasswordIsScPin : 1;
    ULONG fDisablePNPRedir : 1;
    WCHAR UserName[USERNAME_LENGTH + 1];
    WCHAR Domain[DOMAIN_LENGTH + 1];
    WCHAR Password[PASSWORD_LENGTH + 1];
    WCHAR WorkDirectory[DIRECTORY_LENGTH + 1];
    WCHAR InitialProgram[INITIALPROGRAM_LENGTH + 1];
    WCHAR CallbackNumber[CALLBACK_LENGTH + 1];
    CALLBACKCLASS Callback;
    SHADOWCLASS Shadow;
    ULONG MaxConnectionTime;
    ULONG MaxDisconnectionTime;
    ULONG MaxIdleTime;
    ULONG KeyboardLayout;
    BYTE MinEncryptionLevel;
    WCHAR NWLogonServer[NASIFILESERVER_LENGTH + 1];
    WCHAR PublishedName[MAX_BR_NAME];
    WCHAR WFProfilePath[DIRECTORY_LENGTH + 1];
    WCHAR WFHomeDir[DIRECTORY_LENGTH + 1];
    WCHAR WFHomeDirDrive[4];
} USERCONFIG, *PUSERCONFIG;

typedef enum _SDCLASS
{
    SdNone = 0,
    SdConsole,
    SdNetwork,
    SdAsync,
    SdOemTransport
} SDCLASS;

typedef WCHAR DEVICENAME[DEVICENAME_LENGTH + 1];
typedef WCHAR MODEMNAME[MODEMNAME_LENGTH + 1];
typedef WCHAR NASISPECIFICNAME[NASISPECIFICNAME_LENGTH + 1];
typedef WCHAR NASIUSERNAME[NASIUSERNAME_LENGTH + 1];
typedef WCHAR NASIPASSWORD[NASIPASSWORD_LENGTH + 1];
typedef WCHAR NASISESIONNAME[NASISESSIONNAME_LENGTH + 1];
typedef WCHAR NASIFILESERVER[NASIFILESERVER_LENGTH + 1];
typedef WCHAR WDNAME[WDNAME_LENGTH + 1];
typedef WCHAR WDPREFIX[WDPREFIX_LENGTH + 1];
typedef WCHAR CDNAME[CDNAME_LENGTH + 1];
typedef WCHAR DLLNAME[DLLNAME_LENGTH + 1];
typedef WCHAR PDNAME[PDNAME_LENGTH + 1];

typedef struct _NETWORKCONFIG
{
    LONG LanAdapter;
    DEVICENAME NetworkName;
    ULONG Flags;
} NETWORKCONFIG, *PNETWORKCONFIG;

typedef enum _FLOWCONTROLCLASS
{
    FlowControl_None,
    FlowControl_Hardware,
    FlowControl_Software
} FLOWCONTROLCLASS;

typedef enum _RECEIVEFLOWCONTROLCLASS
{
    ReceiveFlowControl_None,
    ReceiveFlowControl_RTS,
    ReceiveFlowControl_DTR,
} RECEIVEFLOWCONTROLCLASS;

typedef enum _TRANSMITFLOWCONTROLCLASS
{
    TransmitFlowControl_None,
    TransmitFlowControl_CTS,
    TransmitFlowControl_DSR,
} TRANSMITFLOWCONTROLCLASS;

typedef enum _ASYNCCONNECTCLASS
{
    Connect_CTS,
    Connect_DSR,
    Connect_RI,
    Connect_DCD,
    Connect_FirstChar,
    Connect_Perm,
} ASYNCCONNECTCLASS;

typedef struct _FLOWCONTROLCONFIG
{
    ULONG fEnableSoftwareTx : 1;
    ULONG fEnableSoftwareRx : 1;
    ULONG fEnableDTR : 1;
    ULONG fEnableRTS : 1;
    CHAR XonChar;
    CHAR XoffChar;
    FLOWCONTROLCLASS Type;
    RECEIVEFLOWCONTROLCLASS HardwareReceive;
    TRANSMITFLOWCONTROLCLASS HardwareTransmit;
} FLOWCONTROLCONFIG, *PFLOWCONTROLCONFIG;

typedef struct _CONNECTCONFIG
{
    ASYNCCONNECTCLASS Type;
    ULONG fEnableBreakDisconnect : 1;
} CONNECTCONFIG, *PCONNECTCONFIG;

typedef struct _ASYNCCONFIG
{
    DEVICENAME DeviceName;
    MODEMNAME ModemName;
    ULONG BaudRate;
    ULONG Parity;
    ULONG StopBits;
    ULONG ByteSize;
    ULONG fEnableDsrSensitivity : 1;
    ULONG fConnectionDriver : 1;
    FLOWCONTROLCONFIG FlowControl;
    CONNECTCONFIG Connect;
} ASYNCCONFIG, *PASYNCCONFIG;

typedef struct _NASICONFIG
{
    NASISPECIFICNAME SpecificName;
    NASIUSERNAME UserName;
    NASIPASSWORD PassWord;
    NASISESIONNAME SessionName;
    NASIFILESERVER FileServer;
    BOOLEAN GlobalSession;
} NASICONFIG, *PNASICONFIG;

typedef struct _OEMTDCONFIG
{
    LONG Adapter;
    DEVICENAME DeviceName;
    ULONG Flags;
} OEMTDCONFIG, *POEMTDCONFIG;

/**
 * The PDPARAMS structure represents the transport protocol driver parameters.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/ff0e2998-fb8b-4dff-ab64-8427fad556eb
 */
typedef struct _PDPARAMS
{
    SDCLASS SdClass; // Stack driver class. Indicates which one of the union's structures is valid.
    union
    {
        NETWORKCONFIG Network; // Configuration of network drivers. Used if SdClass is SdNetwork.
        ASYNCCONFIG Async; // Configuration of async (modem) driver. Used if SdClass is SdAsync.
        NASICONFIG Nasi; // Reserved.
        OEMTDCONFIG OemTd; // Configuration of OEM transport driver. Used if SdClass is SdOemTransport.
    };
} PDPARAMS, *PPDPARAMS;

/**
 * The WDCONFIG structure represents the WinStation (session) driver configuration.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/d1bf099b-eb54-4ed9-a723-0b1062dbc128
 */
typedef struct _WDCONFIG
{
    WDNAME WdName; // The descriptive name of the WinStation driver.
    DLLNAME WdDLL; // The driver's image name.
    DLLNAME WsxDLL; // Used by the Terminal Services service to communicate with the WinStation driver.
    ULONG WdFlag; // Driver flags.
    ULONG WdInputBufferLength; // Length, in bytes, of the input buffer used by the driver. Defaults to 2048.
    DLLNAME CfgDLL; // Configuration DLL used by Terminal Services administrative tools for configuring the driver.
    WDPREFIX WdPrefix; // Used as the prefix of the WinStation name generated for the connected sessions with this WinStation driver.
} WDCONFIG, *PWDCONFIG;

/**
 * The PDCONFIG2 structure represents the protocol driver's software configuration.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/74204022-eb7c-4454-b3d0-24f642c892a4
 */
typedef struct _PDCONFIG2
{
    PDNAME PdName;
    SDCLASS SdClass;
    DLLNAME PdDLL;
    ULONG PdFlag;
    ULONG OutBufLength;
    ULONG OutBufCount;
    ULONG OutBufDelay;
    ULONG InteractiveDelay;
    ULONG PortNumber;
    ULONG KeepAliveTimeout;
} PDCONFIG2, *PPDCONFIG2;

/**
 * The WINSTATIONCLIENT structure defines the client-requested configuration when connecting to a session.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/673d8ac0-f557-48cb-98a6-49925160d729
 */
typedef struct _WINSTATIONCLIENT
{
    ULONG fTextOnly : 1;
    ULONG fDisableCtrlAltDel : 1;
    ULONG fMouse : 1;
    ULONG fDoubleClickDetect : 1;
    ULONG fINetClient : 1;
    ULONG fPromptForPassword : 1;
    ULONG fMaximizeShell : 1;
    ULONG fEnableWindowsKey : 1;
    ULONG fRemoteConsoleAudio : 1;
    ULONG fPasswordIsScPin : 1;
    ULONG fNoAudioPlayback : 1;
    ULONG fUsingSavedCreds : 1;
    WCHAR ClientName[CLIENTNAME_LENGTH + 1];
    WCHAR Domain[DOMAIN_LENGTH + 1];
    WCHAR UserName[USERNAME_LENGTH + 1];
    WCHAR Password[PASSWORD_LENGTH + 1];
    WCHAR WorkDirectory[DIRECTORY_LENGTH + 1];
    WCHAR InitialProgram[INITIALPROGRAM_LENGTH + 1];
    ULONG SerialNumber;
    BYTE EncryptionLevel;
    ULONG ClientAddressFamily;
    WCHAR ClientAddress[CLIENTADDRESS_LENGTH + 1];
    USHORT HRes;
    USHORT VRes;
    USHORT ColorDepth;
    USHORT ProtocolType;
    ULONG KeyboardLayout;
    ULONG KeyboardType;
    ULONG KeyboardSubType;
    ULONG KeyboardFunctionKey;
    WCHAR ImeFileName[IMEFILENAME_LENGTH + 1];
    WCHAR ClientDirectory[DIRECTORY_LENGTH + 1];
    WCHAR ClientLicense[CLIENTLICENSE_LENGTH + 1];
    WCHAR ClientModem[CLIENTMODEM_LENGTH + 1];
    ULONG ClientBuildNumber;
    ULONG ClientHardwareId;
    USHORT ClientProductId;
    USHORT OutBufCountHost;
    USHORT OutBufCountClient;
    USHORT OutBufLength;
    WCHAR AudioDriverName[9];
    TS_TIME_ZONE_INFORMATION ClientTimeZone;
    ULONG ClientSessionId;
    WCHAR ClientDigProductId[CLIENT_PRODUCT_ID_LENGTH];
    ULONG PerformanceFlags;
    ULONG ActiveInputLocale;
} WINSTATIONCLIENT, *PWINSTATIONCLIENT;

typedef struct _TSHARE_COUNTERS
{
    ULONG Reserved;
} TSHARE_COUNTERS, *PTSHARE_COUNTERS;

typedef struct _PROTOCOLCOUNTERS
{
    ULONG WdBytes;
    ULONG WdFrames;
    ULONG WaitForOutBuf;
    ULONG Frames;
    ULONG Bytes;
    ULONG CompressedBytes;
    ULONG CompressFlushes;
    ULONG Errors;
    ULONG Timeouts;
    ULONG AsyncFramingError;
    ULONG AsyncOverrunError;
    ULONG AsyncOverflowError;
    ULONG AsyncParityError;
    ULONG TdErrors;
    USHORT ProtocolType;
    USHORT Length;
    union
    {
        TSHARE_COUNTERS TShareCounters;
        ULONG Reserved[100];
    } Specific;
} PROTOCOLCOUNTERS, *PPROTOCOLCOUNTERS;

typedef struct _THINWIRECACHE
{
    ULONG CacheReads;
    ULONG CacheHits;
} THINWIRECACHE, *PTHINWIRECACHE;

#define MAX_THINWIRECACHE 4

typedef struct _RESERVED_CACHE
{
    THINWIRECACHE ThinWireCache[MAX_THINWIRECACHE];
} RESERVED_CACHE, *PRESERVED_CACHE;

typedef struct _TSHARE_CACHE
{
    ULONG Reserved;
} TSHARE_CACHE, *PTSHARE_CACHE;

/**
 * The CACHE_STATISTICS structure represents the cache statistics on the protocol.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/81203ca2-e58b-4681-affa-924e59671b5c
 */
typedef struct CACHE_STATISTICS
{
    USHORT ProtocolType;                        // Protocol type.
    USHORT Length;                              // Length of data in the protocol-specific area. Can be up to 20 * sizeof(ULONG) in size.
    union
    {
        RESERVED_CACHE ReservedCacheStats;      // Not used.
        TSHARE_CACHE TShareCacheStats;          // Protocol cache statistics.
        ULONG Reserved[20];                     // Reserved for future use.
    } Specific;
} CACHE_STATISTICS, *PCACHE_STATISTICS;

/**
 * The PROTOCOLSTATUS structure represents the status of the protocol used by the session.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/c9066753-acbd-4678-9a72-8fb1b080bd09
 */
typedef struct _PROTOCOLSTATUS
{
    PROTOCOLCOUNTERS Output;    // A PROTOCOLCOUNTERS structure containing the output protocol counters.
    PROTOCOLCOUNTERS Input;     // A PROTOCOLCOUNTERS structure containing the input protocol counters.
    CACHE_STATISTICS Cache;     // A CACHE_STATISTICS structure containing statistics for the cache.
    ULONG AsyncSignal;          // Indicator of async signal, such as MS_CTS_ON, for async protocols.
    ULONG AsyncSignalMask;      // Mask of async signal events, such as EV_CTS, for async protocols.
} PROTOCOLSTATUS, *PPROTOCOLSTATUS;

/**
 * The WINSTATIONINFORMATION structure retrieves the state, connect time, last input time, and so on, for a session.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/c2566d8b-7016-440b-b7e0-0d07c3b2418f
 */
typedef struct _WINSTATIONINFORMATION
{
    WINSTATIONSTATECLASS ConnectState;      // The current connect state of the session.
    WINSTATIONNAME WinStationName;          // The name of the session.
    ULONG LogonId;                          // The session identifier of the session.
    LARGE_INTEGER ConnectTime;              // The time of the most recent connection to the session.
    LARGE_INTEGER DisconnectTime;           // The time of the most recent disconnection from the session.
    LARGE_INTEGER LastInputTime;            // The time the session last received input.
    LARGE_INTEGER LogonTime;                // The time of the logon to the session.
    PROTOCOLSTATUS Status;                  // The status of the protocol.
    WCHAR Domain[DOMAIN_LENGTH + 1];        // The user's domain name.
    WCHAR UserName[USERNAME_LENGTH + 1];    // The user's user name.
    LARGE_INTEGER CurrentTime;              // The current time in the session.
} WINSTATIONINFORMATION, *PWINSTATIONINFORMATION;

/**
 * The TS_TRACE structure specifies fields used for configuring tracing operations in TS binaries if they are checked.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/ad349575-5369-4830-a174-1920a7af8d5f
 */
typedef struct _TS_TRACE
{
    WCHAR TraceFile[256];   // Specifies the file name, if any, to which to write debug information.
    BOOLEAN Debugger;       // Specifies whether debugger is attached.
    BOOLEAN Timestamp;      // Specifies whether to append time stamp to the traces logged.
    ULONG TraceClass;       // Classes of tracing to log. They enable tracing for the various terminal server binaries/functionalities.
    ULONG TraceEnable;      // Type of tracing calls log.
    WCHAR TraceOption[64];  // Trace option string. This can be an empty string meaning collect trace for all files and lines in those files.
} TS_TRACE, *PTS_TRACE;

/**
 * The BEEPINPUT structure performs a beep in the session.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/2faf4c5b-3a79-491a-9d1a-145f46a797d1
 */
typedef struct _BEEPINPUT
{
    /**
     * If the session ID is 0, this can be any of the values that can be passed to the standard MessageBeep function.
     * If the session ID is not 0, a frequency and duration is chosen by the server to send as a beep to the session.
     */
    ULONG Type;
} BEEPINPUT, *PBEEPINPUT;

/**
 * The WINSTATIONUSERTOKEN structure retrieves the user's token for the session.
 *
 * \remarks Caller requires WINSTATION_ALL_ACCESS permission.
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/07f9831c-6331-43e5-ba27-d3d58772eb4c
 */
typedef struct _WINSTATIONUSERTOKEN
{
    HANDLE ProcessId;   // Specifies the Process ID.
    HANDLE ThreadId;    // Specifies the calling thread.
    HANDLE UserToken;   // Returns the user token that is currently logged on to the session.
} WINSTATIONUSERTOKEN, *PWINSTATIONUSERTOKEN;

/**
 * The WINSTATIONVIDEODATA structure defines the resolution and color depth of a session.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/5f95f657-89d2-472d-b4ab-b0595618dbd1
 */
typedef struct _WINSTATIONVIDEODATA
{
    USHORT HResolution; // Specifies the horizontal resolution, in pixels.
    USHORT VResolution; // Specifies the vertical resolution, in pixels.
    USHORT ColorDepth;  // Specifies the color depth.
} WINSTATIONVIDEODATA, *PWINSTATIONVIDEODATA;

typedef enum _CDCLASS
{
    CdNone, // No connection driver.
    CdModem, // Connection driver is a modem.
    CdClass_Maximum,
} CDCLASS;

/**
 * The CDCONFIG structure defines the configuration used for connecting via modem to a server.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/f88900e1-c159-4f02-b3ae-84f05eec212f
 */
typedef struct _CDCONFIG
{
    CDCLASS CdClass; // Connection driver type.
    CDNAME CdName; // Connection driver descriptive name.
    DLLNAME CdDLL; // Connection driver image name.
    ULONG CdFlag; // Connection driver flags. Connection driver specific.
} CDCONFIG, *PCDCONFIG;

// The name has the following form:
// name syntax : xxxyyyy<null>
typedef CHAR CLIENTDATANAME[CLIENTDATANAME_LENGTH + 1];
typedef CHAR* PCLIENTDATANAME;

typedef struct _WINSTATIONCLIENTDATA
{
    CLIENTDATANAME DataName; // Identifies the type of data sent in this WINSTATIONCLIENTDATA structure.
    BOOLEAN fUnicodeData; // TRUE indicates data is in Unicode format; FALSE otherwise.
} WINSTATIONCLIENTDATA, *PWINSTATIONCLIENTDATA;

typedef enum _LOADFACTORTYPE
{
    ErrorConstraint, // An error occurred while obtaining constraint data.
    PagedPoolConstraint, // The amount of paged pool is the constraint.
    NonPagedPoolConstraint, // The amount of non-paged pool is the constraint.
    AvailablePagesConstraint, // The amount of available pages is the constraint.
    SystemPtesConstraint, // The number of system page table entries (PTEs) is the constraint.
    CPUConstraint // CPU usage is the constraint.
} LOADFACTORTYPE;

/**
 * The WINSTATIONLOADINDICATORDATA structure defines data used for the load balancing of a server.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/91459fa1-77e8-4987-a6f0-fe7dd3e62bfc
 */
typedef struct _WINSTATIONLOADINDICATORDATA
{
    ULONG RemainingSessionCapacity;     // The estimated number of additional sessions that can be supported given the CPU constraint.
    LOADFACTORTYPE LoadFactor;          // Indicates the most constrained current resource.
    ULONG TotalSessions;                // The total number of sessions.
    ULONG DisconnectedSessions;         // The number of disconnected sessions.
    LARGE_INTEGER IdleCPU;              // This is always set to 0.
    LARGE_INTEGER TotalCPU;             // This is always set to 0.
    ULONG RawSessionCapacity;           // The raw number of sessions capacity.
    ULONG reserved[9];                  // Reserved.
} WINSTATIONLOADINDICATORDATA, *PWINSTATIONLOADINDICATORDATA;

/**
 * The SHADOWSTATECLASS enumeration specifies WinStation shadow states.
 *
 * \sa https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-tsts/c55fbd8f-d7e3-4efe-9ca6-d0985dab9602
 */
typedef enum _SHADOWSTATECLASS
{
    State_NoShadow, // No shadow operations are currently being performed on this session.
    State_Shadowing, // The session is shadowing a different session. The current session is referred to as a shadow client.
    State_Shadowed // The session is being shadowed by a different session. The current session is referred to as a shadow target.
} SHADOWSTATECLASS;

#define PROTOCOL_CONSOLE 0
#define PROTOCOL_OTHERS 1
#define PROTOCOL_RDP 2

// Retrieves the current shadow state of a session.
typedef struct _WINSTATIONSHADOW
{
    SHADOWSTATECLASS ShadowState; // Specifies the current state of shadowing.
    SHADOWCLASS ShadowClass; // Specifies the type of shadowing.
    ULONG SessionId; // Specifies the session ID of the session.
    ULONG ProtocolType; // Specifies the type of protocol on the session. Can be one of PROTOCOL_* values.
} WINSTATIONSHADOW, *PWINSTATIONSHADOW;

// Retrieves the client product ID and current product ID of the session.
typedef struct _WINSTATIONPRODID
{
    WCHAR DigProductId[CLIENT_PRODUCT_ID_LENGTH];
    WCHAR ClientDigProductId[CLIENT_PRODUCT_ID_LENGTH];
    WCHAR OuterMostDigProductId[CLIENT_PRODUCT_ID_LENGTH];
    ULONG CurrentSessionId;
    ULONG ClientSessionId;
    ULONG OuterMostSessionId;
} WINSTATIONPRODID, *PWINSTATIONPRODID;

// Retrieves the remote IP address of the terminal server client in the session.
typedef struct _WINSTATIONREMOTEADDRESS
{
    USHORT sin_family;
    union
    {
        struct
        {
            USHORT sin_port;
            ULONG sin_addr;
            UCHAR sin_zero[8];
        } ipv4;
        struct
        {
            USHORT sin6_port;
            ULONG sin6_flowinfo;
            USHORT sin6_addr[8];
            ULONG sin6_scope_id;
        } ipv6;
    };
} WINSTATIONREMOTEADDRESS, *PWINSTATIONREMOTEADDRESS;

//
// WinStationInformationEx
//

// private
typedef struct _WINSTATIONINFORMATIONEX_LEVEL1
{
    ULONG SessionId;
    WINSTATIONSTATECLASS SessionState;
    LONG SessionFlags;
    WINSTATIONNAME WinStationName;
    WCHAR UserName[USERNAME_LENGTH + 1];
    WCHAR DomainName[DOMAIN_LENGTH + 1];
    LARGE_INTEGER LogonTime;
    LARGE_INTEGER ConnectTime;
    LARGE_INTEGER DisconnectTime;
    LARGE_INTEGER LastInputTime;
    LARGE_INTEGER CurrentTime;
    PROTOCOLSTATUS ProtocolStatus;
} WINSTATIONINFORMATIONEX_LEVEL1, *PWINSTATIONINFORMATIONEX_LEVEL1;

// private
typedef struct _WINSTATIONINFORMATIONEX_LEVEL2
{
    ULONG SessionId;
    WINSTATIONSTATECLASS SessionState;
    LONG SessionFlags;
    WINSTATIONNAME WinStationName;
    WCHAR SamCompatibleUserName[USERNAME_LENGTH + 1];
    WCHAR SamCompatibleDomainName[DOMAIN_LENGTH + 1];
    LARGE_INTEGER LogonTime;
    LARGE_INTEGER ConnectTime;
    LARGE_INTEGER DisconnectTime;
    LARGE_INTEGER LastInputTime;
    LARGE_INTEGER CurrentTime;
    PROTOCOLSTATUS ProtocolStatus;
    WCHAR UserName[257];
    WCHAR DomainName[256];
} WINSTATIONINFORMATIONEX_LEVEL2, *PWINSTATIONINFORMATIONEX_LEVEL2;

// private
typedef union _WINSTATIONINFORMATIONEX_LEVEL
{
    WINSTATIONINFORMATIONEX_LEVEL1 WinStationInfoExLevel1;
    WINSTATIONINFORMATIONEX_LEVEL2 WinStationInfoExLevel2;
} WINSTATIONINFORMATIONEX_LEVEL, *PWINSTATIONINFORMATIONEX_LEVEL;

// private
typedef struct _WINSTATIONINFORMATIONEX
{
    ULONG Level;
    WINSTATIONINFORMATIONEX_LEVEL Data;
} WINSTATIONINFORMATIONEX, *PWINSTATIONINFORMATIONEX;

#define TS_PROCESS_INFO_MAGIC_NT4 0x23495452

typedef struct _TS_PROCESS_INFORMATION_NT4
{
    ULONG MagicNumber;
    ULONG LogonId;
    PVOID ProcessSid;
    ULONG Pad;
} TS_PROCESS_INFORMATION_NT4, *PTS_PROCESS_INFORMATION_NT4;

#define SIZEOF_TS4_SYSTEM_THREAD_INFORMATION 64
#define SIZEOF_TS4_SYSTEM_PROCESS_INFORMATION 136

_Struct_size_bytes_(NextEntryOffset)
typedef struct _TS_SYS_PROCESS_INFORMATION
{
    ULONG NextEntryOffset;
    ULONG NumberOfThreads;
    LARGE_INTEGER SpareLi1;
    LARGE_INTEGER SpareLi2;
    LARGE_INTEGER CycleTime;
    LARGE_INTEGER CreateTime;
    LARGE_INTEGER UserTime;
    LARGE_INTEGER KernelTime;
    UNICODE_STRING ImageName;
    KPRIORITY BasePriority;
    ULONG UniqueProcessId;
    ULONG InheritedFromUniqueProcessId;
    ULONG HandleCount;
    ULONG SessionId;
    ULONG UniqueProcessKey;
    SIZE_T PeakVirtualSize;
    SIZE_T VirtualSize;
    ULONG PageFaultCount;
    ULONG PeakWorkingSetSize;
    ULONG WorkingSetSize;
    SIZE_T QuotaPeakPagedPoolUsage;
    SIZE_T QuotaPagedPoolUsage;
    SIZE_T QuotaPeakNonPagedPoolUsage;
    SIZE_T QuotaNonPagedPoolUsage;
    SIZE_T PagefileUsage;
    SIZE_T PeakPagefileUsage;
    SIZE_T PrivatePageCount;
} TS_SYS_PROCESS_INFORMATION, *PTS_SYS_PROCESS_INFORMATION;

typedef struct _TS_ALL_PROCESSES_INFO
{
    PTS_SYS_PROCESS_INFORMATION TsProcessInfo;
    ULONG SizeOfSid;
    PSID Sid;
} TS_ALL_PROCESSES_INFO, *PTS_ALL_PROCESSES_INFO;

typedef struct _TS_COUNTER_HEADER
{
    ULONG CounterID;
    BOOLEAN Result;
} TS_COUNTER_HEADER, *PTS_COUNTER_HEADER;

typedef struct _TS_COUNTER
{
    TS_COUNTER_HEADER CounterHead;
    ULONG Value;
    LARGE_INTEGER StartTime;
} TS_COUNTER, *PTS_COUNTER;

// Flags for WinStationShutdownSystem
#define WSD_LOGOFF 0x1
#define WSD_SHUTDOWN 0x2
#define WSD_REBOOT 0x4
#define WSD_POWEROFF 0x8

// Flags for WinStationWaitSystemEvent
#define WEVENT_NONE 0x0
#define WEVENT_CREATE 0x1
#define WEVENT_DELETE 0x2
#define WEVENT_RENAME 0x4
#define WEVENT_CONNECT 0x8
#define WEVENT_DISCONNECT 0x10
#define WEVENT_LOGON 0x20
#define WEVENT_LOGOFF 0x40
#define WEVENT_STATECHANGE 0x80
#define WEVENT_LICENSE 0x100
#define WEVENT_ALL 0x7fffffff
#define WEVENT_FLUSH 0x80000000

// Hotkey modifiers for WinStationShadow
#define KBDSHIFT 0x1
#define KBDCTRL 0x2
#define KBDALT 0x4

// begin_rev
// Flags for WinStationRegisterConsoleNotification
/**
 * WNOTIFY_THIS_SESSION
 *
 * Specifies that only session notifications involving the session attached
 * to by the window identified by the WindowHandle are to be received.
 */
#define WNOTIFY_THIS_SESSION 0x0
/**
 * WNOTIFY_ALL_SESSIONS
 *
 * Specifies that all session notifications are to be received.
 */
#define WNOTIFY_ALL_SESSIONS 0x1
// end_rev

// In the functions below, memory returned can be freed using LocalFree. NULL can be specified for
// server handles to indicate the local server. -1 can be specified for session IDs to indicate the
// current session ID.

// rev
/**
 * The WinStationFreeMemory routine frees memory allocated by a Remote Desktop Services function.
 *
 * \param Buffer Pointer to the memory to free.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/nf-wtsapi32-wtsfreememory
 */
NTSYSAPI
BOOLEAN
NTAPI
WinStationFreeMemory(
    _In_ PVOID Buffer
    );

// rev
/**
 * The WinStationOpenServerW routine opens a handle to the specified Remote Desktop Session Host (RD Session Host) server.
 *
 * \param ServerName Pointer to a null-terminated string specifying the NetBIOS name of the RD Session Host server.
 * \return HANDLE If the function succeeds, the return value is a handle to the specified server.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/nf-wtsapi32-wtsopenserverw
 */
NTSYSAPI
HANDLE
NTAPI
WinStationOpenServerW(
    _In_opt_ PCWSTR ServerName
    );

// rev
/**
 * The WinStationOpenServerExW routine opens a handle to the specified Remote Desktop Session Host (RD Session Host) server
 * or Remote Desktop Virtualization Host (RD Virtualization Host) server.
 *
 * \param ServerName Pointer to a null-terminated string specifying the NetBIOS name of the RD Session Host server.
 * \return HANDLE If the function succeeds, the return value is a handle to the specified server.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/nf-wtsapi32-wtsopenserverexw
 */
NTSYSAPI
HANDLE
NTAPI
WinStationOpenServerExW(
    _In_opt_ PCWSTR ServerName
    );

// rev
/**
 * The WinStationCloseServer routine closes an open handle to a Remote Desktop Session Host (RD Session Host) server.
 *
 * \param ServerHandle A handle to an RD Session Host server opened by a call to the WinStationOpenServerW function.
 * \return BOOLEAN Nonzero if the function succeeds, or zero otherwise. To get extended error information, call GetLastError.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/nf-wtsapi32-wtscloseserver
 */
NTSYSAPI
BOOLEAN
NTAPI
WinStationCloseServer(
    _In_ HANDLE ServerHandle
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationServerPing(
    _In_opt_ HANDLE ServerHandle
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationGetTermSrvCountersValue(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG Count,
    _Inout_ PTS_COUNTER Counters // set counter IDs before calling
    );

// rev
/**
 * The WinStationShutdownSystem routine shuts down (and optionally restarts) the specified Remote Desktop Session Host (RD Session Host) server.
 *
 * \param ServerHandle Handle to an RD Session Host server, or specify WINSTATION_CURRENT_SERVER to indicate the server on which your application is running.
 * \param ShutdownFlags Indicates the type of shutdown. This parameter can be one of the WSD_* values.
 * \return BOOLEAN Nonzero if the function succeeds, or zero otherwise. To get extended error information, call GetLastError.
 * \remarks To shut down or restart the system, the calling process must have the SE_SHUTDOWN_NAME privilege enabled.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/nf-wtsapi32-wtsshutdownsystem
 */
NTSYSAPI
BOOLEAN
NTAPI
WinStationShutdownSystem(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG ShutdownFlags // WSD_*
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationWaitSystemEvent(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG EventMask, // WEVENT_*
    _Out_ PULONG EventFlags
    );

// rev
/**
 * The WinStationRegisterConsoleNotification routine shuts down (and optionally restarts) the specified Remote Desktop Session Host (RD Session Host) server.
 *
 * \param ServerHandle Handle to an RD Session Host server, or WINSTATION_CURRENT_SERVER .
 * \param WindowHandle Handle of the window to receive session change notifications.
 * \param Flags Specifies whether to receive notifications for all sessions (WNOTIFY_ALL_SESSIONS) or only for the console session.
 * \return BOOLEAN Nonzero if the function succeeds, or zero otherwise. To get extended error information, call GetLastError.
 * \remarks To shut down or restart the system, the calling process must have the SE_SHUTDOWN_NAME privilege enabled.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/nf-wtsapi32-wtsregistersessionnotificationex
 */
NTSYSAPI
BOOLEAN
NTAPI
WinStationRegisterConsoleNotification(
    _In_opt_ HANDLE ServerHandle,
    _In_ HWND WindowHandle,
    _In_ ULONG Flags
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationUnRegisterConsoleNotification(
    _In_opt_ HANDLE ServerHandle,
    _In_ HWND WindowHandle
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationEnumerateW(
    _In_opt_ HANDLE ServerHandle,
    _Out_ PSESSIONIDW *SessionIds,
    _Out_ PULONG Count
    );

/**
 * The WinStationQueryInformationW routine retrieves information about a window station.
 *
 * \param ServerHandle A handle to an RD Session Host server. Specify a handle opened by the WinStationOpenServerW function, or specify WINSTATION_CURRENT_SERVER to indicate the server on which your application is running.
 * \param SessionId A Remote Desktop Services session identifier.
 * To indicate the session in which the calling application is running (or the current session) specify WINSTATION_CURRENT_SESSION.
 * Only specify WINSTATION_CURRENT_SESSION when obtaining session information on the local server.
 * If WINSTATION_CURRENT_SESSION is specified when querying session information on a remote server, the returned session information will be inconsistent. Do not use the returned data.
 * \param WinStationInformationClass A value from the TOKEN_INFORMATION_CLASS enumerated type identifying the type of information to be retrieved.
 * \param WinStationInformation Pointer to a caller-allocated buffer that receives the requested information about the token.
 * \param WinStationInformationLength Length, in bytes, of the caller-allocated TokenInformation buffer.
 * \param ReturnLength Pointer to a caller-allocated variable that receives the actual length, in bytes, of the information returned in the TokenInformation buffer.
 * \return BOOLEAN Nonzero if the function succeeds, or zero otherwise. To get extended error information, call GetLastError.
 * \sa https://learn.microsoft.com/en-us/previous-versions/aa383827(v=vs.85)
 */
NTSYSAPI
BOOLEAN
NTAPI
WinStationQueryInformationW(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ WINSTATIONINFOCLASS WinStationInformationClass,
    _Out_writes_bytes_(WinStationInformationLength) PVOID WinStationInformation,
    _In_ ULONG WinStationInformationLength,
    _Out_ PULONG ReturnLength
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationSetInformationW(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ WINSTATIONINFOCLASS WinStationInformationClass,
    _In_reads_bytes_(WinStationInformationLength) PVOID WinStationInformation,
    _In_ ULONG WinStationInformationLength
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationQueryCurrentSessionInformation(
    _In_ WINSTATIONINFOCLASS WinStationInformationClass,
    _In_reads_bytes_(WinStationInformationLength) PVOID WinStationInformation,
    _In_ ULONG WinStationInformationLength
    );

NTSYSAPI
BOOLEAN
NTAPI
WinStationNameFromLogonIdW(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _Out_writes_(WINSTATIONNAME_LENGTH + 1) PWSTR WinStationName
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
LogonIdFromWinStationNameW(
    _In_opt_ HANDLE ServerHandle,
    _In_ PCWSTR WinStationName,
    _Out_ PULONG SessionId
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationSendMessageW(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ PCWSTR Title,
    _In_ ULONG TitleLength,
    _In_ PCWSTR Message,
    _In_ ULONG MessageLength,
    _In_ ULONG Style,
    _In_ ULONG Timeout,
    _Out_ PULONG Response,
    _In_ BOOLEAN DoNotWait
    );

NTSYSAPI
BOOLEAN
NTAPI
WinStationConnectW(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ ULONG TargetSessionId,
    _In_opt_ PCWSTR Password,
    _In_ BOOLEAN bWait
    );

NTSYSAPI
BOOLEAN
NTAPI
WinStationDisconnect(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ BOOLEAN bWait
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationReset(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ BOOLEAN bWait
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationShadow(
    _In_opt_ HANDLE ServerHandle,
    _In_ PCWSTR TargetServerName,
    _In_ ULONG TargetSessionId,
    _In_ UCHAR HotKeyVk,
    _In_ USHORT HotkeyModifiers // KBD*
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationShadowStop(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ BOOLEAN bWait // ignored
    );

// Processes

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationEnumerateProcesses(
    _In_opt_ HANDLE ServerHandle,
    _Out_ PVOID *Processes
    );

#define WINSTATION_PROCESS_LEVEL 0

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationGetAllProcesses(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG Level,
    _Out_ PULONG NumberOfProcesses,
    _Out_ PTS_ALL_PROCESSES_INFO *Processes
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationFreeGAPMemory(
    _In_ ULONG Level,
    _In_ PTS_ALL_PROCESSES_INFO Processes,
    _In_ ULONG NumberOfProcesses
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationTerminateProcess(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG ProcessId,
    _In_ ULONG ExitCode
    );

NTSYSAPI
BOOLEAN
NTAPI
WinStationGetProcessSid(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG ProcessId,
    _In_ FILETIME ProcessStartTime,
    _Out_ PVOID ProcessUserSid,
    _Inout_ PULONG dwSidSize
    );

//
// Services isolation
//

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationSwitchToServicesSession(
    VOID
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationRevertFromServicesSession(
    VOID
    );

// Misc.
NTSYSAPI
BOOLEAN
NTAPI
_WinStationWaitForConnect(
    VOID
    );

// rev
NTSYSAPI
HANDLE
NTAPI
WinStationVirtualOpen(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ PCSTR Name
    );

// rev
NTSYSAPI
HANDLE
NTAPI
WinStationVirtualOpenEx(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ PCSTR Name,
    _In_ ULONG Flags
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationIsCurrentSessionRemoteable(
    _Out_ PBOOLEAN IsRemoteable
    );

EXTERN_C DECLSPEC_SELECTANY CONST GUID PROPERTY_TYPE_GET_MONITOR_CONFIG = { 0x865D5285, 0xF70A, 0x4ECF, { 0x8B, 0x28, 0x51, 0x2F, 0xE0, 0xAA, 0x2D, 0x53 } };
EXTERN_C DECLSPEC_SELECTANY CONST GUID PROPERTY_TYPE_CORRELATIONID_GUID = { 0x9A363F8E, 0x1902, 0x40DA, { 0xA2, 0xCC, 0x56, 0x4F, 0x09, 0x40, 0xAD, 0xE3 } };

typedef struct _TS_PROPERTY_INFORMATION
{
    ULONG Length;
    PVOID Buffer;
} TS_PROPERTY_INFORMATION, *PTS_PROPERTY_INFORMATION;

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationGetConnectionProperty(
    _In_ ULONG SessionId,
    _In_ PCGUID PropertyType,
    _Out_ PTS_PROPERTY_INFORMATION PropertyBuffer
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationFreePropertyValue(
    _In_ PVOID PropertyBuffer
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationIsSessionRemoteable(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _Out_ PBOOLEAN IsRemote
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationSetAutologonPassword(
    _In_ PCSTR KeyName,
    _In_ PCSTR Password
    );

// private
typedef struct _EXECENVDATAEX_LEVEL1
{
    LONG ExecEnvId;
    LONG State;
    LONG AbsSessionId;
    PWSTR SessionName;
    PWSTR HostName;
    PWSTR UserName;
    PWSTR DomainName;
    PWSTR FarmName;
} EXECENVDATAEX_LEVEL1, *PEXECENVDATAEX_LEVEL1;

typedef union _EXECENVDATAEX_PAYLOAD
{
    UCHAR Data[1];
    EXECENVDATAEX_LEVEL1 Level1;
    // define level 2/3/4 here
} EXECENVDATAEX_PAYLOAD;

typedef struct _EXECENVDATAEX
{
    ULONG Level;
    EXECENVDATAEX_PAYLOAD Payload;
} EXECENVDATAEX, *PEXECENVDATAEX;

// typedef struct _EXECENVDATAEX
// {
//     ULONG Level;
//     union
//     {
//         EXECENVDATAEX_LEVEL1 ExecEnvEnum_Level1;
//     };
// } EXECENVDATAEX, *PEXECENVDATAEX;

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationGetAllSessionsEx(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG Level, // Must be 1
    _Out_ PEXECENVDATAEX *SessionData,
    _Out_ PULONG Count
    );

// rev
NTSYSAPI
VOID 
WINAPI 
WinStationFreeEXECENVDATAEX(
    _In_opt_ PEXECENVDATAEX SessionData,
    _In_ ULONG Count
    );

typedef enum _SessionType
{
    SESSIONTYPE_UNKNOWN = 0,
    SESSIONTYPE_SERVICES,
    SESSIONTYPE_LISTENER,
    SESSIONTYPE_REGULARDESKTOP,
    SESSIONTYPE_ALTERNATESHELL,
    SESSIONTYPE_REMOTEAPP,
    SESSIONTYPE_MEDIACENTEREXT
} SESSIONTYPE;

// rev
typedef struct _TS_USER_SESSION
{
    ULONG Version;
    ULONG SessionId;
    ULONG Unknown;
    SESSIONTYPE State;
    ULONG field5;
} TS_USER_SESSION, *PTS_USER_SESSION;

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationGetAllUserSessions(
    _In_opt_ HANDLE ServerHandle,
    _In_ PSID Sid,
    _Out_ PVOID* Processes, // LocalFree
    _Out_ PULONG NumberOfProcesses
    );

// rev
typedef struct _TS_SESSION_VIRTUAL_ADDRESS
{
  USHORT AddressFamily;
  USHORT AddressLength;
  BYTE Address[20];
} TS_SESSION_VIRTUAL_ADDRESS, *PTS_SESSION_VIRTUAL_ADDRESS;
typedef USHORT ADDRESS_FAMILY;

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationQuerySessionVirtualIP(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _In_ ADDRESS_FAMILY Family,
    _Out_ TS_SESSION_VIRTUAL_ADDRESS* SessionVirtualIP
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationGetDeviceId(
    _In_opt_ HANDLE ServerHandle,
    _In_ ULONG SessionId,
    _Out_ PCHAR* Buffer, // CHAR DeviceId[MAX_PATH + 1];
    _In_ SIZE_T BufferLength
    );

// rev
NTSYSAPI
BOOLEAN
NTAPI
WinStationGetLoggedOnCount(
    _Out_ PULONG LoggedOnUserCount,
    _Out_ PULONG LoggedOnDeviceCount
    );

// rev
/**
 * The WinStationSetRenderHint routine is used by an application that is displaying content that 
 * can be optimized for displaying in a remote session to identify the region of a window that is the actual content.
 * In the remote session, this content will be encoded, sent to the client, then decoded and displayed.
 *
 * \param[out] RenderHintID The address of a value that identifies the rendering hint affected by this call.
 * If a new hint is being created, this value must contain zero.
 * This function will return a unique rendering hint identifier which is used for subsequent calls, such as clearing the hint.
 * \param[in] WindowHandle The handle of window linked to lifetime of the rendering hint. This window is used in situations where a hint target is removed without the hint being explicitly cleared.
 * \param[in] RenderHintType Specifies the type of hint represented by this call.
 * \param[in] HintDataLength The size in bytes, of the HintData buffer.
 * \param[in] HintData Additional data for the hint. The format of this data is dependent upon the value passed in the renderHintType parameter.
 * \return BOOLEAN Nonzero if the function succeeds, or zero otherwise.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtshintapi/nf-wtshintapi-wtssetrenderhint
 */
NTSYSAPI
BOOLEAN
NTAPI
WinStationSetRenderHint(
    _In_opt_ PULONG64 RenderHintID,
    _In_ HWND WindowHandle,
    _In_ ULONG RenderHintType,
    _In_ ULONG HintDataLength,
    _In_ PBYTE HintData
    );

// rev
/**
 * The WinStationActiveSessionExists routine returns active sessions on the system without enumerating through the list of sessions.
 * It also does not obtain any extra information from Local Session Manager.
 *
 * \return BOOLEAN Nonzero if an active session exists.
 * \sa https://learn.microsoft.com/en-us/windows/win32/api/wtsapi32/nf-wtsapi32-wtsactivesessionexists
 */
NTSYSAPI
BOOLEAN
NTAPI
WinStationActiveSessionExists(
    VOID
    );

#endif
